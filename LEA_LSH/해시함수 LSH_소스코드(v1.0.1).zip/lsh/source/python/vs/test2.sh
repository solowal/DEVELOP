#!
echo "Testing for Python2"
python2 lshvs.py

