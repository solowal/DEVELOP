
from projectq.ops import H, CNOT, Measure, Toffoli, X, All, Swap
from projectq import MainEngine
from projectq.backends import ResourceCounter, ClassicalSimulator

from projectq.meta import Loop, Compute, Uncompute, Control


def Add_RK(eng, b, k):
    for i in range(64):
        CNOT | (k[i], b[i])

def p_sbox_lighter_r(eng, b):

    CNOT | (b[2], b[1])

    Toffoli | (b[1], b[2], b[3])
    Toffoli | (b[3], b[1], b[2])
    Toffoli | (b[0], b[2], b[1])

    CNOT | (b[3] ,b[2])

    X | b[3]

    CNOT | (b[1], b[2])
    CNOT | (b[3], b[0])
    CNOT | (b[0], b[1])

    X | b[0]

    Toffoli | (b[1] ,b[2], b[3])

    Swap | (b[3], b[1]) #b[3] = b[1] , b[1] = b[3]
    Swap | (b[2], b[1]) #b[2] = b[3] , b[1] = b[2] 0 ,2 ,3 1

def Permutation(eng, b):

    Swap|(b[1], b[4]) # b[1] = 4
    Swap|(b[16], b[4]) # b[16] = 1 b[4] = 16

    Swap|(b[2], b[8])
    Swap|(b[32], b[8])

    Swap|(b[3], b[12])
    Swap|(b[48], b[12])

    Swap|(b[5], b[20])
    Swap|(b[17], b[20])

    Swap|(b[6], b[24])
    Swap|(b[33], b[24])

    Swap|(b[7], b[28])
    Swap|(b[49], b[28])

    Swap|(b[9], b[36])
    Swap|(b[18], b[36])

    Swap|(b[10], b[40])
    Swap|(b[34], b[40])

    Swap|(b[11], b[44])
    Swap|(b[50], b[44])

    Swap|(b[13], b[52])
    Swap|(b[19], b[52])

    Swap|(b[14], b[56])
    Swap|(b[35], b[56])

    Swap|(b[15], b[60])
    Swap|(b[51], b[60])

    Swap|(b[22], b[25])
    Swap|(b[37], b[25])

    Swap|(b[23], b[29])
    Swap|(b[53], b[29])

    Swap|(b[26], b[41])
    Swap|(b[38], b[41])

    Swap|(b[27], b[45])
    Swap|(b[54], b[45])

    Swap|(b[30], b[57])
    Swap|(b[39], b[57])

    Swap|(b[31], b[61])
    Swap|(b[55], b[61])

    Swap|(b[43], b[46])
    Swap|(b[58], b[46])

    Swap|(b[47], b[62])
    Swap|(b[59], b[62])

def keySchedule(eng, k, ctr):
    ctr = ctr+1

    for j in range(19): #right shift 19
        for i in range(79):
            Swap | (k[i], k[i+1])

    p_sbox_lighter_r(eng, k[76:80])
    CTR_XOR(eng, k[15:20], ctr)

    return ctr

def CTR_XOR(eng, k, ctr):

    if (ctr >= 16):
        X | (k[4])
        ctr = ctr - 16
    if (ctr >= 8):
        X | (k[3])
        ctr = ctr - 8
    if (ctr >= 4):
        X | (k[2])
        ctr = ctr - 4
    if (ctr >= 2):
        X | (k[1])
        ctr = ctr - 2
    if (ctr >= 1):
        X | (k[0])
        ctr = ctr - 1


def Enc(eng):

    b = eng.allocate_qureg(64) #Plaintext
    k = eng.allocate_qureg(80) #Key

    #Set Plaintext, Key
    #All(X) | b # 0xffffffffffffffff
    #All(X) | k # 0xffffffffffffffffffff

    ctr = 0

    for j in range(31):

        Add_RK(eng, b, k[16:80]) #Addroundeky

        ctr = keySchedule(eng, k, ctr)  # Keyschedule

        for i in range(16):      #Sbox
            p_sbox_lighter_r(eng, b[4*i : 4*(i+1)])

        Permutation(eng, b)      #Permutation

    Add_RK(eng, b, k[16:80])  # Addroundeky

    All(Measure) | b

    for i in range (64):
        print(int(b[63-i]), end=' ')


Engine = ClassicalSimulator()
eng = MainEngine(Engine)
print('Ciphertext :')
(Enc(eng))

print('\n\nChecking quantum resources....')
Engine = ResourceCounter()
eng = MainEngine(Engine)
Enc(eng)
print('\n')
print(Engine)

eng.flush()
