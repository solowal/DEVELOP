import math

from projectq import MainEngine
from projectq.ops import H, CNOT, Measure, Toffoli, X, All
from projectq.backends import CircuitDrawer, ResourceCounter
from projectq.meta import Loop, Compute, Uncompute, Control

def Sbox(eng, input):

    Toffoli | (input[0], input[2], input[1])
    Toffoli | (input[1] ,input[3], input[0])

    X | (input[0])
    X | (input[1])
    Toffoli | (input[0], input[1], input[2])
    X | (input[2])
    #reverse
    X | (input[0])
    X | (input[1])

    CNOT | (input[2], input[3])
    X | (input[3])

    CNOT | (input[3], input[1])
    X | (input[1])

    Toffoli | (input[0], input[1], input[2])

    #in  : 3 2 1 0
    #out : 0 2 1 3

    #2번 수행하면 원래 자리로 -> out : 3 2 1 0

def Add_roundkey(eng, key, input):
    for i in range(32):
        CNOT | ( key[i], input[4*i+1])
        CNOT | ( key[i+32], input[4*i+2])


def Enc(eng):

    input = eng.allocate_qureg(128)
    key = eng.allocate_qureg(128) # Result : 192( 64 qubits omitted(key schedule)) --> Actually 256 qubits

    #Round 0
    for i in range (32) :
        Sbox(eng, input[4*i:4*i+4])

    # Permutation
    # (permutation not applied)
    Add_roundkey(eng, key, input)

    #Add constant (0x01) (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]

    X | input[127]

    #Key schedule (127 ~ 0) , no cost

    # Round 1
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x03) (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[7]

    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 2
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x07) (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[7]
    X | input[11]

    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 3
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x0f) (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[7]
    X | input[11]
    X | input[15]

    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 4
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x1f) (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[7]
    X | input[11]
    X | input[15]
    X | input[19]

    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 5
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x3e) 111110 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[7]
    X | input[11]
    X | input[15]
    X | input[19]
    X | input[23]

    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 6
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x3d) 111101 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[11]
    X | input[15]
    X | input[19]
    X | input[23]

    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 7
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x3b) 111011 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[7]
    X | input[15]
    X | input[19]
    X | input[23]

    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 8
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x37) 110111 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[7]
    X | input[11]
    X | input[19]
    X | input[23]

    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 9
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x2F) 101111 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[7]
    X | input[11]
    X | input[15]
    X | input[23]

    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    #Round 10
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x1E) 11110 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[7]
    X | input[11]
    X | input[15]
    X | input[19]

    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 11
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x3C) 111100 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[11]
    X | input[15]
    X | input[19]
    X | input[23]

    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 12
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x39) 111001 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[15]
    X | input[19]
    X | input[23]

    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 13
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x33) 110011 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[7]
    X | input[19]
    X | input[23]

    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 14
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x27) 100111 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[7]
    X | input[11]
    X | input[23]

    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 15
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x0E) 1110 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[7]
    X | input[11]
    X | input[15]

    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 16
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x1D) 11101 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[11]
    X | input[15]
    X | input[19]

    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 17
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x3A) 111010 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[7]
    X | input[15]
    X | input[19]
    X | input[23]

    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 18
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x35) 110101 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[11]
    X | input[19]
    X | input[23]

    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 19
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x2B) 101011 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[7]
    X | input[15]
    X | input[23]

    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 20
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x16) 10110 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[7]
    X | input[11]
    X | input[19]

    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 21
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x2C) 101100 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[11]
    X | input[15]
    X | input[23]

    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 22
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x18) 11000 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[15]
    X | input[19]

    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 23
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x30) 110000 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[19]
    X | input[23]

    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 24
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x21) 100001 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[23]

    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 25
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x02) 10 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[7]

    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 26
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x05) 101 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[11]

    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 27
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x0B) 1011 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[7]
    X | input[15]

    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    ##########

    # Round 28
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x17) 10111 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[7]
    X | input[11]

    X | input[19]

    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 29
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x2E) 101110 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[7]
    X | input[11]
    X | input[15]
    X | input[23]

    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 30
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x1C) 11100 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[11]
    X | input[15]
    X | input[19]

    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 31
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x38) 111000 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[23]
    X | input[15]
    X | input[19]

    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 32
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x31) 110001 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[19]
    X | input[23]
    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 33
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x23) 100011 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[7]
    X | input[23]
    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 34
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x06) 1010 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[7]
    X | input[15]
    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 35
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x0D) 1101 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[11]
    X | input[15]
    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 36
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x1B) 11011 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[7]
    X | input[15]
    X | input[19]
    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 37
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x36) 11 1010 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[7]
    X | input[15]
    X | input[19]
    X | input[23]
    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 38
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x2D) 10 1101 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[11]
    X | input[15]
    X | input[23]
    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 39
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x1A) 01 1010 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[7]
    X | input[15]
    X | input[19]
    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 40
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x34) 11 0100 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[11]
    X | input[19]
    X | input[23]
    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 41
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x29) 10 1001 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[15]
    X | input[23]
    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 42
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x12) 01 0010 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[7]
    X | input[19]
    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 43
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x24) 10 0100 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[11]
    X | input[23]
    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 44
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x08) 00 1000 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[15]
    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 45
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x11) 01 0001 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[19]
    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 46
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x22) 10 0010 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[7]
    X | input[23]
    X | input[127]

    # Key schedule (127 ~ 0) , no cost

    # Round 47
    for i in range(32):
        Sbox(eng, input[4 * i:4 * i + 4])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x04) 00 0100 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[11]
    X | input[127]

    # Key schedule (127 ~ 0) , no cost

Resource = ResourceCounter()
eng = MainEngine(Resource)
Enc(eng)
print(Resource)

#eng = MainEngine()
#print(Enc(eng))

eng.flush()

#drawing_engine = CircuitDrawer()
#eng = MainEngine(drawing_engine)

#Enc(eng)
#eng.flush()
#print(drawing_engine.get_latex())


