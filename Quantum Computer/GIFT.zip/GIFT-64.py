import math

from projectq import MainEngine
from projectq.ops import H, CNOT, Measure, Toffoli, X, All
from projectq.backends import CircuitDrawer, ResourceCounter, ClassicalSimulator
from projectq.meta import Loop, Compute, Uncompute, Control

def Sbox(eng, input):

    Toffoli | (input[0], input[2], input[1])
    Toffoli | (input[1] ,input[3], input[0])

    X | (input[0])
    X | (input[1])
    Toffoli | (input[0], input[1], input[2])
    X | (input[2])
    #reverse
    X | (input[0])
    X | (input[1])

    CNOT | (input[2], input[3])
    X | (input[3])

    CNOT | (input[3], input[1])
    X | (input[1])

    Toffoli | (input[0], input[1], input[2])

    #in  : 3 2 1 0
    #out : 0 2 1 3

    #2번 수행하면 원래 자리로 -> out : 3 2 1 0

def Add_roundkey(eng, key, input): 
    for i in range(16):
        CNOT | ( key[i], input[4*i])
        CNOT | ( key[i+16], input[4*i+1])




def Enc(eng):

    input = eng.allocate_qureg(64)
    key = eng.allocate_qureg(128) # Result : 96( 96 qubits (key schedule)) --> Actually 192

    #Round 0
    Sbox(eng, input[0:4]); Sbox(eng, input[4:8]); Sbox(eng, input[8:12]); Sbox(eng, input[12:16])
    Sbox(eng, input[16:20]); Sbox(eng, input[20:24]); Sbox(eng, input[24:28]); Sbox(eng, input[28:32])
    Sbox(eng, input[32:36]); Sbox(eng, input[36:40]); Sbox(eng, input[40:44]); Sbox(eng, input[44:48])
    Sbox(eng, input[48:52]); Sbox(eng, input[52:56]); Sbox(eng, input[56:60]); Sbox(eng, input[60:64])

    # Permutation
    # 0, 17, 34, 51, 48,  1, 18, 35, 32, 49,  2, 19, 16, 33, 50,  3,
    # 4, 21, 38, 55, 52,  5, 22, 39, 36, 53,  6, 23, 20, 37, 54,  7,
    # 8, 25, 42, 59, 56,  9, 26, 43, 40, 57, 10, 27, 24, 41, 58, 11,
    # 12, 29, 46, 63, 60, 13, 30, 47, 44, 61, 14, 31, 28, 45, 62, 15

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    #Add constant (0x01) (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]

    X | input[63]

    #Key schedule (127 ~ 0) , no cost

    # 32 Roation right
    # 31 ~ 0 | 127 ~ 32

    # part rotation right( 2, 12 )
    # 31 ~ 16 | 15 ~ 0 | 127 ~ 32
    # 17 16 31 ~ 18 | 11 ~ 0, 15, 14, 13, 12 | 127 ~ 32

    # Round 1

    Sbox(eng, input[0:4]); Sbox(eng, input[4:8]); Sbox(eng, input[8:12]); Sbox(eng, input[12:16])
    Sbox(eng, input[16:20]); Sbox(eng, input[20:24]); Sbox(eng, input[24:28]); Sbox(eng, input[28:32])
    Sbox(eng, input[32:36]); Sbox(eng, input[36:40]); Sbox(eng, input[40:44]); Sbox(eng, input[44:48])
    Sbox(eng, input[48:52]); Sbox(eng, input[52:56]); Sbox(eng, input[56:60]); Sbox(eng, input[60:64])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x03) (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[7]

    X | input[63]

    # Key schedule (127 ~ 0) , no cost

    # Round 2
    for i in range (16):
        Sbox(eng, input[4*i:4*(i+1)])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x07) (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[7]
    X | input[11]

    X | input[63]

    # Key schedule (127 ~ 0) , no cost

    # Round 3
    Sbox(eng, input[0:4])
    Sbox(eng, input[4:8])
    Sbox(eng, input[8:12])
    Sbox(eng, input[12:16])
    Sbox(eng, input[16:20])
    Sbox(eng, input[20:24])
    Sbox(eng, input[24:28])
    Sbox(eng, input[28:32])
    Sbox(eng, input[32:36])
    Sbox(eng, input[36:40])
    Sbox(eng, input[40:44])
    Sbox(eng, input[44:48])
    Sbox(eng, input[48:52])
    Sbox(eng, input[52:56])
    Sbox(eng, input[56:60])
    Sbox(eng, input[60:64])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x0f) (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[7]
    X | input[11]
    X | input[15]

    X | input[63]

    # Key schedule (127 ~ 0) , no cost

    # Round 4
    Sbox(eng, input[0:4])
    Sbox(eng, input[4:8])
    Sbox(eng, input[8:12])
    Sbox(eng, input[12:16])
    Sbox(eng, input[16:20])
    Sbox(eng, input[20:24])
    Sbox(eng, input[24:28])
    Sbox(eng, input[28:32])
    Sbox(eng, input[32:36])
    Sbox(eng, input[36:40])
    Sbox(eng, input[40:44])
    Sbox(eng, input[44:48])
    Sbox(eng, input[48:52])
    Sbox(eng, input[52:56])
    Sbox(eng, input[56:60])
    Sbox(eng, input[60:64])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x1f) (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[7]
    X | input[11]
    X | input[15]
    X | input[19]

    X | input[63]

    # Key schedule (127 ~ 0) , no cost

    # Round 5
    Sbox(eng, input[0:4])
    Sbox(eng, input[4:8])
    Sbox(eng, input[8:12])
    Sbox(eng, input[12:16])
    Sbox(eng, input[16:20])
    Sbox(eng, input[20:24])
    Sbox(eng, input[24:28])
    Sbox(eng, input[28:32])
    Sbox(eng, input[32:36])
    Sbox(eng, input[36:40])
    Sbox(eng, input[40:44])
    Sbox(eng, input[44:48])
    Sbox(eng, input[48:52])
    Sbox(eng, input[52:56])
    Sbox(eng, input[56:60])
    Sbox(eng, input[60:64])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x3e) 111110 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[7]
    X | input[11]
    X | input[15]
    X | input[19]
    X | input[23]

    X | input[63]

    # Key schedule (127 ~ 0) , no cost

    # Round 6
    Sbox(eng, input[0:4])
    Sbox(eng, input[4:8])
    Sbox(eng, input[8:12])
    Sbox(eng, input[12:16])
    Sbox(eng, input[16:20])
    Sbox(eng, input[20:24])
    Sbox(eng, input[24:28])
    Sbox(eng, input[28:32])
    Sbox(eng, input[32:36])
    Sbox(eng, input[36:40])
    Sbox(eng, input[40:44])
    Sbox(eng, input[44:48])
    Sbox(eng, input[48:52])
    Sbox(eng, input[52:56])
    Sbox(eng, input[56:60])
    Sbox(eng, input[60:64])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x3d) 111101 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[11]
    X | input[15]
    X | input[19]
    X | input[23]

    X | input[63]

    # Key schedule (127 ~ 0) , no cost

    # Round 7
    Sbox(eng, input[0:4])
    Sbox(eng, input[4:8])
    Sbox(eng, input[8:12])
    Sbox(eng, input[12:16])
    Sbox(eng, input[16:20])
    Sbox(eng, input[20:24])
    Sbox(eng, input[24:28])
    Sbox(eng, input[28:32])
    Sbox(eng, input[32:36])
    Sbox(eng, input[36:40])
    Sbox(eng, input[40:44])
    Sbox(eng, input[44:48])
    Sbox(eng, input[48:52])
    Sbox(eng, input[52:56])
    Sbox(eng, input[56:60])
    Sbox(eng, input[60:64])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x3b) 111011 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[7]
    X | input[15]
    X | input[19]
    X | input[23]

    X | input[63]

    # Key schedule (127 ~ 0) , no cost

    # Round 8
    Sbox(eng, input[0:4])
    Sbox(eng, input[4:8])
    Sbox(eng, input[8:12])
    Sbox(eng, input[12:16])
    Sbox(eng, input[16:20])
    Sbox(eng, input[20:24])
    Sbox(eng, input[24:28])
    Sbox(eng, input[28:32])
    Sbox(eng, input[32:36])
    Sbox(eng, input[36:40])
    Sbox(eng, input[40:44])
    Sbox(eng, input[44:48])
    Sbox(eng, input[48:52])
    Sbox(eng, input[52:56])
    Sbox(eng, input[56:60])
    Sbox(eng, input[60:64])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x37) 110111 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[7]
    X | input[11]
    X | input[19]
    X | input[23]

    X | input[63]

    # Key schedule (127 ~ 0) , no cost

    # Round 9
    Sbox(eng, input[0:4])
    Sbox(eng, input[4:8])
    Sbox(eng, input[8:12])
    Sbox(eng, input[12:16])
    Sbox(eng, input[16:20])
    Sbox(eng, input[20:24])
    Sbox(eng, input[24:28])
    Sbox(eng, input[28:32])
    Sbox(eng, input[32:36])
    Sbox(eng, input[36:40])
    Sbox(eng, input[40:44])
    Sbox(eng, input[44:48])
    Sbox(eng, input[48:52])
    Sbox(eng, input[52:56])
    Sbox(eng, input[56:60])
    Sbox(eng, input[60:64])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x2F) 101111 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[7]
    X | input[11]
    X | input[15]
    X | input[23]

    X | input[63]

    # Key schedule (127 ~ 0) , no cost

    #Round 10
    Sbox(eng, input[0:4])
    Sbox(eng, input[4:8])
    Sbox(eng, input[8:12])
    Sbox(eng, input[12:16])
    Sbox(eng, input[16:20])
    Sbox(eng, input[20:24])
    Sbox(eng, input[24:28])
    Sbox(eng, input[28:32])
    Sbox(eng, input[32:36])
    Sbox(eng, input[36:40])
    Sbox(eng, input[40:44])
    Sbox(eng, input[44:48])
    Sbox(eng, input[48:52])
    Sbox(eng, input[52:56])
    Sbox(eng, input[56:60])
    Sbox(eng, input[60:64])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x1E) 11110 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[7]
    X | input[11]
    X | input[15]
    X | input[19]

    X | input[63]

    # Key schedule (127 ~ 0) , no cost

    # Round 11
    Sbox(eng, input[0:4])
    Sbox(eng, input[4:8])
    Sbox(eng, input[8:12])
    Sbox(eng, input[12:16])
    Sbox(eng, input[16:20])
    Sbox(eng, input[20:24])
    Sbox(eng, input[24:28])
    Sbox(eng, input[28:32])
    Sbox(eng, input[32:36])
    Sbox(eng, input[36:40])
    Sbox(eng, input[40:44])
    Sbox(eng, input[44:48])
    Sbox(eng, input[48:52])
    Sbox(eng, input[52:56])
    Sbox(eng, input[56:60])
    Sbox(eng, input[60:64])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x3C) 111100 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[11]
    X | input[15]
    X | input[19]
    X | input[23]

    X | input[63]

    # Key schedule (127 ~ 0) , no cost

    # Round 12
    Sbox(eng, input[0:4])
    Sbox(eng, input[4:8])
    Sbox(eng, input[8:12])
    Sbox(eng, input[12:16])
    Sbox(eng, input[16:20])
    Sbox(eng, input[20:24])
    Sbox(eng, input[24:28])
    Sbox(eng, input[28:32])
    Sbox(eng, input[32:36])
    Sbox(eng, input[36:40])
    Sbox(eng, input[40:44])
    Sbox(eng, input[44:48])
    Sbox(eng, input[48:52])
    Sbox(eng, input[52:56])
    Sbox(eng, input[56:60])
    Sbox(eng, input[60:64])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x39) 111001 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[15]
    X | input[19]
    X | input[23]

    X | input[63]

    # Key schedule (127 ~ 0) , no cost

    # Round 13
    Sbox(eng, input[0:4])
    Sbox(eng, input[4:8])
    Sbox(eng, input[8:12])
    Sbox(eng, input[12:16])
    Sbox(eng, input[16:20])
    Sbox(eng, input[20:24])
    Sbox(eng, input[24:28])
    Sbox(eng, input[28:32])
    Sbox(eng, input[32:36])
    Sbox(eng, input[36:40])
    Sbox(eng, input[40:44])
    Sbox(eng, input[44:48])
    Sbox(eng, input[48:52])
    Sbox(eng, input[52:56])
    Sbox(eng, input[56:60])
    Sbox(eng, input[60:64])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x33) 110011 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[7]
    X | input[19]
    X | input[23]

    X | input[63]

    # Key schedule (127 ~ 0) , no cost

    # Round 14
    Sbox(eng, input[0:4])
    Sbox(eng, input[4:8])
    Sbox(eng, input[8:12])
    Sbox(eng, input[12:16])
    Sbox(eng, input[16:20])
    Sbox(eng, input[20:24])
    Sbox(eng, input[24:28])
    Sbox(eng, input[28:32])
    Sbox(eng, input[32:36])
    Sbox(eng, input[36:40])
    Sbox(eng, input[40:44])
    Sbox(eng, input[44:48])
    Sbox(eng, input[48:52])
    Sbox(eng, input[52:56])
    Sbox(eng, input[56:60])
    Sbox(eng, input[60:64])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x27) 100111 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[7]
    X | input[11]
    X | input[23]

    X | input[63]

    # Key schedule (127 ~ 0) , no cost

    # Round 15
    Sbox(eng, input[0:4])
    Sbox(eng, input[4:8])
    Sbox(eng, input[8:12])
    Sbox(eng, input[12:16])
    Sbox(eng, input[16:20])
    Sbox(eng, input[20:24])
    Sbox(eng, input[24:28])
    Sbox(eng, input[28:32])
    Sbox(eng, input[32:36])
    Sbox(eng, input[36:40])
    Sbox(eng, input[40:44])
    Sbox(eng, input[44:48])
    Sbox(eng, input[48:52])
    Sbox(eng, input[52:56])
    Sbox(eng, input[56:60])
    Sbox(eng, input[60:64])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x0E) 1110 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[7]
    X | input[11]
    X | input[15]

    X | input[63]

    # Key schedule (127 ~ 0) , no cost

    # Round 16
    Sbox(eng, input[0:4])
    Sbox(eng, input[4:8])
    Sbox(eng, input[8:12])
    Sbox(eng, input[12:16])
    Sbox(eng, input[16:20])
    Sbox(eng, input[20:24])
    Sbox(eng, input[24:28])
    Sbox(eng, input[28:32])
    Sbox(eng, input[32:36])
    Sbox(eng, input[36:40])
    Sbox(eng, input[40:44])
    Sbox(eng, input[44:48])
    Sbox(eng, input[48:52])
    Sbox(eng, input[52:56])
    Sbox(eng, input[56:60])
    Sbox(eng, input[60:64])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x1D) 11101 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[11]
    X | input[15]
    X | input[19]

    X | input[63]

    # Key schedule (127 ~ 0) , no cost

    # Round 17
    Sbox(eng, input[0:4])
    Sbox(eng, input[4:8])
    Sbox(eng, input[8:12])
    Sbox(eng, input[12:16])
    Sbox(eng, input[16:20])
    Sbox(eng, input[20:24])
    Sbox(eng, input[24:28])
    Sbox(eng, input[28:32])
    Sbox(eng, input[32:36])
    Sbox(eng, input[36:40])
    Sbox(eng, input[40:44])
    Sbox(eng, input[44:48])
    Sbox(eng, input[48:52])
    Sbox(eng, input[52:56])
    Sbox(eng, input[56:60])
    Sbox(eng, input[60:64])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x3A) 111010 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[7]
    X | input[15]
    X | input[19]
    X | input[23]

    X | input[63]

    # Key schedule (127 ~ 0) , no cost

    # Round 18
    Sbox(eng, input[0:4])
    Sbox(eng, input[4:8])
    Sbox(eng, input[8:12])
    Sbox(eng, input[12:16])
    Sbox(eng, input[16:20])
    Sbox(eng, input[20:24])
    Sbox(eng, input[24:28])
    Sbox(eng, input[28:32])
    Sbox(eng, input[32:36])
    Sbox(eng, input[36:40])
    Sbox(eng, input[40:44])
    Sbox(eng, input[44:48])
    Sbox(eng, input[48:52])
    Sbox(eng, input[52:56])
    Sbox(eng, input[56:60])
    Sbox(eng, input[60:64])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x35) 110101 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[11]
    X | input[19]
    X | input[23]

    X | input[63]

    # Key schedule (127 ~ 0) , no cost

    # Round 19
    Sbox(eng, input[0:4])
    Sbox(eng, input[4:8])
    Sbox(eng, input[8:12])
    Sbox(eng, input[12:16])
    Sbox(eng, input[16:20])
    Sbox(eng, input[20:24])
    Sbox(eng, input[24:28])
    Sbox(eng, input[28:32])
    Sbox(eng, input[32:36])
    Sbox(eng, input[36:40])
    Sbox(eng, input[40:44])
    Sbox(eng, input[44:48])
    Sbox(eng, input[48:52])
    Sbox(eng, input[52:56])
    Sbox(eng, input[56:60])
    Sbox(eng, input[60:64])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x2B) 101011 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[7]
    X | input[15]
    X | input[23]

    X | input[63]

    # Key schedule (127 ~ 0) , no cost

    # Round 20
    Sbox(eng, input[0:4])
    Sbox(eng, input[4:8])
    Sbox(eng, input[8:12])
    Sbox(eng, input[12:16])
    Sbox(eng, input[16:20])
    Sbox(eng, input[20:24])
    Sbox(eng, input[24:28])
    Sbox(eng, input[28:32])
    Sbox(eng, input[32:36])
    Sbox(eng, input[36:40])
    Sbox(eng, input[40:44])
    Sbox(eng, input[44:48])
    Sbox(eng, input[48:52])
    Sbox(eng, input[52:56])
    Sbox(eng, input[56:60])
    Sbox(eng, input[60:64])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x16) 10110 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[7]
    X | input[11]
    X | input[19]

    X | input[63]

    # Key schedule (127 ~ 0) , no cost

    # Round 21
    Sbox(eng, input[0:4])
    Sbox(eng, input[4:8])
    Sbox(eng, input[8:12])
    Sbox(eng, input[12:16])
    Sbox(eng, input[16:20])
    Sbox(eng, input[20:24])
    Sbox(eng, input[24:28])
    Sbox(eng, input[28:32])
    Sbox(eng, input[32:36])
    Sbox(eng, input[36:40])
    Sbox(eng, input[40:44])
    Sbox(eng, input[44:48])
    Sbox(eng, input[48:52])
    Sbox(eng, input[52:56])
    Sbox(eng, input[56:60])
    Sbox(eng, input[60:64])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x2C) 101100 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[11]
    X | input[15]
    X | input[23]

    X | input[63]

    # Key schedule (127 ~ 0) , no cost

    # Round 22
    Sbox(eng, input[0:4])
    Sbox(eng, input[4:8])
    Sbox(eng, input[8:12])
    Sbox(eng, input[12:16])
    Sbox(eng, input[16:20])
    Sbox(eng, input[20:24])
    Sbox(eng, input[24:28])
    Sbox(eng, input[28:32])
    Sbox(eng, input[32:36])
    Sbox(eng, input[36:40])
    Sbox(eng, input[40:44])
    Sbox(eng, input[44:48])
    Sbox(eng, input[48:52])
    Sbox(eng, input[52:56])
    Sbox(eng, input[56:60])
    Sbox(eng, input[60:64])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x18) 11000 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[15]
    X | input[19]

    X | input[63]

    # Key schedule (127 ~ 0) , no cost

    # Round 23
    Sbox(eng, input[0:4])
    Sbox(eng, input[4:8])
    Sbox(eng, input[8:12])
    Sbox(eng, input[12:16])
    Sbox(eng, input[16:20])
    Sbox(eng, input[20:24])
    Sbox(eng, input[24:28])
    Sbox(eng, input[28:32])
    Sbox(eng, input[32:36])
    Sbox(eng, input[36:40])
    Sbox(eng, input[40:44])
    Sbox(eng, input[44:48])
    Sbox(eng, input[48:52])
    Sbox(eng, input[52:56])
    Sbox(eng, input[56:60])
    Sbox(eng, input[60:64])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x30) 110000 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[19]
    X | input[23]

    X | input[63]

    # Key schedule (127 ~ 0) , no cost

    # Round 24
    Sbox(eng, input[0:4])
    Sbox(eng, input[4:8])
    Sbox(eng, input[8:12])
    Sbox(eng, input[12:16])
    Sbox(eng, input[16:20])
    Sbox(eng, input[20:24])
    Sbox(eng, input[24:28])
    Sbox(eng, input[28:32])
    Sbox(eng, input[32:36])
    Sbox(eng, input[36:40])
    Sbox(eng, input[40:44])
    Sbox(eng, input[44:48])
    Sbox(eng, input[48:52])
    Sbox(eng, input[52:56])
    Sbox(eng, input[56:60])
    Sbox(eng, input[60:64])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x21) 100001 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[23]

    X | input[63]

    # Key schedule (127 ~ 0) , no cost

    # Round 25
    Sbox(eng, input[0:4])
    Sbox(eng, input[4:8])
    Sbox(eng, input[8:12])
    Sbox(eng, input[12:16])
    Sbox(eng, input[16:20])
    Sbox(eng, input[20:24])
    Sbox(eng, input[24:28])
    Sbox(eng, input[28:32])
    Sbox(eng, input[32:36])
    Sbox(eng, input[36:40])
    Sbox(eng, input[40:44])
    Sbox(eng, input[44:48])
    Sbox(eng, input[48:52])
    Sbox(eng, input[52:56])
    Sbox(eng, input[56:60])
    Sbox(eng, input[60:64])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x02) 10 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[7]

    X | input[63]

    # Key schedule (127 ~ 0) , no cost

    # Round 26
    Sbox(eng, input[0:4])
    Sbox(eng, input[4:8])
    Sbox(eng, input[8:12])
    Sbox(eng, input[12:16])
    Sbox(eng, input[16:20])
    Sbox(eng, input[20:24])
    Sbox(eng, input[24:28])
    Sbox(eng, input[28:32])
    Sbox(eng, input[32:36])
    Sbox(eng, input[36:40])
    Sbox(eng, input[40:44])
    Sbox(eng, input[44:48])
    Sbox(eng, input[48:52])
    Sbox(eng, input[52:56])
    Sbox(eng, input[56:60])
    Sbox(eng, input[60:64])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x05) 101 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[11]

    X | input[63]

    # Key schedule (127 ~ 0) , no cost

    # Round 27
    Sbox(eng, input[0:4])
    Sbox(eng, input[4:8])
    Sbox(eng, input[8:12])
    Sbox(eng, input[12:16])
    Sbox(eng, input[16:20])
    Sbox(eng, input[20:24])
    Sbox(eng, input[24:28])
    Sbox(eng, input[28:32])
    Sbox(eng, input[32:36])
    Sbox(eng, input[36:40])
    Sbox(eng, input[40:44])
    Sbox(eng, input[44:48])
    Sbox(eng, input[48:52])
    Sbox(eng, input[52:56])
    Sbox(eng, input[56:60])
    Sbox(eng, input[60:64])

    # Permutation

    # (permutation not applied)
    Add_roundkey(eng, key, input)

    # Add constant (0x0B) 1011 (23, 19, 15, 11, 7, 3) + (63) (permutation not applied)
    X | input[3]
    X | input[7]
    X | input[15]

    X | input[63]

    # Key schedule (127 ~ 0) , no cost
    All(Measure) | input

    return int(input[0]), int(input[1]), int(input[2])

#Resource = ResourceCounter()
#eng = MainEngine(Resource)
#Enc(eng)
#print(Resource)

sim = ClassicalSimulator()
eng = MainEngine(sim)
print(Enc(eng))
eng.flush()


#drawing_engine = CircuitDrawer()
#eng = MainEngine(drawing_engine)

#Enc(eng)
#eng.flush()
#print(drawing_engine.get_latex())


