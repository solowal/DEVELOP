import math

from projectq import MainEngine
from projectq.ops import H, CNOT, Measure, Toffoli, X, All
from projectq.backends import CircuitDrawer, ResourceCounter
from projectq.meta import Loop, Compute, Uncompute, Control

def Round(eng, left, right, key) :

    for i in range (32):
        CNOT | (key[i], right[i])

    #Function F
    for i in range (32):
        Toffoli | (left[i], left[(i-5)%32], right[i])
        CNOT | (left[(i-1)%32], right[i])

    # input (left, right) -> output(right, left)

def fffffffd(eng, key):

    X | (key[0])

    for i in range(30):
        X | key[(i+2)]


def fffffffc(eng, key):

    for i in range(30):
        X | key[(i + 2)]

def KeySchedule_d(eng, key, t) :

    #Function F
    for i in range(32):
        Toffoli | (t[i], t[(i-5)%32], key[i])
        CNOT | (t[(i-1)%32], key[i])

    #Constant XORing
    fffffffd(eng, key)

def KeySchedule_c(eng, key, t) :

    #Function F
    for i in range(32):
        Toffoli | (t[i], t[(i-5)%32], key[i])
        CNOT | (t[(i-1)%32], key[i])

    #Constant XORing
    fffffffc(eng, key)

def Enc(eng):

    pt0 = eng.allocate_qureg(32)
    pt1 = eng.allocate_qureg(32)

    k0 = eng.allocate_qureg(32)
    k1 = eng.allocate_qureg(32)
    k2 = eng.allocate_qureg(32)
    k3 = eng.allocate_qureg(32)

    # Round 0
    Round(eng, pt0, pt1, k0)

    # Round 1
    Round(eng, pt1, pt0, k1)

    # Round 2
    Round(eng, pt0, pt1, k2)

    # Round 3
    Round(eng, pt1, pt0, k3)

    #Keyschedule
    KeySchedule_d(eng, k0, k1)
    #Round 4
    Round(eng, pt0, pt1, k0) #t3

    # Keyschedule
    KeySchedule_d(eng, k1, k2)
    # Round 5
    Round(eng, pt1, pt0, k1) #t4

    # Keyschedule
    KeySchedule_d(eng, k2, k3)
    # Round 6
    Round(eng, pt0, pt1, k2) #t5

    # Keyschedule
    KeySchedule_d(eng, k3, k0)
    # Round 7
    Round(eng, pt1, pt0, k3) #t6

    # Keyschedule
    KeySchedule_d(eng, k0, k1)
    # Round 8
    Round(eng, pt0, pt1, k0)  # t7

    # Keyschedule
    KeySchedule_d(eng, k1, k2)
    # Round 9
    Round(eng, pt1, pt0, k1)  # t8

    # Keyschedule
    KeySchedule_c(eng, k2, k3)
    # Round 10
    Round(eng, pt0, pt1, k2)  # t9

    # Keyschedule
    KeySchedule_c(eng, k3, k0)
    # Round 11
    Round(eng, pt1, pt0, k3)  # t10

    ###

    # Keyschedule
    KeySchedule_c(eng, k0, k1)
    # Round 12
    Round(eng, pt0, pt1, k0)  # t11

    # Keyschedule
    KeySchedule_c(eng, k1, k2)
    # Round 13
    Round(eng, pt1, pt0, k1)  # t12

    # Keyschedule
    KeySchedule_c(eng, k2, k3)
    # Round 14
    Round(eng, pt0, pt1, k2)  # t13

    # Keyschedule
    KeySchedule_d(eng, k3, k0)
    # Round 15
    Round(eng, pt1, pt0, k3)  # t14

    ###

    # Keyschedule
    KeySchedule_c(eng, k0, k1)
    # Round 16
    Round(eng, pt0, pt1, k0)  # t15

    # Keyschedule
    KeySchedule_c(eng, k1, k2)
    # Round 17
    Round(eng, pt1, pt0, k1)  # t16

    # Keyschedule
    KeySchedule_c(eng, k2, k3)
    # Round 18
    Round(eng, pt0, pt1, k2)  # t17

    # Keyschedule
    KeySchedule_c(eng, k3, k0)
    # Round 19
    Round(eng, pt1, pt0, k3)  # t18

    ###

    # Keyschedule
    KeySchedule_d(eng, k0, k1)
    # Round 20
    Round(eng, pt0, pt1, k0)  # t19

    # Keyschedule
    KeySchedule_d(eng, k1, k2)
    # Round 21
    Round(eng, pt1, pt0, k1)  # t20

    # Keyschedule
    KeySchedule_c(eng, k2, k3)
    # Round 22
    Round(eng, pt0, pt1, k2)  # t21

    # Keyschedule
    KeySchedule_c(eng, k3, k0)
    # Round 23
    Round(eng, pt1, pt0, k3)  # t22

    ###

    # Keyschedule
    KeySchedule_c(eng, k0, k1)
    # Round 24
    Round(eng, pt0, pt1, k0)  # t23

    # Keyschedule
    KeySchedule_d(eng, k1, k2)
    # Round 25
    Round(eng, pt1, pt0, k1)  # t24

    # Keyschedule
    KeySchedule_c(eng, k2, k3)
    # Round 26
    Round(eng, pt0, pt1, k2)  # t25

    # Keyschedule
    KeySchedule_d(eng, k3, k0)
    # Round 27
    Round(eng, pt1, pt0, k3)  # t26

    ###

    # Keyschedule
    KeySchedule_c(eng, k0, k1)
    # Round 28
    Round(eng, pt0, pt1, k0)  # t27

    # Keyschedule
    KeySchedule_c(eng, k1, k2)
    # Round 29
    Round(eng, pt1, pt0, k1)  # t28

    # Keyschedule
    KeySchedule_d(eng, k2, k3)
    # Round 30
    Round(eng, pt0, pt1, k2)  # t29

    # Keyschedule
    KeySchedule_d(eng, k3, k0)
    # Round 31
    Round(eng, pt1, pt0, k3)  # t30

    ###

    # Keyschedule
    KeySchedule_d(eng, k0, k1)
    # Round 32
    Round(eng, pt0, pt1, k0)  # t31

    # Keyschedule
    KeySchedule_d(eng, k1, k2)
    # Round 33
    Round(eng, pt1, pt0, k1)  # t32

    # Keyschedule
    KeySchedule_c(eng, k2, k3)
    # Round 34
    Round(eng, pt0, pt1, k2)  # t33

    # Keyschedule
    KeySchedule_d(eng, k3, k0)
    # Round 35
    Round(eng, pt1, pt0, k3)  # t34


    ###

    # Keyschedule
    KeySchedule_c(eng, k0, k1)
    # Round 36
    Round(eng, pt0, pt1, k0)  # t35

    # Keyschedule
    KeySchedule_c(eng, k1, k2)
    # Round 37
    Round(eng, pt1, pt0, k1)  # t36

    # Keyschedule
    KeySchedule_c(eng, k2, k3)
    # Round 38
    Round(eng, pt0, pt1, k2)  # t37

    # Keyschedule
    KeySchedule_d(eng, k3, k0)
    # Round 39
    Round(eng, pt1, pt0, k3)  # t38

    ###

    # Keyschedule
    KeySchedule_d(eng, k0, k1)
    # Round 40
    Round(eng, pt0, pt1, k0)  # t39

    # Keyschedule
    KeySchedule_d(eng, k1, k2)
    # Round 41
    Round(eng, pt1, pt0, k1)  # t40

    # Keyschedule
    KeySchedule_c(eng, k2, k3)
    # Round 42
    Round(eng, pt0, pt1, k2)  # t41

    # Keyschedule
    KeySchedule_c(eng, k3, k0)
    # Round 43
    Round(eng, pt1, pt0, k3)  # t42

Resource = ResourceCounter()
eng = MainEngine(Resource)
Enc(eng)
print(Resource)

eng.flush()