from projectq import MainEngine
from projectq.ops import CNOT, Measure, Toffoli, X
from projectq.backends import CircuitDrawer, ResourceCounter

#################### function #######################
def MAJ(eng,a,b,c):

    CNOT | (a, b)
    CNOT | (a, c)
    Toffoli | (c,  b, a)

def UMA(eng,a,b,c):

    Toffoli | (c,  b, a)
    CNOT | (a, c)
    CNOT | (c, b)

def Add(eng, a, b, a_first, a_last, b_first, b_last, c0):
    MAJ(eng, a[a_first], b[b_first], c0)
    for i in range (31):
        MAJ(eng, a[(i + a_first+1)%32], b[(i+b_first+1)%32], a[(a_first+i)%32])

    for i in range (31):
        UMA(eng, a[(a_last - i)%32], b[(b_last - i)%32], a[(a_last-1-i)%32])
    UMA(eng, a[a_first], b[b_first], c0)

######################  Encryption ######################

def KeySchedule(eng, a, t0, t1, t2, t3, t4, t5, start0, start1, start2, start3, start4, start5, i, c0):

    Add(eng, a, t0, (32-i) % 32, (31-i) % 32, start0, (start0-1) % 32, c0)

    Add(eng, a, t1, (31-i) % 32, (30-i) % 32, start1, (start1-1) % 32, c0)

    Add(eng, a, t2, (30-i) % 32, (29-i) % 32, start2, (start2-1) % 32, c0)

    Add(eng, a, t3, (29-i) % 32, (28-i) % 32, start3, (start3-1) % 32, c0)

    Add(eng, a, t4, (28 - i) % 32, (27 - i) % 32, start4, (start4-1) % 32, c0)

    Add(eng, a, t5, (27 - i) % 32, (26 - i) % 32, start5, (start5-1) % 32, c0)

def Encryption(eng, t0, t1, t2, t3, t4, t5, s0, s1, s2, s3, s4, s5, text0, text1, text2, text3, start0, start1, start2, start3, round, c0):
    for i in range(32):
        CNOT | (t5[(s5+i)%32], text3[(i+start3)%32])

    for i in range(32):
        CNOT | (t4[(s4+i)%32], text2[(i+start2)%32])

    Add(eng, text2, text3, start2, (start2-1)%32, start3, (start3-1)%32, c0)

    #Reverse
    for i in range(32):
        CNOT | (t4[(s4+i)%32], text2[(i+start2)%32])

    #text2 = text3 ( 3, 2 )


    for i in range(32):
        CNOT | (t3[(s3+i)%32], text2[(i+start2)%32])

    for i in range(32):
        CNOT | (t2[(s2+i)%32], text1[(i+start1)%32])

    Add(eng, text1, text2, start1, (start1-1)%32, start2, (start2-1)%32, c0)

    #Reverse
    for i in range(32):
        CNOT | (t2[(s2+i)%32], text1[(i+start1)%32])

    #text1 = text2 (5, 4)


    for i in range(32):
        CNOT | (t1[(s1+i)%32], text1[(i+start1)%32])

    for i in range(32):
        CNOT | (t0[(s0+i)%32], text0[(i+start0)%32])

    Add(eng, text0, text1, start0, (start0-1)%32, start1, (start1-1)%32, c0)

    #Reverse
    for i in range(32):
        CNOT | (t0[(s0+i)%32], text0[(i+start0)%32])

def Enc(eng):

    # Qubit
    t0 = eng.allocate_qureg(32)  #Key
    t1 = eng.allocate_qureg(32)
    t2 = eng.allocate_qureg(32)
    t3 = eng.allocate_qureg(32)
    t4 = eng.allocate_qureg(32)
    t5 = eng.allocate_qureg(32)
    t6 = eng.allocate_qureg(32)
    t7 = eng.allocate_qureg(32)

    a0 = eng.allocate_qureg(32)  #Constant (+130 X gate)
    a1 = eng.allocate_qureg(32)
    a2 = eng.allocate_qureg(32)
    a3 = eng.allocate_qureg(32)
    a4 = eng.allocate_qureg(32)
    a5 = eng.allocate_qureg(32)
    a6 = eng.allocate_qureg(32)
    a7 = eng.allocate_qureg(32)

    c0 = eng.allocate_qubit()    #carry qubit

    text0 = eng.allocate_qureg(32)  # plaintext --> ciphertext
    text1 = eng.allocate_qureg(32)
    text2 = eng.allocate_qureg(32)
    text3 = eng.allocate_qureg(32)

    #Round0
    KeySchedule(eng, a0, t0, t1, t2, t3, t4, t5, 0, 0, 0, 0, 0, 0, 0, c0)
    ################################ ENC(0), X(1) ############################################
    Encryption(eng, t0, t1, t2, t3, t4, t5, 31, 29,  26, 21, 19, 15, text0, text1, text2, text3, 0, 0, 0, 0, 0, c0)
    # text0 = text1 (23, 22)[-9] #text0 = text2      #text0 = text3
    # text1 = text2 (5, 4)  [+5] #text1 = text3      #text1 = text0
    # text2 = text3 (3, 2)  [+3] #text2 = text0      #text2 = text1
    # text3 = text0 (0, 31) [0]  #text3 = text1      #text3 = text2

    # Round1
    KeySchedule(eng, a1, t6, t7, t0, t1, t2, t3, 0, 0, 31, 29, 26, 21, 1, c0)
    Encryption(eng, t6, t7, t0, t1, t2, t3, 31, 29, 25, 18, 13, 4, text1, text2, text3, text0, 23, 5, 3, 0, 1, c0)
    # text0 = text1 (23, 22)[-9] #text0 = text2(28, 27)    #text0 = text3(31, 30)
    # text1 = text2 (5, 4)  [+5] #text1 = text3(8, 7)      #text1 = text0(8, 7)
    # text2 = text3 (3, 2)  [+3] #text2 = text0(3, 2)      #text2 = text1(26, 25)
    # text3 = text0 (0, 31) [0]  #text3 = text1(23, 22)    #text3 = text2(28, 27)

    # Round2
    KeySchedule(eng, a2, t4, t5, t6, t7, t0, t1, 19, 15, 31, 29, 25, 18, 2, c0)
    Encryption(eng, t4, t5, t6, t7, t0, t1, 18, 12, 25, 18, 12, 1, text2, text3, text0, text1, 28, 8, 3, 23, 2, c0)
    # text0 = text1 (23, 22)[-9] #text0 = text2(28, 27)    #text0 = text3(31, 30)
    # text1 = text2 (5, 4)  [+5] #text1 = text3(8, 7)      #text1 = text0(8, 7)
    # text2 = text3 (3, 2)  [+3] #text2 = text0(3, 2)      #text2 = text1(26, 25)
    # text3 = text0 (0, 31) [0]  #text3 = text1(23, 22)    #text3 = text2(28, 27)

    # Round3
    KeySchedule(eng, a3, t2, t3, t4, t5, t6, t7, 13, 14, 18, 12, 25, 18, 3, c0)
    Encryption(eng, t2, t3, t4, t5, t6, t7, 12, 11, 12, 1, 12, 1, text3, text0, text1, text2, 31, 8, 26, 28, 3, c0)
    # text0 = text1 (23, 22)[-9] #text0 = text2(28, 27)    #text0 = text3(31, 30) #text0 = text0 (31, 30)
    # text1 = text2 (5, 4)  [+5] #text1 = text3(8, 7)      #text1 = text0(8, 7)   #text1 = text1 (31, 30)
    # text2 = text3 (3, 2)  [+3] #text2 = text0(3, 2)      #text2 = text1(26, 25) #text2 = text2 (31, 30)
    # text3 = text0 (0, 31) [0]  #text3 = text1(23, 22)    #text3 = text2(28, 27)   #text3 = text3 (31, 30)

    #Round4
    KeySchedule(eng, a4, t0, t1, t2, t3, t4, t5, 12, 1, 12, 11, 12, 1, 4, c0)
    Encryption(eng, t0, t1, t2, t3, t4, t5, 11, 30, 6, 0, 31, 16, text0, text1, text2, text3, 31, 31, 31, 31, 4, c0)

    # text0 = text1 (23, 22)[-9] #text0 = text2(28, 27)    #text0 = text3(31, 30) #text0 = text0 (31, 30)
    # text1 = text2 (5, 4)  [+5] #text1 = text3(8, 7)      #text1 = text0(8, 7)   #text1 = text1 (31, 30)
    # text2 = text3 (3, 2)  [+3] #text2 = text0(3, 2)      #text2 = text1(26, 25) #text2 = text2 (31, 30)
    # text3 = text0 (0, 31) [0]  #text3 = text1(23, 22)    #text3 = text2(3, 2)   #text3 = text3 (31, 30)

    # text0 = text1 (22, 21)[-9]
    # text1 = text2 (4, 3)[+5]
    # text2 = text3 (2, 1)  [+3]
    # text3 = text0 (31, 30)[0]

    #Round5
    KeySchedule(eng, a5, t6, t7, t0, t1, t2, t3, 12, 1, 11, 30, 6, 0, 5, c0)
    Encryption(eng, t6, t7, t0, t1, t2, t3, 11, 30, 5, 19, 25, 15, text1, text2, text3, text0, 22, 4, 2, 31, 5, c0)
    # text0 = text1 (22, 21)[-9] #text0 = text2 (27, 26)
    # text1 = text2 (4, 3)[+5]   #text1 = text3 (7, 6)
    # text2 = text3 (2, 1)  [+3] #text2 = text0 (2, 1)
    # text3 = text0 (31, 30)[0]  #text3 = text1 (22, 21)

    #Round6
    KeySchedule(eng, a6, t4, t5, t6, t7, t0, t1, 31, 16, 11, 30, 5, 19, 6, c0)
    Encryption(eng, t4, t5, t6, t7, t0, t1, 30, 13, 5, 19, 24, 2, text2, text3, text0, text1, 27, 7, 2, 22, 6, c0)

    # text0 = text1 (22, 21)[-9] #text0 = text2 (27, 26)  #text0 = text3 (30,29)
    # text1 = text2 (11, 10)[+5] #text1 = text3 (7, 6)  #text1 = text0 (7, 6)
    # text2 = text3 (2, 1)  [+3] #text2 = text0 (2, 1)  #text2 = text1 (25, 24)
    # text3 = text0 (31, 30)[0]  #text3 = text1 (22, 21)#text3 = text2 (27, 26)

    #Round7
    KeySchedule(eng, a7, t2, t3, t4, t5, t6, t7, 25, 15, 30, 13, 5, 19, 7, c0)
    Encryption(eng, t2, t3, t4, t5, t6, t7, 24, 12, 24, 2, 24, 2, text3, text0, text1, text2, 30, 7, 25, 27, 7, c0)

    # text0 = text1 (22, 21)[-9] #text0 = text2 (27, 26)  #text0 = text3 (30,29) #text0 = text0 (30, 29)
    # text1 = text2 (11, 10)[+5] #text1 = text3 (7, 6)  #text1 = text0 (7, 6)  #text1 = text1 (30, 29)
    # text2 = text3 (2, 1)  [+3] #text2 = text0 (2, 1)  #text2 = text1 (25, 24)#text2 = text2 (30, 29)
    # text3 = text0 (31, 30)[0]  #text3 = text1 (22, 21)#text3 = text2 (27, 26)  #text3 = text3 (30, 29)

    #Round8
    KeySchedule(eng, a0, t0, t1, t2, t3, t4, t5, 24, 2, 24, 12, 24, 2, 8, c0)
    Encryption(eng, t0, t1, t2, t3, t4, t5, 23, 31, 18, 1, 11, 17, text0, text1, text2, text3, 30, 30, 30, 30, 8, c0)


##
    #Round9
    KeySchedule(eng, a1, t6, t7, t0, t1, t2, t3, 24, 2, 23, 31, 18, 1, 9, c0)
    Encryption(eng, t6, t7, t0, t1, t2, t3, 23, 31, 17, 20, 15, 16, text1, text2, text3, text0, 21, 3, 1, 30, 9, c0)
    # text0 = text1 (22, 21)[-9] #text0 = text2 (27, 26)
    # text1 = text2 (4, 3)[+5]   #text1 = text3 (7, 6)
    # text2 = text3 (2, 1)  [+3] #text2 = text0 (2, 1)
    # text3 = text0 (31, 30)[0]  #text3 = text1 (22, 21)

    #Round10
    KeySchedule(eng, a2, t4, t5, t6, t7, t0, t1, 11, 17, 23, 31, 17, 20, 10, c0)
    Encryption(eng, t4, t5, t6, t7, t0, t1, 10, 14, 17, 20, 4, 3, text2, text3, text0, text1, 26, 6, 1, 21, 10, c0)

    # text0 = text1 (22, 21)[-9] #text0 = text2 (27, 26)  #text0 = text3 (30,29)
    # text1 = text2 (11, 10)[+5] #text1 = text3 (7, 6)  #text1 = text0 (7, 6)
    # text2 = text3 (2, 1)  [+3] #text2 = text0 (2, 1)  #text2 = text1 (25, 24)
    # text3 = text0 (31, 30)[0]  #text3 = text1 (22, 21)#text3 = text2 (27, 26)

    #Round11
    KeySchedule(eng, a3, t2, t3, t4, t5, t6, t7, 15, 16, 10, 14, 17, 20, 11, c0)
    Encryption(eng, t2, t3, t4, t5, t6, t7, 14, 13, 4, 3, 4, 3, text3, text0, text1, text2, 29, 6, 24, 26, 11, c0)

    # text0 = text1 (22, 21)[-9] #text0 = text2 (27, 26)  #text0 = text3 (30,29) #text0 = text0 (30, 29)
    # text1 = text2 (11, 10)[+5] #text1 = text3 (7, 6)  #text1 = text0 (7, 6)  #text1 = text1 (30, 29)
    # text2 = text3 (2, 1)  [+3] #text2 = text0 (2, 1)  #text2 = text1 (25, 24)#text2 = text2 (30, 29)
    # text3 = text0 (31, 30)[0]  #text3 = text1 (22, 21)#text3 = text2 (27, 26)  #text3 = text3 (30, 29)

    #Round12
    KeySchedule(eng, a4, t0, t1, t2, t3, t4, t5, 4, 3, 14, 13, 4, 3, 12, c0)
    Encryption(eng, t0, t1, t2, t3, t4, t5, 3, 0, 8, 2, 23, 18, text0, text1, text2, text3, 29, 29, 29, 29, 12, c0)

##

    #Round13
    KeySchedule(eng, a5, t6, t7, t0, t1, t2, t3, 4, 3, 3, 0, 8, 2, 13, c0)
    Encryption(eng, t6, t7, t0, t1, t2, t3, 3, 0, 29, 21, 27, 17, text1, text2, text3, text0, 20, 2, 0, 29, 13, c0)
    # text0 = text1 (22, 21)[-9] #text0 = text2 (27, 26)
    # text1 = text2 (4, 3)[+5]   #text1 = text3 (7, 6)
    # text2 = text3 (2, 1)  [+3] #text2 = text0 (2, 1)
    # text3 = text0 (31, 30)[0]  #text3 = text1 (22, 21)

    #Round14
    KeySchedule(eng, a6, t4, t5, t6, t7, t0, t1, 23, 18, 3, 0, 29, 21, 14, c0)
    Encryption(eng, t4, t5, t6, t7, t0, t1, 22, 15, 29, 21, 16, 4, text2, text3, text0, text1, 25, 5, 0, 20, 14, c0)

    # text0 = text1 (22, 21)[-9] #text0 = text2 (27, 26)  #text0 = text3 (30,29)
    # text1 = text2 (11, 10)[+5] #text1 = text3 (7, 6)  #text1 = text0 (7, 6)
    # text2 = text3 (2, 1)  [+3] #text2 = text0 (2, 1)  #text2 = text1 (25, 24)
    # text3 = text0 (31, 30)[0]  #text3 = text1 (22, 21)#text3 = text2 (27, 26)

    #Round15
    KeySchedule(eng, a7, t2, t3, t4, t5, t6, t7, 27, 17, 22, 15, 29, 21, 15, c0)
    Encryption(eng, t2, t3, t4, t5, t6, t7, 26, 14, 16, 4, 16, 4, text3, text0, text1, text2, 28, 5, 23, 25, 15, c0)

    # text0 = text1 (22, 21)[-9] #text0 = text2 (27, 26)  #text0 = text3 (30,29) #text0 = text0 (30, 29)
    # text1 = text2 (11, 10)[+5] #text1 = text3 (7, 6)  #text1 = text0 (7, 6)  #text1 = text1 (30, 29)
    # text2 = text3 (2, 1)  [+3] #text2 = text0 (2, 1)  #text2 = text1 (25, 24)#text2 = text2 (30, 29)
    # text3 = text0 (31, 30)[0]  #text3 = text1 (22, 21)#text3 = text2 (27, 26)  #text3 = text3 (30, 29)

    #Round16
    KeySchedule(eng, a0, t0, t1, t2, t3, t4, t5, 16, 4, 26, 14, 16, 4, 16, c0)
    Encryption(eng, t0, t1, t2, t3, t4, t5, 15, 1, 20, 3, 3, 19, text0, text1, text2, text3, 28, 28, 28, 28, 16, c0)

##
    #Round17
    KeySchedule(eng, a1, t6, t7, t0, t1, t2, t3, 16, 4, 15, 1, 20, 3, 17, c0)
    Encryption(eng, t6, t7, t0, t1, t2, t3, 15, 1, 9, 22, 7, 18, text1, text2, text3, text0, 19, 1, 31, 28, 17, c0)
    # text0 = text1 (22, 21)[-9] #text0 = text2 (27, 26)
    # text1 = text2 (4, 3)[+5]   #text1 = text3 (7, 6)
    # text2 = text3 (2, 1)  [+3] #text2 = text0 (2, 1)
    # text3 = text0 (31, 30)[0]  #text3 = text1 (22, 21)

    #Round18
    KeySchedule(eng, a2, t4, t5, t6, t7, t0, t1, 3, 19, 15, 1, 9, 22, 18, c0)
    Encryption(eng, t4, t5, t6, t7, t0, t1, 22, 16, 9, 22, 28, 5, text2, text3, text0, text1, 24, 4, 31, 19, 18, c0)

    # text0 = text1 (22, 21)[-9] #text0 = text2 (27, 26)  #text0 = text3 (30,29)
    # text1 = text2 (11, 10)[+5] #text1 = text3 (7, 6)  #text1 = text0 (7, 6)
    # text2 = text3 (2, 1)  [+3] #text2 = text0 (2, 1)  #text2 = text1 (25, 24)
    # text3 = text0 (31, 30)[0]  #text3 = text1 (22, 21)#text3 = text2 (27, 26)

    #Round19
    KeySchedule(eng, a3, t2, t3, t4, t5, t6, t7, 7, 18, 22, 16, 9, 22, 19, c0)
    Encryption(eng, t2, t3, t4, t5, t6, t7, 6, 15, 16, 5, 28, 5, text3, text0, text1, text2, 27, 4, 22, 24, 19, c0)

    # text0 = text1 (22, 21)[-9] #text0 = text2 (27, 26)  #text0 = text3 (30,29) #text0 = text0 (30, 29)
    # text1 = text2 (11, 10)[+5] #text1 = text3 (7, 6)  #text1 = text0 (7, 6)  #text1 = text1 (30, 29)
    # text2 = text3 (2, 1)  [+3] #text2 = text0 (2, 1)  #text2 = text1 (25, 24)#text2 = text2 (30, 29)
    # text3 = text0 (31, 30)[0]  #text3 = text1 (22, 21)#text3 = text2 (27, 26)  #text3 = text3 (30, 29)

    #Round20
    KeySchedule(eng, a4, t0, t1, t2, t3, t4, t5, 28, 5, 6, 15, 16, 5, 20, c0)
    Encryption(eng, t0, t1, t2, t3, t4, t5, 27, 2, 0, 4, 3, 20, text0, text1, text2, text3, 27, 27, 27, 27, 20, c0)

##
    # Round21
    KeySchedule(eng, a5, t6, t7, t0, t1, t2, t3, 28, 5, 27, 2, 0, 4, 21, c0)
    Encryption(eng, t6, t7, t0, t1, t2, t3, 27, 2, 21, 23, 19, 19, text1, text2, text3, text0, 18, 0, 30, 27, 21, c0)
    # text0 = text1 (22, 21)[-9] #text0 = text2 (27, 26)
    # text1 = text2 (4, 3)[+5]   #text1 = text3 (7, 6)
    # text2 = text3 (2, 1)  [+3] #text2 = text0 (2, 1)
    # text3 = text0 (31, 30)[0]  #text3 = text1 (22, 21)

    # Round22
    KeySchedule(eng, a6, t4, t5, t6, t7, t0, t1, 3, 20, 27, 2, 21, 23, 22, c0)
    Encryption(eng, t4, t5, t6, t7, t0, t1, 2, 17, 21, 23, 8, 6, text2, text3, text0, text1, 23, 3, 30, 18, 22, c0)

    # text0 = text1 (22, 21)[-9] #text0 = text2 (27, 26)  #text0 = text3 (30,29)
    # text1 = text2 (11, 10)[+5] #text1 = text3 (7, 6)  #text1 = text0 (7, 6)
    # text2 = text3 (2, 1)  [+3] #text2 = text0 (2, 1)  #text2 = text1 (25, 24)
    # text3 = text0 (31, 30)[0]  #text3 = text1 (22, 21)#text3 = text2 (27, 26)

    # Round23
    KeySchedule(eng, a7, t2, t3, t4, t5, t6, t7, 19, 19, 2, 17, 21, 23, 23, c0)
    Encryption(eng, t2, t3, t4, t5, t6, t7, 18, 16, 28, 6, 8, 6, text3, text0, text1, text2, 26, 3, 21, 23, 23, c0)

    #Round24
    KeySchedule(eng, a0, t0, t1, t2, t3, t4, t5, 8, 6, 18, 16, 28, 6, 24, c0)
    Encryption(eng, t0, t1, t2, t3, t4, t5, 7, 3, 12, 5, 15, 21, text0, text1, text2, text3, 26, 26, 26, 26, 24, c0)

##

    # Round25
    KeySchedule(eng, a1, t6, t7, t0, t1, t2, t3, 8, 6, 7, 3, 12, 5, 25, c0)
    Encryption(eng, t6, t7, t0, t1, t2, t3, 7, 3, 1, 24, 31, 20, text1, text2, text3, text0, 17, 31, 29, 26, 25, c0)
    # text0 = text1 (22, 21)[-9] #text0 = text2 (27, 26)
    # text1 = text2 (4, 3)[+5]   #text1 = text3 (7, 6)
    # text2 = text3 (2, 1)  [+3] #text2 = text0 (2, 1)
    # text3 = text0 (31, 30)[0]  #text3 = text1 (22, 21)

    # Round26
    KeySchedule(eng, a2, t4, t5, t6, t7, t0, t1, 15, 21, 7, 3, 1, 24, 26, c0)
    Encryption(eng, t4, t5, t6, t7, t0, t1, 14, 18, 1, 24, 20, 7, text2, text3, text0, text1, 22, 2, 29, 17, 26, c0)

    # text0 = text1 (22, 21)[-9] #text0 = text2 (27, 26)  #text0 = text3 (30,29)
    # text1 = text2 (11, 10)[+5] #text1 = text3 (7, 6)  #text1 = text0 (7, 6)
    # text2 = text3 (2, 1)  [+3] #text2 = text0 (2, 1)  #text2 = text1 (25, 24)
    # text3 = text0 (31, 30)[0]  #text3 = text1 (22, 21)#text3 = text2 (27, 26)

    # Round27
    KeySchedule(eng, a3, t2, t3, t4, t5, t6, t7,  31, 20, 14, 18, 1, 24, 27, c0)
    Encryption(eng, t2, t3, t4, t5, t6, t7, 30, 17, 8, 7, 20, 7, text3, text0, text1, text2, 25, 2, 20, 22, 27, c0)

    # Round28
    KeySchedule(eng, a4, t0, t1, t2, t3, t4, t5, 20, 7, 30, 17, 8, 7, 28, c0)
    Encryption(eng, t0, t1, t2, t3, t4, t5, 19, 4, 24, 6, 27, 22, text0, text1, text2, text3, 25, 25, 25, 25, 28, c0)

##

    # Round29
    KeySchedule(eng, a5, t6, t7, t0, t1, t2, t3, 20, 7, 19, 4, 24, 6, 29, c0)
    Encryption(eng, t6, t7, t0, t1, t2, t3, 19, 4, 13, 25, 11, 21, text1, text2, text3, text0, 16, 30, 28, 25, 29, c0)
    # text0 = text1 (22, 21)[-9] #text0 = text2 (27, 26)
    # text1 = text2 (4, 3)[+5]   #text1 = text3 (7, 6)
    # text2 = text3 (2, 1)  [+3] #text2 = text0 (2, 1)
    # text3 = text0 (31, 30)[0]  #text3 = text1 (22, 21)

    # Round30
    KeySchedule(eng, a6, t4, t5, t6, t7, t0, t1, 27, 22, 19, 4, 13, 25, 30, c0)
    Encryption(eng, t4, t5, t6, t7, t0, t1, 26, 19, 13, 25, 0, 8, text2, text3, text0, text1, 21, 1, 28, 16, 30, c0)

    # text0 = text1 (22, 21)[-9] #text0 = text2 (27, 26)  #text0 = text3 (30,29)
    # text1 = text2 (11, 10)[+5] #text1 = text3 (7, 6)  #text1 = text0 (7, 6)
    # text2 = text3 (2, 1)  [+3] #text2 = text0 (2, 1)  #text2 = text1 (25, 24)
    # text3 = text0 (31, 30)[0]  #text3 = text1 (22, 21)#text3 = text2 (27, 26)

    # Round31
    KeySchedule(eng, a7, t2, t3, t4, t5, t6, t7, 11, 21, 26, 19, 13, 25, 31, c0)
    Encryption(eng, t2, t3, t4, t5, t6, t7, 10, 18, 20, 8, 0, 8, text3, text0, text1, text2, 24, 1, 19, 21, 31, c0)

    #cipher0 = text3(24, 23)
    #cipher1 = text0(1, 0)
    #cipher2 = text1(19, 18)
    #cipher3 = text2(21, 20)

    #END
Resource = ResourceCounter()
eng = MainEngine(Resource)
Enc(eng)
print(Resource)

eng.flush()

    # eng = MainEngine()
    # print(Enc(eng))

