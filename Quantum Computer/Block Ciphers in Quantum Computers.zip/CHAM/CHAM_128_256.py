import math

from projectq import MainEngine
from projectq.ops import H, CNOT, Measure, Toffoli, X, All
from projectq.backends import CircuitDrawer, ResourceCounter
from projectq.meta import Loop, Compute, Uncompute, Control


def CHAM64_128_ENC(eng):
    k0 = eng.allocate_qureg(32)
    k1 = eng.allocate_qureg(32)
    k2 = eng.allocate_qureg(32)
    k3 = eng.allocate_qureg(32)
    k4 = eng.allocate_qureg(32)
    k5 = eng.allocate_qureg(32)
    k6 = eng.allocate_qureg(32)
    k7 = eng.allocate_qureg(32)


    key_temp  = eng.allocate_qureg(11)

    c0 = eng.allocate_qubit()

    text0 = eng.allocate_qureg(32)
    text1 = eng.allocate_qureg(32)
    text2 = eng.allocate_qureg(32)
    text3 = eng.allocate_qureg(32)

    ctr = -1

    # Round#0
    ctr = Enc64_type_even_else1(eng, text0, 0, text1, 0, k0, ctr, key_temp, c0)
    # X[0] = X[1]
    # X[1] = X[2]
    # X[2] = X[3]
    # X[3] = X[0] start 15, end 14

    # Round#1
    ctr = Enc64_type_odd1(eng, text1, 0, text2, 0, k1, ctr, key_temp, c0)

    # X[0] = X[2]
    # X[1] = X[3]
    # X[2] = X[0] start 15, end 14
    # X[3] = X[1] start 8, end 7

    # Round#2
    ctr = Enc64_type_even_else1(eng, text2, 0, text3, 0, k2, ctr, key_temp, c0)

    # X[0] = X[3]
    # X[1] = X[0] start 15, end 14
    # X[2] = X[1] start 8, end 7
    # X[3] = X[2] start 15, end 14

    # Round#3
    ctr = Enc64_type_odd1(eng, text3, 0, text0, 31, k3, ctr, key_temp, c0)

    # X[0] = X[0] start 15, end 14
    # X[1] = X[1] start 8, end 7
    # X[2] = X[2] start 15, end 14
    # X[3] = X[3], start8, end 7

    ###########

    # Round#4
    ctr = Enc64_type_even_else1(eng, text0, 31, text1, 24, k4, ctr, key_temp, c0)

    # X[0] = X[1] start 8, end 7
    # X[1] = X[2] start 15, end 14
    # X[2] = X[3] start8, end 7
    # X[3] = X[0] start 14, end 13

    # Round 5
    ctr = Enc64_type_odd1(eng, text1, 24, text2, 31, k5, ctr, key_temp, c0)

    # X[0] = X[2] start 15, end 14
    # X[1] = X[3] sart 8, end 7
    # X[2] = X[0] start 14, end 13
    # X[3] = X[1] start 0, end 15

    # Round 6
    ctr = Enc64_type_even_else1(eng, text2, 31, text3, 24, k6, ctr, key_temp, c0)

    # X[0] = X[3] start 8, end 7
    # X[1] = X[0] start 14, end 13
    # X[2] = X[1] start 0, end 15
    # X[3] = X[2] start 14, end 13

    # Round 7
    ctr = Enc64_type_odd1(eng, text3, 24, text0, 30, k7, ctr, key_temp, c0)

    # X[0] = X[0] start 14, end 13
    # X[1] = X[1] start 0, end 15
    # X[2] = X[2] start 14, end 13
    # X[3] = X[3], start0, end 15

    # Round 8
    ctr = Enc64_type_even_else2(eng, text0, 30, text1, 16, k1, ctr, key_temp, c0)

    # X[0] = X[1] start 0, end 15
    # X[1] = X[2] start 14, end 13
    # X[2] = X[3] start 0, end 15
    # X[3] = X[0] start 13, end 12

    # Round 9
    ctr = Enc64_type_odd2(eng, text1, 16, text2, 30, k0, ctr, key_temp, c0)

    # X[0] = X[2] start 14, end 13
    # X[1] = X[3] start 0, end 15
    # X[2] = X[0] start 13, end 12
    # X[3] = X[1] start 8, end 7

    # Round 10
    ctr = Enc64_type_even_else2(eng, text2, 30, text3, 16, k3, ctr, key_temp, c0)

    # X[0] = X[3] start 0, end 15
    # X[1] = X[0] start 13, end 12
    # X[2] = X[1] start 8, end 7
    # X[3] = X[2] start 13, end 12

    # Round 11
    ctr = Enc64_type_odd2(eng, text3, 16, text0, 29, k2, ctr, key_temp, c0)

    # X[0] = X[0] start 13, end 12
    # X[1] = X[1] start 8, end 7
    # X[2] = X[2] start 13, end 12
    # X[3] = X[3], start 8, end 7

    ##########

    # Round 12
    ctr = Enc64_type_even_else2(eng, text0, 29, text1, 8, k5, ctr, key_temp, c0)

    # X[0] = X[1] start 8, end 7
    # X[1] = X[2] start 13, end 12
    # X[2] = X[3] start 8, end 7
    # X[3] = X[0] start 12, end 11

    # Round 13
    ctr = Enc64_type_odd2(eng, text1, 8, text2, 29, k4, ctr, key_temp, c0)

    # X[0] = X[2] start 13, end 12
    # X[1] = X[3] start 8, end 7
    # X[2] = X[0] start 12, end 11
    # X[3] = X[1] start 0, end 15

    # Round 14
    ctr = Enc64_type_even_else2(eng, text2, 29, text3, 8, k7, ctr, key_temp, c0)

    # X[0] = X[3] start 8, end 7
    # X[1] = X[0] start 12, end 11
    # X[2] = X[1] start 0, end 15
    # X[3] = X[2] start 12, end 11

    # Round 15
    ctr = Enc64_type_odd2(eng, text3, 8, text0, 28, k6, ctr, key_temp, c0)

    # X[0] = X[0] start 12, end 11
    # X[1] = X[1] start 0, end 15
    # X[2] = X[2] start 12, end 11
    # X[3] = X[3], start 0, end 15

    ###

    # Round #16
    ctr = Enc64_type_even_else1(eng, text0, 28, text1, 0, k0, ctr, key_temp, c0)
    # X[0] = X[1] start 0, end 15
    # X[1] = X[2] start 12, end 11
    # X[2] = X[3] start 0, 15
    # X[3] = X[0] start 11, end 10

    # Round#17
    ctr = Enc64_type_odd1(eng, text1, 0, text2, 28, k1, ctr, key_temp, c0)

    # X[0] = X[2] 12, 11
    # X[1] = X[3] 0, 15
    # X[2] = X[0] 11, 10
    # X[3] = X[1] 8, 7

    # Round#18
    ctr = Enc64_type_even_else1(eng, text2, 28, text3, 0, k2, ctr, key_temp, c0)

    # X[0] = X[3] 0, 15
    # X[1] = X[0] 11, 10
    # X[2] = X[1] 8, 7
    # X[3] = X[2] 11, 10

    # Round#19
    ctr = Enc64_type_odd1(eng, text3, 0, text0, 27, k3, ctr, key_temp, c0)

    # X[0] = X[0] 11, 10
    # X[1] = X[1] 8, 7
    # X[2] = X[2] 11, 10
    # X[3] = X[3] 8, 7

    ###########

    # Round#20
    ctr = Enc64_type_even_else1(eng, text0, 27, text1, 24, k4, ctr, key_temp, c0)

    # X[0] = X[1] 8, 7
    # X[1] = X[2] 11, 10
    # X[2] = X[3] 8, 7
    # X[3] = X[0] 10, 9

    # Round 21
    ctr = Enc64_type_odd1(eng, text1, 24, text2, 27, k5, ctr, key_temp, c0)

    # X[0] = X[2] 11, 10
    # X[1] = X[3] 8, 7
    # X[2] = X[0] 10, 9
    # X[3] = X[1] 0, 15

    # Round 22
    ctr = Enc64_type_even_else1(eng, text2, 27, text3, 24, k6, ctr, key_temp, c0)

    # X[0] = X[3] 8, 7
    # X[1] = X[0] 10, 9
    # X[2] = X[1] 0, 15
    # X[3] = X[2] 10, 9

    # Round 23
    ctr = Enc64_type_odd1(eng, text3, 24, text0, 26, k7, ctr, key_temp, c0)

    # X[0] = X[0] 10, 9
    # X[1] = X[1] 0, 15
    # X[2] = X[2] 10, 9
    # X[3] = X[3], 0, 15

    #####

    # Round 24
    ctr = Enc64_type_even_else2(eng, text0, 26, text1, 16, k1, ctr, key_temp, c0)

    # X[0] = X[1] 0, 15
    # X[1] = X[2] 10, 9
    # X[2] = X[3] 0, 15
    # X[3] = X[0] 9, 8

    # Round 25
    ctr = Enc64_type_odd2(eng, text1, 16, text2, 26, k0, ctr, key_temp, c0)

    # X[0] = X[2] 10, 9
    # X[1] = X[3] 0, 15
    # X[2] = X[0] 9, 8
    # X[3] = X[1] 8, 7

    # Round 26
    ctr = Enc64_type_even_else2(eng, text2, 26, text3, 16, k3, ctr, key_temp, c0)

    # X[0] = X[3] 0, 15
    # X[1] = X[0] 9, 8
    # X[2] = X[1] 8, 7
    # X[3] = X[2] 9, 8

    # Round 27
    ctr = Enc64_type_odd2(eng, text3, 16, text0, 25, k2, ctr, key_temp, c0)

    # X[0] = X[0] 9, 8
    # X[1] = X[1] 8, 7
    # X[2] = X[2] 9, 8
    # X[3] = X[3] 8, 7

    ##########

    # Round 28
    ctr = Enc64_type_even_else2(eng, text0, 25, text1, 8, k5, ctr, key_temp, c0)

    # X[0] = X[1] 8, 7
    # X[1] = X[2] 9, 8
    # X[2] = X[3] 8, 7
    # X[3] = X[0] 8, 7

    # Round 29
    ctr = Enc64_type_odd2(eng, text1, 8, text2, 25, k4, ctr, key_temp, c0)

    # X[0] = X[2] 9, 8
    # X[1] = X[3] 8, 7
    # X[2] = X[0] 8, 7
    # X[3] = X[1] 0, 15

    # Round 30
    ctr = Enc64_type_even_else2(eng, text2, 25, text3, 8, k7, ctr, key_temp, c0)

    # X[0] = X[3] 8, 7
    # X[1] = X[0] 8, 7
    # X[2] = X[1] 0, 15
    # X[3] = X[2] 8, 7

    # Round 31
    ctr = Enc64_type_odd2(eng, text3, 8, text0, 24, k6, ctr, key_temp, c0)

    # X[0] = X[0] 8, 7
    # X[1] = X[1] 0, 15
    # X[2] = X[2] 8, 7
    # X[3] = X[3] 0, 15

    ###
    # Round#32
    ctr = Enc64_type_even_else1(eng, text0, 24, text1, 0, k0, ctr, key_temp, c0)
    # X[0] = X[1]
    # X[1] = X[2]
    # X[2] = X[3]
    # X[3] = X[0] start 15, end 14

    # Round33
    ctr = Enc64_type_odd1(eng, text1, 0, text2, 24, k1, ctr, key_temp, c0)

    # X[0] = X[2]
    # X[1] = X[3]
    # X[2] = X[0] start 15, end 14
    # X[3] = X[1] start 8, end 7

    # Round#34
    ctr = Enc64_type_even_else1(eng, text2, 24, text3, 0, k2, ctr, key_temp, c0)

    # X[0] = X[3]
    # X[1] = X[0] start 15, end 14
    # X[2] = X[1] start 8, end 7
    # X[3] = X[2] start 15, end 14

    # Round#35
    ctr = Enc64_type_odd1(eng, text3, 0, text0, 23, k3, ctr, key_temp, c0)

    # X[0] = X[0] start 15, end 14
    # X[1] = X[1] start 8, end 7
    # X[2] = X[2] start 15, end 14
    # X[3] = X[3], start8, end 7

    ###########

    # Round#36
    ctr = Enc64_type_even_else1(eng, text0, 23, text1, 24, k4, ctr, key_temp, c0)

    # X[0] = X[1] start 8, end 7
    # X[1] = X[2] start 15, end 14
    # X[2] = X[3] start8, end 7
    # X[3] = X[0] start 14, end 13

    # Round 37
    ctr = Enc64_type_odd1(eng, text1, 24, text2, 23, k5, ctr, key_temp, c0)

    # X[0] = X[2] start 15, end 14
    # X[1] = X[3] sart 8, end 7
    # X[2] = X[0] start 14, end 13
    # X[3] = X[1] start 0, end 15

    # Round 38
    ctr = Enc64_type_even_else1(eng, text2, 23, text3, 24, k6, ctr, key_temp, c0)

    # X[0] = X[3] start 8, end 7
    # X[1] = X[0] start 14, end 13
    # X[2] = X[1] start 0, end 15
    # X[3] = X[2] start 14, end 13

    # Round 39
    ctr = Enc64_type_odd1(eng, text3, 24, text0, 22, k7, ctr, key_temp, c0)

    # X[0] = X[0] start 14, end 13
    # X[1] = X[1] start 0, end 15
    # X[2] = X[2] start 14, end 13
    # X[3] = X[3], start0, end 15

    # Round 40
    ctr = Enc64_type_even_else2(eng, text0, 22, text1, 16, k1, ctr, key_temp, c0)

    # X[0] = X[1] start 0, end 15
    # X[1] = X[2] start 14, end 13
    # X[2] = X[3] start 0, end 15
    # X[3] = X[0] start 13, end 12

    # Round 41
    ctr = Enc64_type_odd2(eng, text1, 16, text2, 22, k0, ctr, key_temp, c0)

    # X[0] = X[2] start 14, end 13
    # X[1] = X[3] start 0, end 15
    # X[2] = X[0] start 13, end 12
    # X[3] = X[1] start 8, end 7

    # Round 42
    ctr = Enc64_type_even_else2(eng, text2, 22, text3, 16, k3, ctr, key_temp, c0)

    # X[0] = X[3] start 0, end 15
    # X[1] = X[0] start 13, end 12
    # X[2] = X[1] start 8, end 7
    # X[3] = X[2] start 13, end 12

    # Round 43
    ctr = Enc64_type_odd2(eng, text3, 16, text0, 21, k2, ctr, key_temp, c0)

    # X[0] = X[0] start 13, end 12
    # X[1] = X[1] start 8, end 7
    # X[2] = X[2] start 13, end 12
    # X[3] = X[3], start 8, end 7

    ##########

    # Round 44
    ctr = Enc64_type_even_else2(eng, text0, 21, text1, 8, k5, ctr, key_temp, c0)

    # X[0] = X[1] start 8, end 7
    # X[1] = X[2] start 13, end 12
    # X[2] = X[3] start 8, end 7
    # X[3] = X[0] start 12, end 11

    # Round 45
    ctr = Enc64_type_odd2(eng, text1, 8, text2, 21, k4, ctr, key_temp, c0)

    # X[0] = X[2] start 13, end 12
    # X[1] = X[3] start 8, end 7
    # X[2] = X[0] start 12, end 11
    # X[3] = X[1] start 0, end 15

    # Round 46
    ctr = Enc64_type_even_else2(eng, text2, 21, text3, 8, k7, ctr, key_temp, c0)

    # X[0] = X[3] start 8, end 7
    # X[1] = X[0] start 12, end 11
    # X[2] = X[1] start 0, end 15
    # X[3] = X[2] start 12, end 11

    # Round 47
    ctr = Enc64_type_odd2(eng, text3, 8, text0, 20, k6, ctr, key_temp, c0)

    # X[0] = X[0] start 12, end 11
    # X[1] = X[1] start 0, end 15
    # X[2] = X[2] start 12, end 11
    # X[3] = X[3], start 0, end 15

    ####

    # Round 48
    ctr = Enc64_type_even_else1(eng, text0, 20, text1, 0, k0, ctr, key_temp, c0)
    # X[0] = X[1]
    # X[1] = X[2]
    # X[2] = X[3]
    # X[3] = X[0] start 15, end 14

    # Round 49
    ctr = Enc64_type_odd1(eng, text1, 0, text2, 20, k1, ctr, key_temp, c0)

    # X[0] = X[2]
    # X[1] = X[3]
    # X[2] = X[0] start 15, end 14
    # X[3] = X[1] start 8, end 7

    # Round 50
    ctr = Enc64_type_even_else1(eng, text2, 20, text3, 0, k2, ctr, key_temp, c0)

    # X[0] = X[3]
    # X[1] = X[0] start 15, end 14
    # X[2] = X[1] start 8, end 7
    # X[3] = X[2] start 15, end 14

    # Round 51
    ctr = Enc64_type_odd1(eng, text3, 0, text0, 19, k3, ctr, key_temp, c0)

    # X[0] = X[0] start 15, end 14
    # X[1] = X[1] start 8, end 7
    # X[2] = X[2] start 15, end 14
    # X[3] = X[3], start8, end 7

    ###########

    # Round 52
    ctr = Enc64_type_even_else1(eng, text0, 19, text1, 24, k4, ctr, key_temp, c0)

    # X[0] = X[1] start 8, end 7
    # X[1] = X[2] start 15, end 14
    # X[2] = X[3] start8, end 7
    # X[3] = X[0] start 14, end 13

    # Round 53
    ctr = Enc64_type_odd1(eng, text1, 24, text2, 19, k5, ctr, key_temp, c0)

    # X[0] = X[2] start 15, end 14
    # X[1] = X[3] sart 8, end 7
    # X[2] = X[0] start 14, end 13
    # X[3] = X[1] start 0, end 15

    # Round 54
    ctr = Enc64_type_even_else1(eng, text2, 19, text3, 24, k6, ctr, key_temp, c0)

    # X[0] = X[3] start 8, end 7
    # X[1] = X[0] start 14, end 13
    # X[2] = X[1] start 0, end 15
    # X[3] = X[2] start 14, end 13

    # Round 55
    ctr = Enc64_type_odd1(eng, text3, 24, text0, 18, k7, ctr, key_temp, c0)

    # X[0] = X[0] start 14, end 13
    # X[1] = X[1] start 0, end 15
    # X[2] = X[2] start 14, end 13
    # X[3] = X[3], start0, end 15

    # Round 56
    ctr = Enc64_type_even_else2(eng, text0, 18, text1, 16, k1, ctr, key_temp, c0)

    # X[0] = X[1] start 0, end 15
    # X[1] = X[2] start 14, end 13
    # X[2] = X[3] start 0, end 15
    # X[3] = X[0] start 13, end 12

    # Round 57
    ctr = Enc64_type_odd2(eng, text1, 16, text2, 18, k0, ctr, key_temp, c0)

    # X[0] = X[2] start 14, end 13
    # X[1] = X[3] start 0, end 15
    # X[2] = X[0] start 13, end 12
    # X[3] = X[1] start 8, end 7

    # Round 58
    ctr = Enc64_type_even_else2(eng, text2, 18, text3, 16, k3, ctr, key_temp, c0)

    # X[0] = X[3] start 0, end 15
    # X[1] = X[0] start 13, end 12
    # X[2] = X[1] start 8, end 7
    # X[3] = X[2] start 13, end 12

    # Round 59
    ctr = Enc64_type_odd2(eng, text3, 16, text0, 17, k2, ctr, key_temp, c0)

    # X[0] = X[0] start 13, end 12
    # X[1] = X[1] start 8, end 7
    # X[2] = X[2] start 13, end 12
    # X[3] = X[3], start 8, end 7

    ##########

    # Round 60
    ctr = Enc64_type_even_else2(eng, text0, 17, text1, 8, k5, ctr, key_temp, c0)

    # X[0] = X[1] start 8, end 7
    # X[1] = X[2] start 13, end 12
    # X[2] = X[3] start 8, end 7
    # X[3] = X[0] start 12, end 11

    # Round 61
    ctr = Enc64_type_odd2(eng, text1, 8, text2, 17, k4, ctr, key_temp, c0)

    # X[0] = X[2] start 13, end 12
    # X[1] = X[3] start 8, end 7
    # X[2] = X[0] start 12, end 11
    # X[3] = X[1] start 0, end 15

    # Round 62
    ctr = Enc64_type_even_else2(eng, text2, 17, text3, 8, k7, ctr, key_temp, c0)

    # X[0] = X[3] start 8, end 7
    # X[1] = X[0] start 12, end 11
    # X[2] = X[1] start 0, end 15
    # X[3] = X[2] start 12, end 11

    # Round 63
    ctr = Enc64_type_odd2(eng, text3, 8, text0, 16, k6, ctr, key_temp, c0)

    # X[0] = X[0] start 12, end 11
    # X[1] = X[1] start 0, end 15
    # X[2] = X[2] start 12, end 11
    # X[3] = X[3], start 0, end 15

    ##

    # Round 64
    ctr = Enc64_type_even_else1(eng, text0, 16, text1, 0, k0, ctr, key_temp, c0)
    # X[0] = X[1]
    # X[1] = X[2]
    # X[2] = X[3]
    # X[3] = X[0] start 15, end 14

    # Round 65
    ctr = Enc64_type_odd1(eng, text1, 0, text2, 16, k1, ctr, key_temp, c0)

    # X[0] = X[2]
    # X[1] = X[3]
    # X[2] = X[0] start 15, end 14
    # X[3] = X[1] start 8, end 7

    # Round 66
    ctr = Enc64_type_even_else1(eng, text2, 16, text3, 0, k2, ctr, key_temp, c0)

    # X[0] = X[3]
    # X[1] = X[0] start 15, end 14
    # X[2] = X[1] start 8, end 7
    # X[3] = X[2] start 15, end 14

    # Round 67
    ctr = Enc64_type_odd1(eng, text3, 0, text0, 15, k3, ctr, key_temp, c0)

    # X[0] = X[0] start 15, end 14
    # X[1] = X[1] start 8, end 7
    # X[2] = X[2] start 15, end 14
    # X[3] = X[3], start8, end 7

    ###########

    # Round 68
    ctr = Enc64_type_even_else1(eng, text0, 15, text1, 24, k4, ctr, key_temp, c0)

    # X[0] = X[1] start 8, end 7
    # X[1] = X[2] start 15, end 14
    # X[2] = X[3] start8, end 7
    # X[3] = X[0] start 14, end 13

    # Round 69
    ctr = Enc64_type_odd1(eng, text1, 24, text2, 15, k5, ctr, key_temp, c0)

    # X[0] = X[2] start 15, end 14
    # X[1] = X[3] sart 8, end 7
    # X[2] = X[0] start 14, end 13
    # X[3] = X[1] start 0, end 15

    # Round 70
    ctr = Enc64_type_even_else1(eng, text2, 15, text3, 24, k6, ctr, key_temp, c0)

    # X[0] = X[3] start 8, end 7
    # X[1] = X[0] start 14, end 13
    # X[2] = X[1] start 0, end 15
    # X[3] = X[2] start 14, end 13

    # Round 71
    ctr = Enc64_type_odd1(eng, text3, 24, text0, 14, k7, ctr, key_temp, c0)

    # X[0] = X[0] start 14, end 13
    # X[1] = X[1] start 0, end 15
    # X[2] = X[2] start 14, end 13
    # X[3] = X[3], start0, end 15

    # Round 72
    ctr = Enc64_type_even_else2(eng, text0, 14, text1, 16, k1, ctr, key_temp, c0)

    # X[0] = X[1] start 0, end 15
    # X[1] = X[2] start 14, end 13
    # X[2] = X[3] start 0, end 15
    # X[3] = X[0] start 13, end 12

    # Round 73
    ctr = Enc64_type_odd2(eng, text1, 16, text2, 14, k0, ctr, key_temp, c0)

    # X[0] = X[2] start 14, end 13
    # X[1] = X[3] start 0, end 15
    # X[2] = X[0] start 13, end 12
    # X[3] = X[1] start 8, end 7

    # Round 74
    ctr = Enc64_type_even_else2(eng, text2, 14, text3, 16, k3, ctr, key_temp, c0)

    # X[0] = X[3] start 0, end 15
    # X[1] = X[0] start 13, end 12
    # X[2] = X[1] start 8, end 7
    # X[3] = X[2] start 13, end 12

    # Round 75
    ctr = Enc64_type_odd2(eng, text3, 16, text0, 13, k2, ctr, key_temp, c0)

    # X[0] = X[0] start 13, end 12
    # X[1] = X[1] start 8, end 7
    # X[2] = X[2] start 13, end 12
    # X[3] = X[3], start 8, end 7

    ##########

    # Round 76
    ctr = Enc64_type_even_else2(eng, text0, 13, text1, 8, k5, ctr, key_temp, c0)

    # X[0] = X[1] start 8, end 7
    # X[1] = X[2] start 13, end 12
    # X[2] = X[3] start 8, end 7
    # X[3] = X[0] start 12, end 11

    # Round 77
    ctr = Enc64_type_odd2(eng, text1, 8, text2, 13, k4, ctr, key_temp, c0)

    # X[0] = X[2] start 13, end 12
    # X[1] = X[3] start 8, end 7
    # X[2] = X[0] start 12, end 11
    # X[3] = X[1] start 0, end 15

    # Round 78
    ctr = Enc64_type_even_else2(eng, text2, 13, text3, 8, k7, ctr, key_temp, c0)

    # X[0] = X[3] start 8, end 7
    # X[1] = X[0] start 12, end 11
    # X[2] = X[1] start 0, end 15
    # X[3] = X[2] start 12, end 11

    # Round 79
    ctr = Enc64_type_odd2(eng, text3, 8, text0, 12, k6, ctr, key_temp, c0)

    # X[0] = X[0] start 12, end 11
    # X[1] = X[1] start 0, end 15
    # X[2] = X[2] start 12, end 11
    # X[3] = X[3], start 0, end 15

    ###

    # Round 80
    ctr = Enc64_type_even_else1(eng, text0, 12, text1, 0, k0, ctr, key_temp, c0)
    # X[0] = X[1]
    # X[1] = X[2]
    # X[2] = X[3]
    # X[3] = X[0] start 15, end 14

    # Round 81
    ctr = Enc64_type_odd1(eng, text1, 0, text2, 12, k1, ctr, key_temp, c0)

    # X[0] = X[2]
    # X[1] = X[3]
    # X[2] = X[0] start 15, end 14
    # X[3] = X[1] start 8, end 7

    # Round 82
    ctr = Enc64_type_even_else1(eng, text2, 12, text3, 0, k2, ctr, key_temp, c0)

    # X[0] = X[3]
    # X[1] = X[0] start 15, end 14
    # X[2] = X[1] start 8, end 7
    # X[3] = X[2] start 15, end 14

    # Round 83
    ctr = Enc64_type_odd1(eng, text3, 0, text0, 11, k3, ctr, key_temp, c0)

    # X[0] = X[0] start 15, end 14
    # X[1] = X[1] start 8, end 7
    # X[2] = X[2] start 15, end 14
    # X[3] = X[3], start8, end 7

    ###########

    # Round 84
    ctr = Enc64_type_even_else1(eng, text0, 11, text1, 24, k4, ctr, key_temp, c0)

    # X[0] = X[1] start 8, end 7
    # X[1] = X[2] start 15, end 14
    # X[2] = X[3] start8, end 7
    # X[3] = X[0] start 14, end 13

    # Round 85
    ctr = Enc64_type_odd1(eng, text1, 24, text2, 11, k5, ctr, key_temp, c0)

    # X[0] = X[2] start 15, end 14
    # X[1] = X[3] sart 8, end 7
    # X[2] = X[0] start 14, end 13
    # X[3] = X[1] start 0, end 15

    # Round 86
    ctr = Enc64_type_even_else1(eng, text2, 11, text3, 24, k6, ctr, key_temp, c0)

    # X[0] = X[3] start 8, end 7
    # X[1] = X[0] start 14, end 13
    # X[2] = X[1] start 0, end 15
    # X[3] = X[2] start 14, end 13

    # Round 87
    ctr = Enc64_type_odd1(eng, text3, 24, text0, 10, k7, ctr, key_temp, c0)

    # X[0] = X[0] start 14, end 13
    # X[1] = X[1] start 0, end 15
    # X[2] = X[2] start 14, end 13
    # X[3] = X[3], start0, end 15

    # Round 88
    ctr = Enc64_type_even_else2(eng, text0, 10, text1, 16, k1, ctr, key_temp, c0)

    # X[0] = X[1] start 0, end 15
    # X[1] = X[2] start 14, end 13
    # X[2] = X[3] start 0, end 15
    # X[3] = X[0] start 13, end 12

    # Round 89
    ctr = Enc64_type_odd2(eng, text1, 16, text2, 10, k0, ctr, key_temp, c0)

    # X[0] = X[2] start 14, end 13
    # X[1] = X[3] start 0, end 15
    # X[2] = X[0] start 13, end 12
    # X[3] = X[1] start 8, end 7

    # Round 90
    ctr = Enc64_type_even_else2(eng, text2, 10, text3, 16, k3, ctr, key_temp, c0)

    # X[0] = X[3] start 0, end 15
    # X[1] = X[0] start 13, end 12
    # X[2] = X[1] start 8, end 7
    # X[3] = X[2] start 13, end 12

    # Round 91
    ctr = Enc64_type_odd2(eng, text3, 16, text0, 9, k2, ctr, key_temp, c0)

    # X[0] = X[0] start 13, end 12
    # X[1] = X[1] start 8, end 7
    # X[2] = X[2] start 13, end 12
    # X[3] = X[3], start 8, end 7

    ##########

    # Round 92
    ctr = Enc64_type_even_else2(eng, text0, 9, text1, 8, k5, ctr, key_temp, c0)

    # X[0] = X[1] start 8, end 7
    # X[1] = X[2] start 9, end 8
    # X[2] = X[3]
    # X[3] = X[0]

    # Round 93
    ctr = Enc64_type_odd2(eng, text1, 8, text2, 9, k4, ctr, key_temp, c0)

    # X[0] = X[2] start 9, end 8
    # X[1] = X[3] start 8, end 7
    # X[2] = X[0]
    # X[3] = X[1] start 0, end 31

    # Round 94
    ctr = Enc64_type_even_else2(eng, text2, 9, text3, 8, k7, ctr, key_temp, c0)

    # X[0] = X[3] start 8, end 7
    # X[1] = X[0] start 8, end 7
    # X[2] = X[1] start 0, 31
    # X[3] = X[2] start 8, end 7

    # Round 95
    ctr = Enc64_type_odd2(eng, text3, 8, text0, 8, k6, ctr, key_temp, c0)

    # X[0] = X[0] start 8, end 7
    # X[1] = X[1] start 0, end 31
    # X[2] = X[2] start 8, end 7
    # X[3] = X[3] start 0, end 31

    # END

# ...

# Round#90



def KeyGen64_type_0to7(eng, key, key_temp): #72 CNOT

    for i in range(8):
        CNOT | (key[31 - i], key_temp[i])

    for i in range(24):
        CNOT | (key[30 - i], key[31 - i])
        CNOT | (key[23 - i], key[31 - i])

    for i in range(7):
        CNOT | (key[6 - i], key[7 - i])

    for i in range(8):
        CNOT | (key_temp[i], key[7 - i])

    CNOT | (key_temp[0], key[0])


def KeyGen64_type_0to7_reverse(eng, key, key_temp):

    CNOT | (key_temp[0], key[0])

    for i in range(8):
        CNOT | (key_temp[i], key[7-i])

    for i in range(7):
        CNOT | (key[i], key[i+1])

    for i in range(24):
        CNOT | (key[i+7], key[i+8])
        CNOT | (key[i], key[i+8])

    for i in range(8):
        CNOT | (key[31-i], key_temp[i])


def KeyGen64_type_8to15(eng, key, key_temp): #75CNOT

    for i in range(11):
        CNOT | (key[31 - i], key_temp[i])

    for i in range(21):
        CNOT | (key[30 - i], key[31 - i])
        CNOT | (key[20 - i], key[31 - i])

    for i in range(10):
        CNOT | (key[9 - i], key[10 - i])

    for i in range(11):
        CNOT | (key_temp[i], key[10 - i])

    CNOT | (key_temp[0], key[0])

def KeyGen64_type_8to15_reverse(eng, key, key_temp):

    CNOT | (key_temp[0], key[0])

    for i in range(11):
        CNOT | (key_temp[i], key[10 - i])

    for i in range(10):
        CNOT | (key[i], key[i+1])

    for i in range(21):
        CNOT | (key[i+10], key[i+11])
        CNOT | (key[i], key[i+11])

    for i in range(11):
        CNOT | (key[31 - i], key_temp[i])

def Enc64_type_odd1(eng, text0, text0_start, text1, text1_start, r_key, ctr, key_temp, c0):  # 0to7 key
    ctr = ctr + 1
    KeyGen64_type_0to7(eng, r_key, key_temp);  # key gen

    for i in range(32):
        CNOT | (r_key[i], text1[(text1_start-1+i)%32] ) #Left 1
    # CTR
    CTR_XOR(eng, text0, ctr, text0_start)

    # Addition with (ROL8 -- omitted)
    ADD(eng, text1, (text1_start-1)%32, (text1_start-2)%32, text0, text0_start, (text0_start-1)%32, c0)

    # Reversible (Optimization)
    for i in range(32):
        CNOT | (r_key[i], text1[(text1_start - 1 + i) % 32])  # Left 1

    KeyGen64_type_0to7_reverse(eng, r_key, key_temp);  # key reverse

    return ctr


def Enc64_type_even_else1(eng, text0, text0_start, text1, text1_start, r_key, ctr, key_temp, c0):
    ctr = ctr + 1
    KeyGen64_type_0to7(eng, r_key, key_temp);  # key gen

    for i in range(32):
        CNOT | (r_key[i], text1[(text1_start-8+i) % 32])  # Left 8
    # CTR
    CTR_XOR(eng, text0, ctr, text0_start)

    # Addition with (ROL1 -- omitted)
    ADD(eng, text1, (text1_start-8)%32, (text1_start-9)%32, text0, text0_start, (text0_start-1)%32, c0)

    # Reversible (Optimization)
    for i in range(32):
        CNOT | (r_key[i], text1[(text1_start - 8 + i) % 32])  # Left 8

    KeyGen64_type_0to7_reverse(eng, r_key, key_temp);  # key gen
    return ctr


def Enc64_type_odd2(eng, text0, text0_start, text1, text1_start, r_key, ctr, key_temp, c0): #8to15 key
    ctr = ctr + 1
    KeyGen64_type_8to15(eng, r_key, key_temp);  # key gen

    for i in range(32):
        CNOT | (r_key[i], text1[(text1_start - 1 + i) % 32])  # Left 1
    # CTR
    CTR_XOR(eng, text0, ctr, text0_start)

    # Addition with (ROL8 -- omitted)
    ADD(eng, text1, (text1_start - 1) % 32, (text1_start - 2) % 32, text0, text0_start, (text0_start - 1) % 32, c0)

    # Reversible (Optimization)
    for i in range(32):
        CNOT | (r_key[i], text1[(text1_start - 1) % 32])  # Left 1

    KeyGen64_type_8to15_reverse(eng, r_key, key_temp);  # key reverse

    return ctr


def Enc64_type_even_else2(eng, text0, text0_start, text1, text1_start, r_key, ctr, key_temp, c0):
    ctr = ctr + 1
    KeyGen64_type_8to15(eng, r_key, key_temp);  # key gen

    for i in range(32):
        CNOT | (r_key[i], text1[(text1_start-8+i) % 32])  # Left 8
    # CTR
    CTR_XOR(eng, text0, ctr, text0_start)

    # Addition with (ROL1 -- omitted)
    ADD(eng, text1, (text1_start-8)%32, (text1_start-9)%32, text0, text0_start, (text0_start-1)%32, c0)

    # Reversible (Optimization)
    for i in range(32):
        CNOT | (r_key[i], text1[(text1_start - 8 + i) % 32])  # Left 8

    KeyGen64_type_8to15_reverse(eng, r_key, key_temp);  # key reverse

    return ctr

def MAJ(eng, a, b, c):
    CNOT | (a, b)
    CNOT | (a, c)
    Toffoli | (c, b, a)


def UMA(eng, a, b, c):
    Toffoli | (c, b, a)
    CNOT | (a, c)
    CNOT | (c, b)


def ADD(eng, a, a_first, a_last, b, b_first, b_last, c0):
    MAJ(eng, a[a_first], b[b_first], c0)
    for i in range(31):
        MAJ(eng, a[(i + a_first + 1) % 32], b[(i + b_first + 1) % 32], a[(a_first + i) % 32])

    for i in range(31):
        UMA(eng, a[(a_last - i) % 32], b[(b_last - i) % 32], a[(a_last - 1 - i) % 32])
    UMA(eng, a[a_first], b[b_first], c0)


def CTR_XOR(eng, a, ctr, text0_start):

    if (ctr >= 64):
        X | (a[(text0_start+6)%16])
        ctr = ctr - 64

    if (ctr >= 32):
        X | (a[(text0_start+5)%16])
        ctr = ctr - 32

    if (ctr >= 16):
        X | (a[(text0_start+4)%16])
        ctr = ctr - 16

    if (ctr >= 8):
        X | (a[(text0_start+3)%16])
        ctr = ctr - 8

    if (ctr >= 4):
        X | (a[(text0_start+2)%16])
        ctr = ctr - 4

    if (ctr >= 2):
        X | (a[(text0_start+1)%16])
        ctr = ctr - 2

    if (ctr >= 1):
        X | (a[text0_start])
        ctr = ctr - 1

# def dec_to_bin(x):
#	return int(bin(x)[2:])

# drawing_engine = CircuitDrawer()
# eng = MainEngine(drawing_engine)

Resource = ResourceCounter()
eng = MainEngine(Resource)
CHAM64_128_ENC(eng)
print(Resource)

# eng = MainEngine()
# print(Enc(eng))
eng.flush()
