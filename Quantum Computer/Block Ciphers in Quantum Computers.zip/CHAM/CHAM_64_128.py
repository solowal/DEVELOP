import math

from projectq import MainEngine
from projectq.ops import H, CNOT, Measure, Toffoli, X, All
from projectq.backends import CircuitDrawer, ResourceCounter
from projectq.meta import Loop, Compute, Uncompute, Control


def CHAM64_128_ENC(eng):
    k0 = eng.allocate_qureg(16)
    k1 = eng.allocate_qureg(16)
    k2 = eng.allocate_qureg(16)
    k3 = eng.allocate_qureg(16)
    k4 = eng.allocate_qureg(16)
    k5 = eng.allocate_qureg(16)
    k6 = eng.allocate_qureg(16)
    k7 = eng.allocate_qureg(16)

    key_temp  = eng.allocate_qureg(3)

    c0 = eng.allocate_qubit()

    text0 = eng.allocate_qureg(16)
    text1 = eng.allocate_qureg(16)
    text2 = eng.allocate_qureg(16)
    text3 = eng.allocate_qureg(16)

    ctr = -1

    # Round#0
    ctr = Enc64_type_even_else1(eng, text0, 0, text1, 0, k0 , ctr, c0)
    #X[0] = X[1]
    #X[1] = X[2]
    #X[2] = X[3]
    #X[3] = X[0] start 15, end 14

    # Round#1
    ctr = Enc64_type_odd1(eng, text1, 0, text2, 0, k1, ctr, c0)

    # X[0] = X[2]
    # X[1] = X[3]
    # X[2] = X[0] start 15, end 14
    # X[3] = X[1] start 8, end 7

    # Round#2
    ctr = Enc64_type_even_else1(eng, text2, 0, text3, 0, k2, ctr, c0)

    #X[0] = X[3]
    #X[1] = X[0] start 15, end 14
    #X[2] = X[1] start 8, end 7
    #X[3] = X[2] start 15, end 14

    # Round#3
    ctr = Enc64_type_odd1(eng, text3, 0, text0, 15, k3, ctr, c0)

    #X[0] = X[0] start 15, end 14
    #X[1] = X[1] start 8, end 7
    #X[2] = X[2] start 15, end 14
    #X[3] = X[3], start8, end 7

    ###########

    # Round#4
    ctr = Enc64_type_even_else1(eng, text0, 15, text1, 8, k4, ctr, c0)

    # X[0] = X[1] start 8, end 7
    # X[1] = X[2] start 15, end 14
    # X[2] = X[3] start8, end 7
    # X[3] = X[0] start 14, end 13

    # Round 5
    ctr = Enc64_type_odd1(eng, text1, 8, text2, 15, k5, ctr, c0)

    # X[0] = X[2] start 15, end 14
    # X[1] = X[3] sart 8, end 7
    # X[2] = X[0] start 14, end 13
    # X[3] = X[1] start 0, end 15

    # Round 6
    ctr = Enc64_type_even_else1(eng, text2, 15, text3, 8, k6, ctr, c0)

    # X[0] = X[3] start 8, end 7
    # X[1] = X[0] start 14, end 13
    # X[2] = X[1] start 0, end 15
    # X[3] = X[2] start 14, end 13

    # Round 7
    ctr = Enc64_type_odd1(eng, text3, 8, text0, 14, k7, ctr, c0)

    # X[0] = X[0] start 14, end 13
    # X[1] = X[1] start 0, end 15
    # X[2] = X[2] start 14, end 13
    # X[3] = X[3], start0, end 15


    #Round 8
    ctr = Enc64_type_even_else2(eng, text0, 14, text1, 0, k1, ctr, key_temp, c0)

    # X[0] = X[1] start 0, end 15
    # X[1] = X[2] start 14, end 13
    # X[2] = X[3] start 0, end 15
    # X[3] = X[0] start 13, end 12

    #Round 9
    ctr = Enc64_type_odd2(eng, text1, 0, text2, 14, k0, ctr, key_temp, c0)

    #X[0] = X[2] start 14, end 13
    #X[1] = X[3] start 0, end 15
    #X[2] = X[0] start 13, end 12
    #X[3] = X[1] start 8, end 7

    #Round 10
    ctr = Enc64_type_even_else2(eng, text2, 14, text3, 0, k3, ctr, key_temp, c0)

    #X[0] = X[3] start 0, end 15
    #X[1] = X[0] start 13, end 12
    #X[2] = X[1] start 8, end 7
    #X[3] = X[2] start 13, end 12

    #Round 11
    ctr = Enc64_type_odd2(eng, text3, 0, text0, 13, k2, ctr, key_temp, c0)

    # X[0] = X[0] start 13, end 12
    # X[1] = X[1] start 8, end 7
    # X[2] = X[2] start 13, end 12
    # X[3] = X[3], start 8, end 7

    ##########

    #Round 12
    ctr = Enc64_type_even_else2(eng, text0, 13, text1, 8, k5, ctr, key_temp, c0)

    # X[0] = X[1] start 8, end 7
    # X[1] = X[2] start 13, end 12
    # X[2] = X[3] start 8, end 7
    # X[3] = X[0] start 12, end 11

    #Round 13
    ctr = Enc64_type_odd2(eng, text1, 8, text2, 13, k4, ctr, key_temp, c0)

    # X[0] = X[2] start 13, end 12
    # X[1] = X[3] start 8, end 7
    # X[2] = X[0] start 12, end 11
    # X[3] = X[1] start 0, end 15

    # Round 14
    ctr = Enc64_type_even_else2(eng, text2, 13, text3, 8, k7, ctr, key_temp, c0)

    # X[0] = X[3] start 8, end 7
    # X[1] = X[0] start 12, end 11
    # X[2] = X[1] start 0, end 15
    # X[3] = X[2] start 12, end 11

    # Round 15
    ctr = Enc64_type_odd2(eng, text3, 8, text0, 12, k6, ctr, key_temp, c0)

    # X[0] = X[0] start 12, end 11
    # X[1] = X[1] start 0, end 15
    # X[2] = X[2] start 12, end 11
    # X[3] = X[3], start 0, end 15

    ###

    # Round #16
    ctr = Enc64_type_even_else1(eng, text0, 12, text1, 0, k0, ctr, c0)
    # X[0] = X[1] start 0, end 15
    # X[1] = X[2] start 12, end 11
    # X[2] = X[3] start 0, 15
    # X[3] = X[0] start 11, end 10

    # Round#17
    ctr = Enc64_type_odd1(eng, text1, 0, text2, 12, k1, ctr, c0)

    # X[0] = X[2] 12, 11
    # X[1] = X[3] 0, 15
    # X[2] = X[0] 11, 10
    # X[3] = X[1] 8, 7

    # Round#18
    ctr = Enc64_type_even_else1(eng, text2, 12, text3, 0, k2, ctr, c0)

    # X[0] = X[3] 0, 15
    # X[1] = X[0] 11, 10
    # X[2] = X[1] 8, 7
    # X[3] = X[2] 11, 10

    # Round#19
    ctr = Enc64_type_odd1(eng, text3, 0, text0, 11, k3, ctr, c0)

    # X[0] = X[0] 11, 10
    # X[1] = X[1] 8, 7
    # X[2] = X[2] 11, 10
    # X[3] = X[3] 8, 7

    ###########

    # Round#20
    ctr = Enc64_type_even_else1(eng, text0, 11, text1, 8, k4, ctr, c0)

    # X[0] = X[1] 8, 7
    # X[1] = X[2] 11, 10
    # X[2] = X[3] 8, 7
    # X[3] = X[0] 10, 9

    # Round 21
    ctr = Enc64_type_odd1(eng, text1, 8, text2, 11, k5, ctr, c0)

    # X[0] = X[2] 11, 10
    # X[1] = X[3] 8, 7
    # X[2] = X[0] 10, 9
    # X[3] = X[1] 0, 15

    # Round 22
    ctr = Enc64_type_even_else1(eng, text2, 11, text3, 8, k6, ctr, c0)

    # X[0] = X[3] 8, 7
    # X[1] = X[0] 10, 9
    # X[2] = X[1] 0, 15
    # X[3] = X[2] 10, 9

    # Round 23
    ctr = Enc64_type_odd1(eng, text3, 8, text0, 10, k7, ctr, c0)

    # X[0] = X[0] 10, 9
    # X[1] = X[1] 0, 15
    # X[2] = X[2] 10, 9
    # X[3] = X[3], 0, 15

    #####

    # Round 24
    ctr = Enc64_type_even_else2(eng, text0, 10, text1, 0, k1, ctr, key_temp, c0)

    # X[0] = X[1] 0, 15
    # X[1] = X[2] 10, 9
    # X[2] = X[3] 0, 15
    # X[3] = X[0] 9, 8

    # Round 25
    ctr = Enc64_type_odd2(eng, text1, 0, text2, 10, k0, ctr, key_temp, c0)

    # X[0] = X[2] 10, 9
    # X[1] = X[3] 0, 15
    # X[2] = X[0] 9, 8
    # X[3] = X[1] 8, 7

    # Round 26
    ctr = Enc64_type_even_else2(eng, text2, 10, text3, 0, k3, ctr, key_temp, c0)

    # X[0] = X[3] 0, 15
    # X[1] = X[0] 9, 8
    # X[2] = X[1] 8, 7
    # X[3] = X[2] 9, 8

    # Round 27
    ctr = Enc64_type_odd2(eng, text3, 0, text0, 9, k2, ctr, key_temp, c0)

    # X[0] = X[0] 9, 8
    # X[1] = X[1] 8, 7
    # X[2] = X[2] 9, 8
    # X[3] = X[3] 8, 7

    ##########

    # Round 28
    ctr = Enc64_type_even_else2(eng, text0, 9, text1, 8, k5, ctr, key_temp, c0)

    # X[0] = X[1] 8, 7
    # X[1] = X[2] 9, 8
    # X[2] = X[3] 8, 7
    # X[3] = X[0] 8, 7

    # Round 29
    ctr = Enc64_type_odd2(eng, text1, 8, text2, 9, k4, ctr, key_temp, c0)

    # X[0] = X[2] 9, 8
    # X[1] = X[3] 8, 7
    # X[2] = X[0] 8, 7
    # X[3] = X[1] 0, 15

    # Round 30
    ctr = Enc64_type_even_else2(eng, text2, 9, text3, 8, k7, ctr, key_temp, c0)

    # X[0] = X[3] 8, 7
    # X[1] = X[0] 8, 7
    # X[2] = X[1] 0, 15
    # X[3] = X[2] 8, 7

    # Round 31
    ctr = Enc64_type_odd2(eng, text3, 8, text0, 8, k6, ctr, key_temp, c0)

    # X[0] = X[0] 8, 7
    # X[1] = X[1] 0, 15
    # X[2] = X[2] 8, 7
    # X[3] = X[3] 0, 15

    ###
    # Round#32
    ctr = Enc64_type_even_else1(eng, text0, 8, text1, 0, k0, ctr, c0)
    # X[0] = X[1]
    # X[1] = X[2]
    # X[2] = X[3]
    # X[3] = X[0] start 15, end 14

    # Round33
    ctr = Enc64_type_odd1(eng, text1, 0, text2, 8, k1, ctr, c0)

    # X[0] = X[2]
    # X[1] = X[3]
    # X[2] = X[0] start 15, end 14
    # X[3] = X[1] start 8, end 7

    # Round#34
    ctr = Enc64_type_even_else1(eng, text2, 8, text3, 0, k2, ctr, c0)

    # X[0] = X[3]
    # X[1] = X[0] start 15, end 14
    # X[2] = X[1] start 8, end 7
    # X[3] = X[2] start 15, end 14

    # Round#35
    ctr = Enc64_type_odd1(eng, text3, 0, text0, 7, k3, ctr, c0)

    # X[0] = X[0] start 15, end 14
    # X[1] = X[1] start 8, end 7
    # X[2] = X[2] start 15, end 14
    # X[3] = X[3], start8, end 7

    ###########

    # Round#36
    ctr = Enc64_type_even_else1(eng, text0, 7, text1, 8, k4, ctr, c0)

    # X[0] = X[1] start 8, end 7
    # X[1] = X[2] start 15, end 14
    # X[2] = X[3] start8, end 7
    # X[3] = X[0] start 14, end 13

    # Round 37
    ctr = Enc64_type_odd1(eng, text1, 8, text2, 7, k5, ctr, c0)

    # X[0] = X[2] start 15, end 14
    # X[1] = X[3] sart 8, end 7
    # X[2] = X[0] start 14, end 13
    # X[3] = X[1] start 0, end 15

    # Round 38
    ctr = Enc64_type_even_else1(eng, text2, 7, text3, 8, k6, ctr, c0)

    # X[0] = X[3] start 8, end 7
    # X[1] = X[0] start 14, end 13
    # X[2] = X[1] start 0, end 15
    # X[3] = X[2] start 14, end 13

    # Round 39
    ctr = Enc64_type_odd1(eng, text3, 8, text0, 6, k7, ctr, c0)

    # X[0] = X[0] start 14, end 13
    # X[1] = X[1] start 0, end 15
    # X[2] = X[2] start 14, end 13
    # X[3] = X[3], start0, end 15

    # Round 40
    ctr = Enc64_type_even_else2(eng, text0, 6, text1, 0, k1, ctr, key_temp, c0)

    # X[0] = X[1] start 0, end 15
    # X[1] = X[2] start 14, end 13
    # X[2] = X[3] start 0, end 15
    # X[3] = X[0] start 13, end 12

    # Round 41
    ctr = Enc64_type_odd2(eng, text1, 0, text2, 6, k0, ctr, key_temp, c0)

    # X[0] = X[2] start 14, end 13
    # X[1] = X[3] start 0, end 15
    # X[2] = X[0] start 13, end 12
    # X[3] = X[1] start 8, end 7

    # Round 42
    ctr = Enc64_type_even_else2(eng, text2, 6, text3, 0, k3, ctr, key_temp, c0)

    # X[0] = X[3] start 0, end 15
    # X[1] = X[0] start 13, end 12
    # X[2] = X[1] start 8, end 7
    # X[3] = X[2] start 13, end 12

    # Round 43
    ctr = Enc64_type_odd2(eng, text3, 0, text0, 5, k2, ctr, key_temp, c0)

    # X[0] = X[0] start 13, end 12
    # X[1] = X[1] start 8, end 7
    # X[2] = X[2] start 13, end 12
    # X[3] = X[3], start 8, end 7

    ##########

    # Round 44
    ctr = Enc64_type_even_else2(eng, text0, 5, text1, 8, k5, ctr, key_temp, c0)

    # X[0] = X[1] start 8, end 7
    # X[1] = X[2] start 13, end 12
    # X[2] = X[3] start 8, end 7
    # X[3] = X[0] start 12, end 11

    # Round 45
    ctr = Enc64_type_odd2(eng, text1, 8, text2, 5, k4, ctr, key_temp, c0)

    # X[0] = X[2] start 13, end 12
    # X[1] = X[3] start 8, end 7
    # X[2] = X[0] start 12, end 11
    # X[3] = X[1] start 0, end 15

    # Round 46
    ctr = Enc64_type_even_else2(eng, text2, 5, text3, 8, k7, ctr, key_temp, c0)

    # X[0] = X[3] start 8, end 7
    # X[1] = X[0] start 12, end 11
    # X[2] = X[1] start 0, end 15
    # X[3] = X[2] start 12, end 11

    # Round 47
    ctr = Enc64_type_odd2(eng, text3, 8, text0, 4, k6, ctr, key_temp, c0)

    # X[0] = X[0] start 12, end 11
    # X[1] = X[1] start 0, end 15
    # X[2] = X[2] start 12, end 11
    # X[3] = X[3], start 0, end 15

    ####

    # Round 48
    ctr = Enc64_type_even_else1(eng, text0, 4, text1, 0, k0, ctr, c0)
    # X[0] = X[1]
    # X[1] = X[2]
    # X[2] = X[3]
    # X[3] = X[0] start 15, end 14

    # Round 49
    ctr = Enc64_type_odd1(eng, text1, 0, text2, 4, k1, ctr, c0)

    # X[0] = X[2]
    # X[1] = X[3]
    # X[2] = X[0] start 15, end 14
    # X[3] = X[1] start 8, end 7

    # Round 50
    ctr = Enc64_type_even_else1(eng, text2, 4, text3, 0, k2, ctr, c0)

    # X[0] = X[3]
    # X[1] = X[0] start 15, end 14
    # X[2] = X[1] start 8, end 7
    # X[3] = X[2] start 15, end 14

    # Round 51
    ctr = Enc64_type_odd1(eng, text3, 0, text0, 3, k3, ctr, c0)

    # X[0] = X[0] start 15, end 14
    # X[1] = X[1] start 8, end 7
    # X[2] = X[2] start 15, end 14
    # X[3] = X[3], start8, end 7

    ###########

    # Round 52
    ctr = Enc64_type_even_else1(eng, text0, 3, text1, 8, k4, ctr, c0)

    # X[0] = X[1] start 8, end 7
    # X[1] = X[2] start 15, end 14
    # X[2] = X[3] start8, end 7
    # X[3] = X[0] start 14, end 13

    # Round 53
    ctr = Enc64_type_odd1(eng, text1, 8, text2, 3, k5, ctr, c0)

    # X[0] = X[2] start 15, end 14
    # X[1] = X[3] sart 8, end 7
    # X[2] = X[0] start 14, end 13
    # X[3] = X[1] start 0, end 15

    # Round 54
    ctr = Enc64_type_even_else1(eng, text2, 3, text3, 8, k6, ctr, c0)

    # X[0] = X[3] start 8, end 7
    # X[1] = X[0] start 14, end 13
    # X[2] = X[1] start 0, end 15
    # X[3] = X[2] start 14, end 13

    # Round 55
    ctr = Enc64_type_odd1(eng, text3, 8, text0, 2, k7, ctr, c0)

    # X[0] = X[0] start 14, end 13
    # X[1] = X[1] start 0, end 15
    # X[2] = X[2] start 14, end 13
    # X[3] = X[3], start0, end 15

    # Round 56
    ctr = Enc64_type_even_else2(eng, text0, 2, text1, 0, k1, ctr, key_temp, c0)

    # X[0] = X[1] start 0, end 15
    # X[1] = X[2] start 14, end 13
    # X[2] = X[3] start 0, end 15
    # X[3] = X[0] start 13, end 12

    # Round 57
    ctr = Enc64_type_odd2(eng, text1, 0, text2, 2, k0, ctr, key_temp, c0)

    # X[0] = X[2] start 14, end 13
    # X[1] = X[3] start 0, end 15
    # X[2] = X[0] start 13, end 12
    # X[3] = X[1] start 8, end 7

    # Round 58
    ctr = Enc64_type_even_else2(eng, text2, 2, text3, 0, k3, ctr, key_temp, c0)

    # X[0] = X[3] start 0, end 15
    # X[1] = X[0] start 13, end 12
    # X[2] = X[1] start 8, end 7
    # X[3] = X[2] start 13, end 12

    # Round 59
    ctr = Enc64_type_odd2(eng, text3, 0, text0, 1, k2, ctr, key_temp, c0)

    # X[0] = X[0] start 13, end 12
    # X[1] = X[1] start 8, end 7
    # X[2] = X[2] start 13, end 12
    # X[3] = X[3], start 8, end 7

    ##########

    # Round 60
    ctr = Enc64_type_even_else2(eng, text0, 1, text1, 8, k5, ctr, key_temp, c0)

    # X[0] = X[1] start 8, end 7
    # X[1] = X[2] start 13, end 12
    # X[2] = X[3] start 8, end 7
    # X[3] = X[0] start 12, end 11

    # Round 61
    ctr = Enc64_type_odd2(eng, text1, 8, text2, 1, k4, ctr, key_temp, c0)

    # X[0] = X[2] start 13, end 12
    # X[1] = X[3] start 8, end 7
    # X[2] = X[0] start 12, end 11
    # X[3] = X[1] start 0, end 15

    # Round 62
    ctr = Enc64_type_even_else2(eng, text2, 1, text3, 8, k7, ctr, key_temp, c0)

    # X[0] = X[3] start 8, end 7
    # X[1] = X[0] start 12, end 11
    # X[2] = X[1] start 0, end 15
    # X[3] = X[2] start 12, end 11

    # Round 63
    ctr = Enc64_type_odd2(eng, text3, 8, text0, 0, k6, ctr, key_temp, c0)

    # X[0] = X[0] start 12, end 11
    # X[1] = X[1] start 0, end 15
    # X[2] = X[2] start 12, end 11
    # X[3] = X[3], start 0, end 15

    ##

    # Round 64
    ctr = Enc64_type_even_else1(eng, text0, 0, text1, 0, k0, ctr, c0)
    # X[0] = X[1]
    # X[1] = X[2]
    # X[2] = X[3]
    # X[3] = X[0] start 15, end 14

    # Round 65
    ctr = Enc64_type_odd1(eng, text1, 0, text2, 0, k1, ctr, c0)

    # X[0] = X[2]
    # X[1] = X[3]
    # X[2] = X[0] start 15, end 14
    # X[3] = X[1] start 8, end 7

    # Round 66
    ctr = Enc64_type_even_else1(eng, text2, 0, text3, 0, k2, ctr, c0)

    # X[0] = X[3]
    # X[1] = X[0] start 15, end 14
    # X[2] = X[1] start 8, end 7
    # X[3] = X[2] start 15, end 14

    # Round 67
    ctr = Enc64_type_odd1(eng, text3, 0, text0, 15, k3, ctr, c0)

    # X[0] = X[0] start 15, end 14
    # X[1] = X[1] start 8, end 7
    # X[2] = X[2] start 15, end 14
    # X[3] = X[3], start8, end 7

    ###########

    # Round 68
    ctr = Enc64_type_even_else1(eng, text0, 15, text1, 8, k4, ctr, c0)

    # X[0] = X[1] start 8, end 7
    # X[1] = X[2] start 15, end 14
    # X[2] = X[3] start8, end 7
    # X[3] = X[0] start 14, end 13

    # Round 69
    ctr = Enc64_type_odd1(eng, text1, 8, text2, 15, k5, ctr, c0)

    # X[0] = X[2] start 15, end 14
    # X[1] = X[3] sart 8, end 7
    # X[2] = X[0] start 14, end 13
    # X[3] = X[1] start 0, end 15

    # Round 70
    ctr = Enc64_type_even_else1(eng, text2, 15, text3, 8, k6, ctr, c0)

    # X[0] = X[3] start 8, end 7
    # X[1] = X[0] start 14, end 13
    # X[2] = X[1] start 0, end 15
    # X[3] = X[2] start 14, end 13

    # Round 71
    ctr = Enc64_type_odd1(eng, text3, 8, text0, 14, k7, ctr, c0)

    # X[0] = X[0] start 14, end 13
    # X[1] = X[1] start 0, end 15
    # X[2] = X[2] start 14, end 13
    # X[3] = X[3], start0, end 15

    # Round 72
    ctr = Enc64_type_even_else2(eng, text0, 14, text1, 0, k1, ctr, key_temp, c0)

    # X[0] = X[1] start 0, end 15
    # X[1] = X[2] start 14, end 13
    # X[2] = X[3] start 0, end 15
    # X[3] = X[0] start 13, end 12

    # Round 73
    ctr = Enc64_type_odd2(eng, text1, 0, text2, 14, k0, ctr, key_temp, c0)

    # X[0] = X[2] start 14, end 13
    # X[1] = X[3] start 0, end 15
    # X[2] = X[0] start 13, end 12
    # X[3] = X[1] start 8, end 7

    # Round 74
    ctr = Enc64_type_even_else2(eng, text2, 14, text3, 0, k3, ctr, key_temp, c0)

    # X[0] = X[3] start 0, end 15
    # X[1] = X[0] start 13, end 12
    # X[2] = X[1] start 8, end 7
    # X[3] = X[2] start 13, end 12

    # Round 75
    ctr = Enc64_type_odd2(eng, text3, 0, text0, 13, k2, ctr, key_temp, c0)

    # X[0] = X[0] start 13, end 12
    # X[1] = X[1] start 8, end 7
    # X[2] = X[2] start 13, end 12
    # X[3] = X[3], start 8, end 7

    ##########

    # Round 76
    ctr = Enc64_type_even_else2(eng, text0, 13, text1, 8, k5, ctr, key_temp, c0)

    # X[0] = X[1] start 8, end 7
    # X[1] = X[2] start 13, end 12
    # X[2] = X[3] start 8, end 7
    # X[3] = X[0] start 12, end 11

    # Round 77
    ctr = Enc64_type_odd2(eng, text1, 8, text2, 13, k4, ctr, key_temp, c0)

    # X[0] = X[2] start 13, end 12
    # X[1] = X[3] start 8, end 7
    # X[2] = X[0] start 12, end 11
    # X[3] = X[1] start 0, end 15

    # Round 78
    ctr = Enc64_type_even_else2(eng, text2, 13, text3, 8, k7, ctr, key_temp, c0)

    # X[0] = X[3] start 8, end 7
    # X[1] = X[0] start 12, end 11
    # X[2] = X[1] start 0, end 15
    # X[3] = X[2] start 12, end 11

    # Round 79
    ctr = Enc64_type_odd2(eng, text3, 8, text0, 12, k6, ctr, key_temp, c0)  # can -35 Cnot * 8  = -280cnot

    # X[0] = X[0] start 12, end 11
    # X[1] = X[1] start 0, end 15
    # X[2] = X[2] start 12, end 11
    # X[3] = X[3], start 0, end 15

    #END


def KeyGen64_type1(eng, key_in, key_out):
    for i in range(16):
        CNOT | (key_in[i], key_out[(i) % 16])

    for i in range(16):
        CNOT | (key_in[i], key_out[(i + 1) % 16])

    for i in range(16):
        CNOT | (key_in[i], key_out[(i + 8) % 16])


def KeyGen64_type_0to7(eng, key): #25CNOT
    for i in range(8):
        CNOT | (key[i], key[i+8]) #

    for i in range(7):
        CNOT | (key[i+9], key[i])

    CNOT | (key[7], key[15])
    CNOT | (key[8], key[15])
    CNOT | (key[8], key[7])

    for i in range(7):
        CNOT | (key[i], key[i+8])

#key[] = 14 13 12 11 10 9 8 7 6 5 4 3 2 1 0 15 , (start 15, end 14)

def KeyGen64_type_0to7_reverse(eng, key):
    for i in range(7):
        CNOT | (key[6-i], key[14-i])

    CNOT | (key[8], key[7])
    CNOT | (key[8], key[15])
    CNOT | (key[7], key[15])

    for i in range(7):
        CNOT | (key[15-i], key[6-i])

    for i in range(8):
        CNOT | (key[7-i], key[15-i])


def KeyGen64_type_8to15(eng, key, key_temp): #35CNOT

    CNOT | (key[15], key_temp[0])
    CNOT | (key[9], key_temp[0])

    CNOT | (key[5], key_temp[1])
    CNOT | (key[15], key_temp[1])

    CNOT | (key[4], key_temp[2])
    CNOT | (key[10], key_temp[2])

    CNOT | (key[14], key[15])  # 15 14 4
    CNOT | (key[4], key[15])

    CNOT | (key[9], key[4])  # 4 9 3
    CNOT | (key[3], key[4])

    CNOT | (key[14], key[9])  # 9 14 8
    CNOT | (key[8], key[9])

    CNOT | (key[13], key[14])  # 14 13 3
    CNOT | (key[3], key[14])

    CNOT | (key[8], key[3])  # 3 8 2
    CNOT | (key[2], key[3])

    CNOT | (key[13], key[8])  # 8 13 7
    CNOT | (key[7], key[8])

    CNOT | (key[12], key[13])  # 13 12 2
    CNOT | (key[2], key[13])

    CNOT | (key[7], key[2])  # 2 7 1
    CNOT | (key[1], key[2])

    CNOT | (key[12], key[7])  # 7 6 12
    CNOT | (key[6], key[7])

    #
    CNOT | (key[11], key[12])  # 12 11 1
    CNOT | (key[1], key[12])

    CNOT | (key[6], key[1])  # 1 6 0
    CNOT | (key[0], key[1])

    CNOT | (key[11], key[6])  # 6 11 5
    CNOT | (key[5], key[6])

    CNOT | (key[10], key[11])  # 11 10 0
    CNOT | (key[0], key[11])

    CNOT | (key_temp[0], key[10])
    CNOT | (key_temp[1], key[0])
    CNOT | (key_temp[2], key[5])

def KeyGen64_type_8to15_reverse(eng, key, key_temp): #35CNOT

    CNOT | (key_temp[2], key[5])
    CNOT | (key_temp[1], key[0])
    CNOT | (key_temp[0], key[10])

    CNOT | (key[0], key[11])
    CNOT | (key[10], key[11])  # 11 10 0

    CNOT | (key[5], key[6])
    CNOT | (key[11], key[6])  # 6 11 5

    CNOT | (key[0], key[1])
    CNOT | (key[6], key[1])  # 1 6 0

    CNOT | (key[1], key[12])
    CNOT | (key[11], key[12])  # 12 11 1

    CNOT | (key[6], key[7])
    CNOT | (key[12], key[7])  # 7 6 12

    CNOT | (key[1], key[2])
    CNOT | (key[7], key[2])  # 2 7 1

    #######
    CNOT | (key[2], key[13])
    CNOT | (key[12], key[13])  # 13 12 2

    CNOT | (key[7], key[8])
    CNOT | (key[13], key[8])  # 8 13 7

    CNOT | (key[2], key[3])
    CNOT | (key[8], key[3])  # 3 8 2

    CNOT | (key[3], key[14])
    CNOT | (key[13], key[14])  # 14 13 3

    CNOT | (key[8], key[9])
    CNOT | (key[14], key[9])  # 9 14 8

    CNOT | (key[3], key[4])
    CNOT | (key[9], key[4])  # 4 9 3

    CNOT | (key[4], key[15])
    CNOT | (key[14], key[15])  # 15 14 4

    CNOT | (key[10], key_temp[2])
    CNOT | (key[4], key_temp[2])

    CNOT | (key[15], key_temp[1])
    CNOT | (key[5], key_temp[1])

    CNOT | (key[9], key_temp[0])
    CNOT | (key[15], key_temp[0])


def Enc64_type_odd1(eng, text0, text0_start, text1, text1_start, r_key, ctr, c0):  # 0to7 key
    ctr = ctr + 1
    KeyGen64_type_0to7(eng, r_key);  # key gen

    for i in range(16):
        CNOT | (r_key[(i+15)%16], text1[(text1_start-1+i)%16] ) #Left 1
    # CTR
    CTR_XOR(eng, text0, ctr, text0_start)

    # Addition with (ROL8 -- omitted)
    ADD(eng, text1, (text1_start-1)%16, (text1_start-2)%16, text0, text0_start, (text0_start-1)%16, c0)

    # Reversible (Optimization)
    for i in range(16):
        CNOT | (r_key[(i + 15) % 16], text1[(text1_start - 1) % 16])  # Left 1

    KeyGen64_type_0to7_reverse(eng, r_key);  # key reverse

    return ctr


def Enc64_type_even_else1(eng, text0, text0_start, text1, text1_start, r_key, ctr, c0):
    ctr = ctr + 1
    KeyGen64_type_0to7(eng, r_key);  # key gen

    for i in range(16):
        CNOT | (r_key[(i + 15) % 16], text1[(text1_start-8+i) % 16])  # Left 8
    # CTR
    CTR_XOR(eng, text0, ctr, text0_start)

    # Addition with (ROL1 -- omitted)
    ADD(eng, text1, (text1_start-8)%16, (text1_start-9)%16, text0, text0_start, (text0_start-1)%16, c0)

    # Reversible (Optimization)
    for i in range(16):
        CNOT | (r_key[(i + 15) % 16], text1[(text1_start - 8 + i) % 16])  # Left 8

    KeyGen64_type_0to7_reverse(eng, r_key);  # key gen
    return ctr


def Enc64_type_odd2(eng, text0, text0_start, text1, text1_start, r_key, ctr, key_temp, c0): #8to15 key
    ctr = ctr + 1
    KeyGen64_type_8to15(eng, r_key, key_temp);  # key gen

    for i in range(16):
        CNOT | (r_key[i], text1[(text1_start - 1 + i) % 16])  # Left 1
    # CTR
    CTR_XOR(eng, text0, ctr, text0_start)

    # Addition with (ROL8 -- omitted)
    ADD(eng, text1, (text1_start - 1) % 16, (text1_start - 2) % 16, text0, text0_start, (text0_start - 1) % 16, c0)

    # Reversible (Optimization)
    for i in range(16):
        CNOT | (r_key[i], text1[(text1_start - 1) % 16])  # Left 1

    KeyGen64_type_8to15_reverse(eng, r_key, key_temp);  # key reverse

    return ctr


def Enc64_type_even_else2(eng, text0, text0_start, text1, text1_start, r_key, ctr, key_temp, c0):
    ctr = ctr + 1
    KeyGen64_type_8to15(eng, r_key, key_temp);  # key gen

    for i in range(16):
        CNOT | (r_key[i], text1[(text1_start-8+i) % 16])  # Left 8
    # CTR
    CTR_XOR(eng, text0, ctr, text0_start)

    # Addition with (ROL1 -- omitted)
    ADD(eng, text1, (text1_start-8)%16, (text1_start-9)%16, text0, text0_start, (text0_start-1)%16, c0)

    # Reversible (Optimization)
    for i in range(16):
        CNOT | (r_key[i], text1[(text1_start - 8 + i) % 16])  # Left 8

    KeyGen64_type_8to15_reverse(eng, r_key, key_temp);  # key reverse

    return ctr


def MAJ(eng, a, b, c):
    CNOT | (a, b)
    CNOT | (a, c)
    Toffoli | (c, b, a)


def UMA(eng, a, b, c):
    Toffoli | (c, b, a)
    CNOT | (a, c)
    CNOT | (c, b)


def ADD(eng, a, a_first, a_last, b, b_first, b_last, c0):
    MAJ(eng, a[a_first], b[b_first], c0)
    for i in range(15):
        MAJ(eng, a[(i + a_first + 1) % 16], b[(i + b_first + 1) % 16], a[(a_first + i) % 16])

    for i in range(15):
        UMA(eng, a[(a_last - i) % 16], b[(b_last - i) % 16], a[(a_last - 1 - i) % 16])
    UMA(eng, a[a_first], b[b_first], c0)


def CTR_XOR(eng, a, ctr, text0_start):

    if (ctr >= 64):
        X | (a[(text0_start+6)%16])
        ctr = ctr - 64

    if (ctr >= 32):
        X | (a[(text0_start+5)%16])
        ctr = ctr - 32

    if (ctr >= 16):
        X | (a[(text0_start+4)%16])
        ctr = ctr - 16

    if (ctr >= 8):
        X | (a[(text0_start+3)%16])
        ctr = ctr - 8

    if (ctr >= 4):
        X | (a[(text0_start+2)%16])
        ctr = ctr - 4

    if (ctr >= 2):
        X | (a[(text0_start+1)%16])
        ctr = ctr - 2

    if (ctr >= 1):
        X | (a[text0_start])
        ctr = ctr - 1

# def dec_to_bin(x):
#	return int(bin(x)[2:])

# drawing_engine = CircuitDrawer()
# eng = MainEngine(drawing_engine)

Resource = ResourceCounter()
eng = MainEngine(Resource)
CHAM64_128_ENC(eng)
print(Resource)

# eng = MainEngine()
# print(Enc(eng))
eng.flush()
