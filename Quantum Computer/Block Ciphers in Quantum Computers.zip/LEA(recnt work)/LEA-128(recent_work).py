import math

from projectq import MainEngine
from projectq.ops import H, CNOT, Measure, Toffoli, X, All
from projectq.backends import CircuitDrawer, ResourceCounter
from projectq.meta import Loop, Compute, Uncompute, Control

#################### function #######################
def MAJ(eng,a,b,c):

    CNOT | (a, b)
    CNOT | (a, c)
    Toffoli | (c,  b, a)

def Set_a_0(eng,a):

    X | a[0]
    X | a[1]
    X | a[3]

    X | a[4]
    X | a[6]
    X | a[7]

    X | a[8]
    X | a[11]

    X | a[13]
    X | a[14]
    X | a[15]

    X | a[16]
    X | a[17]
    X | a[18]
    X | a[19]

    X | a[21]
    X | a[22]
    X | a[23]

    X | a[24]
    X | a[25]

    X | a[30]
    X | a[31]

                 # 1100 0011 1110 1111 1110 1001 1101 1011 (22)
def To_a1(eng, a): # 0100 0100 0110 0010 0110 1011 0000 0010 (11)
    X | a[0]
    X | a[3]

    X | a[4]
    X | a[6]
    X | a[7]

    X | a[9]

    X | a[15]

    X | a[16]
    X | a[18]
    X | a[19]

    X | a[23]

    X | a[24]
    X | a[25]
    X | a[26]

    X | a[31]

                # 0100 0100 0110 0010 0110 1011 0000 0010 (11)
def To_a2(eng,a): # 0111 1001 1110 0010 0111 1100 1000 1010 (17)

    X | a[3]

    X | a[7]

    X | a[8]
    X | a[9]
    X | a[10]


    X | a[12]

    X | a[23]

    X | a[24]
    X | a[26]
    X | a[27]

    X | a[28]
    X | a[29]
                 # 0111 1001 1110 0010 0111 1100 1000 1010 (17)
def To_a3(eng,a):  # 0111 1000 1101 1111 0011 0000 1110 1100 (18)

    X | a[1]
    X | a[2]

    X | a[5]
    X | a[6]

    X | a[10]
    X | a[11]

    X | a[14]

    X | a[16]
    X | a[18]
    X | a[19]

    X | a[20]
    X | a[21]

    X | a[24]

                    # 0111 1000 1101 1111 0011 0000 1110 1100 (18)
def To_a0(eng, a):    # 1100 0011 1110 1111 1110 1001 1101 1011 (22)

    X | a[0]
    X | a[1]
    X | a[2]

    X | a[4]
    X | a[5]

    X | a[8]
    X | a[11]

    X | a[12]
    X | a[14]
    X | a[15]

    X | a[20]
    X | a[21]

    X | a[24]
    X | a[25]
    X | a[27]

    X | a[28]
    X | a[29]
    X | a[31]

def UMA(eng,a,b,c):

    Toffoli | (c,  b, a)
    CNOT | (a, c)
    CNOT | (c, b)

def Add(eng, a, b, a_first, a_last, b_first, b_last, c0):
    MAJ(eng, a[a_first], b[b_first], c0)
    for i in range (31):
        MAJ(eng, a[(i + a_first+1)%32], b[(i+b_first+1)%32], a[(a_first+i)%32])

    for i in range (31):
        UMA(eng, a[(a_last - i)%32], b[(b_last - i)%32], a[(a_last-1-i)%32])
    UMA(eng, a[a_first], b[b_first], c0)

######################  Encryption ######################

def KeySchedule(eng, a, t0, t1, t2, t3, i, c0):

    Add(eng, a, t0, (32-i) % 32, (31-i) % 32, (32-i) % 32, (31-i) % 32, c0)

    Add(eng, a, t1, (31-i) % 32, (30-i) % 32, (32-i*3) % 32, (31-i*3) % 32, c0)

    Add(eng, a, t2, (30-i) % 32, (29-i) % 32, (32-i*6) % 32, (31-i*6) % 32, c0)

    Add(eng, a, t3, (29-i) % 32, (28-i) % 32, (32-i*11) % 32, (31-i*11) % 32, c0)

def Encryption(eng, t0, t1, t2, t3, text0, text1, text2, text3, start0, start1, start2, start3, round, c0):
    for i in range(32):
        CNOT | (t1[ (i+29-(round*3)) % 32], text3[(i+start3)%32])

    for i in range(32):
        CNOT | (t3[ (i+21-(round*11)) % 32], text2[(i+start2)%32])

    Add(eng, text2, text3, start2, (start2-1)%32, start3, (start3-1)%32, c0)

    #Reverse
    for i in range(32):
        CNOT | (t3[ (i+21-(round*11)) % 32], text2[(i+start2)%32])

    #text2 = text3 ( 3, 2 )

    for i in range(32):
        CNOT | (t1[ (i+29-(round*3)) % 32], text2[(i+start2)%32])

    for i in range(32):
        CNOT | (t2[ (i+26-(round*6)) % 32], text1[(i+start1)%32])

    Add(eng, text1, text2, start1, (start1-1)%32, start2, (start2-1)%32, c0)

    #Reverse
    for i in range(32):
        CNOT | (t2[ (i+26-(round*6)) % 32], text1[(i+start1)%32])

    #text1 = text2 (5, 4)


    for i in range(32):
        CNOT | (t1[ (i+29-(round*3)) % 32], text1[(i+start1)%32])

    for i in range(32):
        CNOT | (t0[ (i+31-round) % 32 ], text0[(i+start0)%32])

    Add(eng, text0, text1, start0, (start0-1)%32, start1, (start1-1)%32, c0)

    #Reverse
    for i in range(32):
        CNOT | (t0[ (i+31-round) % 32 ], text0[(i+start0)%32])

def Enc(eng):

    # Qubit
    t0 = eng.allocate_qureg(32)  #Key
    t1 = eng.allocate_qureg(32)
    t2 = eng.allocate_qureg(32)
    t3 = eng.allocate_qureg(32)


    a = eng.allocate_qureg(32)  # constant

    c0 = eng.allocate_qubit()    #carry qubit

    text0 = eng.allocate_qureg(32)  # plaintext --> ciphertext
    text1 = eng.allocate_qureg(32)
    text2 = eng.allocate_qureg(32)
    text3 = eng.allocate_qureg(32)

    Set_a_0(eng,a)

    #Round0
    KeySchedule(eng, a, t0, t1, t2, t3, 0, c0)
    ################################ ENC(0), X(1) ############################################
    Encryption(eng, t0, t1, t2, t3, text0, text1, text2, text3, 0, 0, 0, 0, 0, c0)
    # text0 = text1 (23, 22)[-9] #text0 = text2      #text0 = text3
    # text1 = text2 (5, 4)  [+5] #text1 = text3      #text1 = text0
    # text2 = text3 (3, 2)  [+3] #text2 = text0      #text2 = text1
    # text3 = text0 (0, 31) [0]  #text3 = text1      #text3 = text2

    To_a1(eng,a)
    # Round1
    KeySchedule(eng, a, t0, t1, t2, t3, 1, c0)
    Encryption(eng, t0, t1, t2, t3, text1, text2, text3, text0, 23, 5, 3, 0, 1, c0)
    # text0 = text1 (23, 22)[-9] #text0 = text2(28, 27)    #text0 = text3(31, 30)
    # text1 = text2 (5, 4)  [+5] #text1 = text3(8, 7)      #text1 = text0(8, 7)
    # text2 = text3 (3, 2)  [+3] #text2 = text0(3, 2)      #text2 = text1(26, 25)
    # text3 = text0 (0, 31) [0]  #text3 = text1(23, 22)    #text3 = text2(28, 27)

    To_a2(eng,a)
    # Round2
    KeySchedule(eng, a, t0, t1, t2, t3, 2, c0)
    Encryption(eng, t0, t1, t2, t3, text2, text3, text0, text1, 28, 8, 3, 23, 2, c0)
    # text0 = text1 (23, 22)[-9] #text0 = text2(28, 27)    #text0 = text3(31, 30)
    # text1 = text2 (5, 4)  [+5] #text1 = text3(8, 7)      #text1 = text0(8, 7)
    # text2 = text3 (3, 2)  [+3] #text2 = text0(3, 2)      #text2 = text1(26, 25)
    # text3 = text0 (0, 31) [0]  #text3 = text1(23, 22)    #text3 = text2(28, 27)

    To_a3(eng,a)
    # Round3
    KeySchedule(eng, a, t0, t1, t2, t3, 3, c0)
    Encryption(eng, t0, t1, t2, t3, text3, text0, text1, text2, 31, 8, 26, 28, 3, c0)
    # text0 = text1 (23, 22)[-9] #text0 = text2(28, 27)    #text0 = text3(31, 30) #text0 = text0 (31, 30)
    # text1 = text2 (5, 4)  [+5] #text1 = text3(8, 7)      #text1 = text0(8, 7)   #text1 = text1 (31, 30)
    # text2 = text3 (3, 2)  [+3] #text2 = text0(3, 2)      #text2 = text1(26, 25) #text2 = text2 (31, 30)
    # text3 = text0 (0, 31) [0]  #text3 = text1(23, 22)    #text3 = text2(28, 27)   #text3 = text3 (31, 30)

    To_a0(eng,a)
    #Round4
    KeySchedule(eng, a, t0, t1, t2, t3, 4, c0)
    Encryption(eng, t0, t1, t2, t3, text0, text1, text2, text3, 31, 31, 31, 31, 4, c0)

    # text0 = text1 (23, 22)[-9] #text0 = text2(28, 27)    #text0 = text3(31, 30) #text0 = text0 (31, 30)
    # text1 = text2 (5, 4)  [+5] #text1 = text3(8, 7)      #text1 = text0(8, 7)   #text1 = text1 (31, 30)
    # text2 = text3 (3, 2)  [+3] #text2 = text0(3, 2)      #text2 = text1(26, 25) #text2 = text2 (31, 30)
    # text3 = text0 (0, 31) [0]  #text3 = text1(23, 22)    #text3 = text2(3, 2)   #text3 = text3 (31, 30)

    # text0 = text1 (22, 21)[-9]
    # text1 = text2 (4, 3)[+5]
    # text2 = text3 (2, 1)  [+3]
    # text3 = text0 (31, 30)[0]

    To_a1(eng,a)
    #Round5
    KeySchedule(eng, a, t0, t1, t2, t3, 5, c0)
    Encryption(eng, t0, t1, t2, t3, text1, text2, text3, text0, 22, 4, 2, 31, 5, c0)
    # text0 = text1 (22, 21)[-9] #text0 = text2 (27, 26)
    # text1 = text2 (4, 3)[+5]   #text1 = text3 (7, 6)
    # text2 = text3 (2, 1)  [+3] #text2 = text0 (2, 1)
    # text3 = text0 (31, 30)[0]  #text3 = text1 (22, 21)

    To_a2(eng,a)
    #Round6
    KeySchedule(eng, a, t0, t1, t2, t3, 6, c0)
    Encryption(eng, t0, t1, t2, t3, text2, text3, text0, text1, 27, 7, 2, 22, 6, c0)

    # text0 = text1 (22, 21)[-9] #text0 = text2 (27, 26)  #text0 = text3 (30,29)
    # text1 = text2 (11, 10)[+5] #text1 = text3 (7, 6)  #text1 = text0 (7, 6)
    # text2 = text3 (2, 1)  [+3] #text2 = text0 (2, 1)  #text2 = text1 (25, 24)
    # text3 = text0 (31, 30)[0]  #text3 = text1 (22, 21)#text3 = text2 (27, 26)

    To_a3(eng,a)
    #Round7
    KeySchedule(eng, a, t0, t1, t2, t3, 7, c0)
    Encryption(eng, t0, t1, t2, t3, text3, text0, text1, text2, 30, 7, 25, 27, 7, c0)

    # text0 = text1 (22, 21)[-9] #text0 = text2 (27, 26)  #text0 = text3 (30,29) #text0 = text0 (30, 29)
    # text1 = text2 (11, 10)[+5] #text1 = text3 (7, 6)  #text1 = text0 (7, 6)  #text1 = text1 (30, 29)
    # text2 = text3 (2, 1)  [+3] #text2 = text0 (2, 1)  #text2 = text1 (25, 24)#text2 = text2 (30, 29)
    # text3 = text0 (31, 30)[0]  #text3 = text1 (22, 21)#text3 = text2 (27, 26)  #text3 = text3 (30, 29)

    To_a0(eng,a)
    #Round8
    KeySchedule(eng, a, t0, t1, t2, t3, 8, c0)
    Encryption(eng, t0, t1, t2, t3, text0, text1, text2, text3, 30, 30, 30, 30, 8, c0)


##
    To_a1(eng,a)
    #Round9
    KeySchedule(eng, a, t0, t1, t2, t3, 9, c0)
    Encryption(eng, t0, t1, t2, t3, text1, text2, text3, text0, 21, 3, 1, 30, 9, c0)
    # text0 = text1 (22, 21)[-9] #text0 = text2 (27, 26)
    # text1 = text2 (4, 3)[+5]   #text1 = text3 (7, 6)
    # text2 = text3 (2, 1)  [+3] #text2 = text0 (2, 1)
    # text3 = text0 (31, 30)[0]  #text3 = text1 (22, 21)

    To_a2(eng,a)
    #Round10
    KeySchedule(eng, a, t0, t1, t2, t3, 10, c0)
    Encryption(eng, t0, t1, t2, t3, text2, text3, text0, text1, 26, 6, 1, 21, 10, c0)

    # text0 = text1 (22, 21)[-9] #text0 = text2 (27, 26)  #text0 = text3 (30,29)
    # text1 = text2 (11, 10)[+5] #text1 = text3 (7, 6)  #text1 = text0 (7, 6)
    # text2 = text3 (2, 1)  [+3] #text2 = text0 (2, 1)  #text2 = text1 (25, 24)
    # text3 = text0 (31, 30)[0]  #text3 = text1 (22, 21)#text3 = text2 (27, 26)

    To_a3(eng,a)
    #Round11
    KeySchedule(eng, a, t0, t1, t2, t3, 11, c0)
    Encryption(eng, t0, t1, t2, t3, text3, text0, text1, text2, 29, 6, 24, 26, 11, c0)

    # text0 = text1 (22, 21)[-9] #text0 = text2 (27, 26)  #text0 = text3 (30,29) #text0 = text0 (30, 29)
    # text1 = text2 (11, 10)[+5] #text1 = text3 (7, 6)  #text1 = text0 (7, 6)  #text1 = text1 (30, 29)
    # text2 = text3 (2, 1)  [+3] #text2 = text0 (2, 1)  #text2 = text1 (25, 24)#text2 = text2 (30, 29)
    # text3 = text0 (31, 30)[0]  #text3 = text1 (22, 21)#text3 = text2 (27, 26)  #text3 = text3 (30, 29)

    To_a0(eng,a)
    #Round12
    KeySchedule(eng, a, t0, t1, t2, t3, 12, c0)
    Encryption(eng, t0, t1, t2, t3, text0, text1, text2, text3, 29, 29, 29, 29, 12, c0)

##
    To_a1(eng,a)
    #Round13
    KeySchedule(eng, a, t0, t1, t2, t3, 13, c0)
    Encryption(eng, t0, t1, t2, t3, text1, text2, text3, text0, 20, 2, 0, 29, 13, c0)
    # text0 = text1 (22, 21)[-9] #text0 = text2 (27, 26)
    # text1 = text2 (4, 3)[+5]   #text1 = text3 (7, 6)
    # text2 = text3 (2, 1)  [+3] #text2 = text0 (2, 1)
    # text3 = text0 (31, 30)[0]  #text3 = text1 (22, 21)

    To_a2(eng,a)
    #Round14
    KeySchedule(eng, a, t0, t1, t2, t3, 14, c0)
    Encryption(eng, t0, t1, t2, t3, text2, text3, text0, text1, 25, 5, 0, 20, 14, c0)

    # text0 = text1 (22, 21)[-9] #text0 = text2 (27, 26)  #text0 = text3 (30,29)
    # text1 = text2 (11, 10)[+5] #text1 = text3 (7, 6)  #text1 = text0 (7, 6)
    # text2 = text3 (2, 1)  [+3] #text2 = text0 (2, 1)  #text2 = text1 (25, 24)
    # text3 = text0 (31, 30)[0]  #text3 = text1 (22, 21)#text3 = text2 (27, 26)

    To_a3(eng,a)
    #Round15
    KeySchedule(eng, a, t0, t1, t2, t3, 15, c0)
    Encryption(eng, t0, t1, t2, t3, text3, text0, text1, text2, 28, 5, 23, 25, 15, c0)

    # text0 = text1 (22, 21)[-9] #text0 = text2 (27, 26)  #text0 = text3 (30,29) #text0 = text0 (30, 29)
    # text1 = text2 (11, 10)[+5] #text1 = text3 (7, 6)  #text1 = text0 (7, 6)  #text1 = text1 (30, 29)
    # text2 = text3 (2, 1)  [+3] #text2 = text0 (2, 1)  #text2 = text1 (25, 24)#text2 = text2 (30, 29)
    # text3 = text0 (31, 30)[0]  #text3 = text1 (22, 21)#text3 = text2 (27, 26)  #text3 = text3 (30, 29)

    To_a0(eng,a)
    #Round16
    KeySchedule(eng, a, t0, t1, t2, t3, 16, c0)
    Encryption(eng, t0, t1, t2, t3, text0, text1, text2, text3, 28, 28, 28, 28, 16, c0)

##
    To_a1(eng,a)
    #Round17
    KeySchedule(eng, a, t0, t1, t2, t3, 17, c0)
    Encryption(eng, t0, t1, t2, t3, text1, text2, text3, text0, 19, 1, 31, 28, 17, c0)
    # text0 = text1 (22, 21)[-9] #text0 = text2 (27, 26)
    # text1 = text2 (4, 3)[+5]   #text1 = text3 (7, 6)
    # text2 = text3 (2, 1)  [+3] #text2 = text0 (2, 1)
    # text3 = text0 (31, 30)[0]  #text3 = text1 (22, 21)

    To_a2(eng,a)
    #Round18
    KeySchedule(eng, a, t0, t1, t2, t3, 18, c0)
    Encryption(eng, t0, t1, t2, t3, text2, text3, text0, text1, 24, 4, 31, 19, 18, c0)

    # text0 = text1 (22, 21)[-9] #text0 = text2 (27, 26)  #text0 = text3 (30,29)
    # text1 = text2 (11, 10)[+5] #text1 = text3 (7, 6)  #text1 = text0 (7, 6)
    # text2 = text3 (2, 1)  [+3] #text2 = text0 (2, 1)  #text2 = text1 (25, 24)
    # text3 = text0 (31, 30)[0]  #text3 = text1 (22, 21)#text3 = text2 (27, 26)

    To_a3(eng,a)
    #Round19
    KeySchedule(eng, a, t0, t1, t2, t3, 19, c0)
    Encryption(eng, t0, t1, t2, t3, text3, text0, text1, text2, 27, 4, 22, 24, 19, c0)

    # text0 = text1 (22, 21)[-9] #text0 = text2 (27, 26)  #text0 = text3 (30,29) #text0 = text0 (30, 29)
    # text1 = text2 (11, 10)[+5] #text1 = text3 (7, 6)  #text1 = text0 (7, 6)  #text1 = text1 (30, 29)
    # text2 = text3 (2, 1)  [+3] #text2 = text0 (2, 1)  #text2 = text1 (25, 24)#text2 = text2 (30, 29)
    # text3 = text0 (31, 30)[0]  #text3 = text1 (22, 21)#text3 = text2 (27, 26)  #text3 = text3 (30, 29)

    To_a0(eng,a)
    #Round20
    KeySchedule(eng, a, t0, t1, t2, t3, 20, c0)
    Encryption(eng, t0, t1, t2, t3, text0, text1, text2, text3, 27, 27, 27, 27, 20, c0)

##
    To_a1(eng,a)
    # Round21
    KeySchedule(eng, a, t0, t1, t2, t3, 21, c0)
    Encryption(eng, t0, t1, t2, t3, text1, text2, text3, text0, 18, 0, 30, 27, 21, c0)
    # text0 = text1 (22, 21)[-9] #text0 = text2 (27, 26)
    # text1 = text2 (4, 3)[+5]   #text1 = text3 (7, 6)
    # text2 = text3 (2, 1)  [+3] #text2 = text0 (2, 1)
    # text3 = text0 (31, 30)[0]  #text3 = text1 (22, 21)

    To_a2(eng,a)
    # Round22
    KeySchedule(eng, a, t0, t1, t2, t3, 22, c0)
    Encryption(eng, t0, t1, t2, t3, text2, text3, text0, text1, 23, 3, 30, 18, 22, c0)

    # text0 = text1 (22, 21)[-9] #text0 = text2 (27, 26)  #text0 = text3 (30,29)
    # text1 = text2 (11, 10)[+5] #text1 = text3 (7, 6)  #text1 = text0 (7, 6)
    # text2 = text3 (2, 1)  [+3] #text2 = text0 (2, 1)  #text2 = text1 (25, 24)
    # text3 = text0 (31, 30)[0]  #text3 = text1 (22, 21)#text3 = text2 (27, 26)

    To_a3(eng,a)
    # Round23
    KeySchedule(eng, a, t0, t1, t2, t3, 23, c0)
    Encryption(eng, t0, t1, t2, t3, text3, text0, text1, text2, 26, 3, 21, 23, 23, c0)

    #cipher0 = text3(26, 25)
    #cipher1 = text0(3, 2)
    #cipher2 = text1(21, 20)
    #cipher3 = text2(23, 22)

    #END

Resource = ResourceCounter()
eng = MainEngine(Resource)
Enc(eng)
print(Resource)

eng.flush()
