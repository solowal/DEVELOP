import math

from projectq import MainEngine
from projectq.ops import H, CNOT, Measure, Toffoli, X, All
from projectq.backends import CircuitDrawer, ResourceCounter
from projectq.meta import Loop, Compute, Uncompute, Control

######################  Encryption ######################

def Enc(eng):

    # key
    mk0 = eng.allocate_qureg(8)
    mk1 = eng.allocate_qureg(8)
    mk2 = eng.allocate_qureg(8)
    mk3 = eng.allocate_qureg(8)
    mk4 = eng.allocate_qureg(8)
    mk5 = eng.allocate_qureg(8)
    mk6 = eng.allocate_qureg(8)
    mk7 = eng.allocate_qureg(8)
    mk8 = eng.allocate_qureg(8)
    mk9 = eng.allocate_qureg(8)
    mk10 = eng.allocate_qureg(8)
    mk11 = eng.allocate_qureg(8)
    mk12 = eng.allocate_qureg(8)
    mk13 = eng.allocate_qureg(8)
    mk14 = eng.allocate_qureg(8)
    mk15 = eng.allocate_qureg(8)

    # Plain text
    x0 = eng.allocate_qureg(8)
    x1 = eng.allocate_qureg(8)
    x2 = eng.allocate_qureg(8)
    x3 = eng.allocate_qureg(8)
    x4 = eng.allocate_qureg(8)
    x5 = eng.allocate_qureg(8)
    x6 = eng.allocate_qureg(8)
    x7 = eng.allocate_qureg(8)

    s = eng.allocate_qureg(8)

    X | s[1]
    X | s[3]
    X | s[4]
    X | s[6]

    c0 = eng.allocate_qubit()  # carry qubit

    #first whitening
    #WK0 = mk12
    #WK1 = mk13
    #WK2 = mk14
    #WK3 = mk15

    #WK4 = mk0
    #WK5 = mk1
    #WK6 = mk2
    #Wk7 = mk3

    Add(eng, mk12, x0, 0, 7, 0, 7, c0)

    for i in range(8):
        CNOT | (mk13[i], x2[i])

    Add(eng, mk14, x4, 0, 7, 0, 7, c0)

    for i in range(8):
        CNOT | (mk15[i], x6[i])

    i=-1

    # Round 1
    i = Round(eng, s, mk0, mk1, mk2, mk3, x0, x1, x2, x3, x4, x5, x6, x7, i, c0)
    # Round2
    i = Round(eng, s, mk4, mk5, mk6, mk7, x7, x0, x1, x2, x3, x4, x5, x6, i, c0)
    #Round 3
    i = Round(eng, s, mk8, mk9, mk10, mk11, x6, x7, x0, x1, x2, x3, x4, x5, i, c0)
    # Round 4
    i = Round(eng, s, mk12, mk13, mk14, mk15, x5, x6, x7, x0, x1, x2, x3, x4, i, c0)


    # Round 5
    i = Round(eng, s, mk7, mk0, mk1, mk2, x4, x5, x6, x7, x0, x1, x2, x3, i, c0)
    # Round 6
    i = Round(eng, s, mk3, mk4, mk5, mk6, x3, x4, x5, x6, x7, x0, x1, x2, i, c0)
    # Round 7
    i = Round(eng, s, mk15, mk8, mk9, mk10, x2, x3, x4, x5, x6, x7, x0, x1, i, c0)
    # Round 8
    i = Round(eng, s, mk11, mk12, mk13, mk14, x1, x2, x3, x4, x5, x6, x7, x0, i, c0)


    # Round 9
    i = Round(eng, s, mk6, mk7, mk0, mk1, x0, x1, x2, x3, x4, x5, x6, x7, i, c0)
    # Round 10
    i = Round(eng, s, mk2, mk3, mk4, mk5, x7, x0, x1, x2, x3, x4, x5, x6, i, c0)
    # Round 11
    i = Round(eng, s, mk14, mk15, mk8, mk9, x6, x7, x0, x1, x2, x3, x4, x5, i, c0)
    # Round 12
    i = Round(eng, s, mk10, mk11, mk12, mk13, x5, x6, x7, x0, x1, x2, x3, x4, i, c0)


    # Round 13
    i = Round(eng, s, mk5, mk6, mk7, mk0, x4, x5, x6, x7, x0, x1, x2, x3, i, c0)
    # Round 14
    i = Round(eng, s, mk1, mk2, mk3, mk4, x3, x4, x5, x6, x7, x0, x1, x2, i, c0)
    # Round 15
    i = Round(eng, s, mk13, mk14, mk15, mk8, x2, x3, x4, x5, x6, x7, x0, x1, i, c0)
    # Round 16
    i = Round(eng, s, mk9, mk10, mk11, mk12, x1, x2, x3, x4, x5, x6, x7, x0, i, c0)


    # Round 17
    i = Round(eng, s, mk4, mk5, mk6, mk7, x0, x1, x2, x3, x4, x5, x6, x7, i, c0)
    # Round 18
    i = Round(eng, s, mk0, mk1, mk2, mk3, x7, x0, x1, x2, x3, x4, x5, x6, i, c0)
    # Round 19
    i = Round(eng, s, mk12, mk13, mk14, mk15, x6, x7, x0, x1, x2, x3, x4, x5, i, c0)
    # Round 20
    i = Round(eng, s, mk8, mk9, mk10, mk11, x5, x6, x7, x0, x1, x2, x3, x4, i, c0)


    # Round 21
    i = Round(eng, s, mk3, mk4, mk5, mk6, x4, x5, x6, x7, x0, x1, x2, x3, i, c0)
    # Round 22
    i = Round(eng, s, mk7, mk0, mk1, mk2, x3, x4, x5, x6, x7, x0, x1, x2, i, c0)
    # Round 23
    i = Round(eng, s, mk11, mk12, mk13, mk14, x2, x3, x4, x5, x6, x7, x0, x1, i, c0)
    # Round 24
    i = Round(eng, s, mk15, mk8, mk9, mk10, x1, x2, x3, x4, x5, x6, x7, x0, i, c0)


    # Round 25
    i = Round(eng, s, mk2, mk3, mk4, mk5, x0, x1, x2, x3, x4, x5, x6, x7, i, c0)
    # Round 26
    i = Round(eng, s, mk6, mk7, mk0, mk1, x7, x0, x1, x2, x3, x4, x5, x6, i, c0)
    # Round 27
    i = Round(eng, s, mk10, mk11, mk12, mk13, x6, x7, x0, x1, x2, x3, x4, x5, i, c0)
    # Round 28
    i = Round(eng, s, mk14, mk15, mk8, mk9, x5, x6, x7, x0, x1, x2, x3, x4, i, c0)

    # Round 29
    i = Round(eng, s, mk1, mk2, mk3, mk4, x4, x5, x6, x7, x0, x1, x2, x3, i, c0)  # mk4 can skip reverse (-1)
    # Round 30
    i = Round(eng, s, mk5, mk6, mk7, mk0, x3, x4, x5, x6, x7, x0, x1, x2, i, c0)  # mk5, 6, 7 can skip reverse (-3)
    # Round 31
    i = Round(eng, s, mk9, mk10, mk11, mk12, x2, x3, x4, x5, x6, x7, x0, x1, i, c0) # all mk can skip reverse (-4)--> -8 reverse operation --> (ADD : 32cnot, 16Tof) * 8  = 256cnot, 128tof
    # Round 32
    i = Last_Round(eng, s, mk13, mk14, mk15, mk8, x1, x2, x3, x4, x5, x6, x7, x0, i, c0) #skipped reverse

    #Last Whitening
    Add(eng, mk0, x1, 0, 7, 0, 7, c0)

    for i in range(8):
        CNOT | (mk1[i], x3[i])

    Add(eng, mk2, x5, 0, 7, 0, 7, c0)

    for i in range(8):
        CNOT | (mk3[i], x7[i])

    #END cipher : 0, 7, 6, 5, 4, 3, 2, 1


def Round(eng, s, mk_first, mk_second, mk_third, mk_fourth, x0, x1, x2, x3, x4, x5, x6, x7, i, c0):
    ##################
    i = generate_s(eng, s, i)
    Add_s(eng, s, mk_first, i % 7, (i-1) % 7, 0, 7, c0)
    F0(eng, x0)
    F0_CNOT(eng, mk_first, x0)
    X_Add(eng, x0, x1, c0)

    #Reverse
    F0_CNOT(eng, mk_first, x0)
    F0_reverse(eng, x0)
    Add_s_reverse(eng, s, mk_first, i % 7, (i-1) % 7, 0, 7, c0)
    # END : X2 = X1

    ###################

    i = generate_s(eng, s, i)
    Add_s(eng, s, mk_second, i % 7, (i-1) % 7, 0, 7, c0)
    F0(eng, x2)
    F0_Add(eng, mk_second, x2, c0)
    X_CNOT(eng, x2, x3)

    #Reverse
    F0_Add_Reverse(eng, mk_second, x2, c0)
    F0_reverse(eng, x2)
    Add_s_reverse(eng, s, mk_second, i % 7, (i-1) % 7, 0, 7, c0)
    # END : X4 = X3

    ###################

    i = generate_s(eng, s, i)
    Add_s(eng, s, mk_third, i % 7, (i-1) % 7, 0, 7, c0)
    F0(eng, x4)
    F0_CNOT(eng, mk_third, x4)
    X_Add(eng, x4, x5, c0)

    #Reverse
    F0_CNOT(eng, mk_third, x4)
    F0_reverse(eng, x4)
    Add_s_reverse(eng, s, mk_third, i % 7, (i - 1) % 7, 0, 7, c0)
    #END : X6 = X5

    ###################

    i = generate_s(eng, s, i)
    Add_s(eng, s, mk_fourth, i % 7, (i - 1) % 7, 0, 7, c0)
    F0(eng, x6)
    F0_Add(eng, mk_fourth, x6, c0)
    X_CNOT(eng, x6, x7)

    #Reverse
    F0_Add_Reverse(eng, mk_fourth, x6, c0)
    F0_reverse(eng, x6)
    Add_s_reverse(eng, s, mk_fourth, i % 7, (i - 1) % 7, 0, 7, c0)
    #End : x0 = x7

    return i

def Last_Round(eng, s, mk_first, mk_second, mk_third, mk_fourth, x0, x1, x2, x3, x4, x5, x6, x7, i, c0):
    i = generate_s(eng, s, i)
    Add_s(eng, s, mk_first, i % 7, (i - 1) % 7, 0, 7, c0)
    F1(eng, x0)
    F1_CNOT(eng, mk_first, x0)
    X1_Add(eng, x0, x1, c0)

    # Reverse
    F1_CNOT(eng, mk_first, x0)
    F1_reverse(eng, x0)
    # END : X1 = X1

    ###################

    i = generate_s(eng, s, i)
    Add_s(eng, s, mk_second, i % 7, (i - 1) % 7, 0, 7, c0)
    F0(eng, x2)
    F0_Add(eng, mk_second, x2, c0)
    X_CNOT(eng, x2, x3)

    # Reverse
    F0_Add_Reverse(eng, mk_second, x2, c0)
    F0_reverse(eng, x2)
    # END : X3 = X3

    ###################

    i = generate_s(eng, s, i)
    Add_s(eng, s, mk_third, i % 7, (i - 1) % 7, 0, 7, c0)
    F1(eng, x4)
    F1_CNOT(eng, mk_third, x4)
    X1_Add(eng, x4, x5, c0)

    # Reverse
    F1_CNOT(eng, mk_third, x4)
    F1_reverse(eng, x4)
    # END : X5 = X5

    ###################

    i = generate_s(eng, s, i)
    Add_s(eng, s, mk_fourth, i % 7, (i - 1) % 7, 0, 7, c0)
    F0(eng, x6)
    F0_Add(eng, mk_fourth, x6, c0)
    X_CNOT(eng, x6, x7)

    # Reverse
    F0_Add_Reverse(eng, mk_fourth, x6, c0)
    F0_reverse(eng, x6)
    # End : x7 = x7

    return i


def generate_s(eng, s, i):
    i = i + 1

    if (i == 0):
        return i

    # new(0) , 6, 5, 4, 3, 2 , 1 ( i % 7 , (i-1) % 7 )
    CNOT | (s[(i+2)%7], s[(i-1)%7])

    return i

def F0 (eng, x): #21cnot
    CNOT | (x[4], x[5])    # 5 = 5+4
    CNOT | (x[3], x[4])    # 4 = 4+3

    CNOT | (x[2], x[3])    # 3 = 3+2
    CNOT | (x[2], x[0])    # 0 = 0+2

    CNOT | (x[4], x[2])    # 2 = 2+4+3
    CNOT | (x[5], x[2])    # 2 = 2+5+3

    CNOT | (x[7], x[5])    # 5 = 5+4+7
    CNOT | (x[6], x[4])    # 4 = 4+3+6

    CNOT | (x[0], x[3])    # 3 = 3+0
    CNOT | (x[1], x[3])    # 3 = 3+0+1

    CNOT | (x[6], x[1])    # 1 = 1+6
    CNOT | (x[7], x[1])    # 1 = 1+6+7

    CNOT | (x[7], x[0])    # 0 = 0+2+7

    CNOT | (x[5], x[6])    # 6 = 6+5+4+7
    CNOT | (x[4], x[6])    # 6 = 3+5+7

    CNOT | (x[3], x[6])    # 6 = 0+1+5+7
    CNOT | (x[1], x[6])    # 6 = 0+5+6

    CNOT | (x[6], x[7])    # 7 = 7+0+5+6
    CNOT | (x[5], x[7])    # 7 = 4+0+6

    CNOT | (x[1], x[7])    # 7 = 1+4+0+7
    CNOT | (x[0], x[7])    # 7 = 1+4+2

def F0_reverse (eng, x):
    CNOT | (x[0], x[7])
    CNOT | (x[1], x[7])

    CNOT | (x[5], x[7])
    CNOT | (x[6], x[7])

    CNOT | (x[1], x[6])
    CNOT | (x[3], x[6])

    CNOT | (x[4], x[6])
    CNOT | (x[5], x[6])

    CNOT | (x[7], x[0])

    CNOT | (x[7], x[1])
    CNOT | (x[6], x[1])

    CNOT | (x[1], x[3])
    CNOT | (x[0], x[3])

    CNOT | (x[6], x[4])
    CNOT | (x[7], x[5])

    CNOT | (x[5], x[2])
    CNOT | (x[4], x[2])

    CNOT | (x[2], x[0])
    CNOT | (x[2], x[3])

    CNOT | (x[3], x[4])
    CNOT | (x[4], x[5])

def F1(eng, x): #24cnot
    CNOT | (x[3], x[4])
    CNOT | (x[1], x[4]) # 4= 4+3+1

    CNOT | (x[2], x[3])
    CNOT | (x[0], x[3]) # 3= 3+2+0

    CNOT | (x[1], x[2])
    CNOT | (x[7], x[2]) # 2 = 2+1+7

    CNOT | (x[0], x[1])
    CNOT | (x[6], x[1]) # 1 = 1+0+6

    CNOT | (x[7], x[0]) # 0 = 0+7+5
    CNOT | (x[5], x[0])


    CNOT | (x[6], x[7]) # 7 = 7+6+4
    CNOT | (x[4], x[7])
    CNOT | (x[3], x[7])
    CNOT | (x[2], x[7])
    CNOT | (x[0], x[7])
    CNOT | (x[5], x[7])

    CNOT | (x[0], x[6])
    CNOT | (x[7], x[6]) # 4 5 6 0  #6 = 0+5+4

    CNOT | (x[4], x[6])
    CNOT | (x[1], x[6]) # 4 3 6 0  #6 = 5+3+6

    CNOT | (x[7], x[5])
    CNOT | (x[6], x[5]) # 3 5 7 4  #5 = 7+4+3

    CNOT | (x[3], x[5])
    CNOT | (x[0], x[5]) # 3 5 7 2  #5 = 4+2+5

    # 4 3 2 1 0 7 6 5
def F1_reverse(eng, x):
    CNOT | (x[0], x[5])
    CNOT | (x[3], x[5])

    CNOT | (x[6], x[5])
    CNOT | (x[7], x[5])

    CNOT | (x[1], x[6])
    CNOT | (x[4], x[6])

    CNOT | (x[7], x[6])
    CNOT | (x[0], x[6])

    CNOT | (x[5], x[7])
    CNOT | (x[0], x[7])
    CNOT | (x[2], x[7])
    CNOT | (x[3], x[7])
    CNOT | (x[4], x[7])
    CNOT | (x[6], x[7])

    CNOT | (x[5], x[0])
    CNOT | (x[7], x[0])

    CNOT | (x[6], x[1])
    CNOT | (x[0], x[1])

    CNOT | (x[7], x[2])
    CNOT | (x[1], x[2])

    CNOT | (x[0], x[3])
    CNOT | (x[2], x[3])

    CNOT | (x[1], x[4])
    CNOT | (x[3], x[4])

def MAJ(eng,a,b,c):
    CNOT | (a, b)
    CNOT | (a, c)
    Toffoli | (c,  b, a)

def UMA(eng,a,b,c):
    Toffoli | (c,  b, a)
    CNOT | (a, c)
    CNOT | (c, b)

def Add(eng, a, b, a_first, a_last, b_first, b_last, c0):
    MAJ(eng, a[a_first], b[b_first], c0)
    for i in range (7):
        MAJ(eng, a[(i + a_first+1)%8], b[(i+b_first+1)%8], a[(a_first+i)%8])

    for i in range (7):
        UMA(eng, a[(a_last - i)%8], b[(b_last - i)%8], a[(a_last-1-i)%8])
    UMA(eng, a[a_first], b[b_first], c0)


def Add_s(eng, a, b, a_first, a_last, b_first, b_last, c0): # 7bit + 8bit
    MAJ(eng, a[a_first], b[b_first], c0)
    for i in range (6):
        MAJ(eng, a[(i + a_first+1)%7], b[(i+b_first+1)%8], a[(a_first+i)%7])
    MAJ(eng, a[7], b[b_last], a[a_last])

    UMA(eng, a[7], b[b_last], a[a_last])
    for i in range (6):
        UMA(eng, a[(a_last - i)%7], b[(b_last-1-i)%8], a[(a_last-1-i)%7])
    UMA(eng, a[a_first], b[b_first], c0)

def MAJ_reverse(eng,a,b,c):
    Toffoli | (c,  b, a)
    CNOT | (a, c)
    CNOT | (a, b)

def UMA_reverse(eng,a,b,c):
    CNOT | (c, b)
    CNOT | (a, c)
    Toffoli | (c, b, a)

def Add_s_reverse(eng, a, b, a_first, a_last, b_first, b_last, c0):
    UMA_reverse(eng, a[a_first], b[b_first], c0)

    for i in range (6):
        UMA_reverse(eng, a[(a_first+1 + i)%7], b[(b_first+1 + i)%8], a[(a_first+i)%7])
    UMA_reverse(eng, a[7], b[b_last], a[a_last])

    MAJ_reverse(eng, a[7], b[b_last], a[a_last])
    for i in range (6):
        MAJ_reverse(eng, a[(a_last-i)%7], b[(b_last-1-i)%8], a[(a_last-1-i)%7])

    MAJ_reverse(eng, a[a_first], b[b_first], c0)

def F0_Add(eng, a, b, c0): # add normal to F0
    MAJ(eng, a[0], b[1], c0)
    MAJ(eng, a[1], b[0], a[0])
    MAJ(eng, a[2], b[3], a[1])
    MAJ(eng, a[3], b[7], a[2])
    MAJ(eng, a[4], b[2], a[3])
    MAJ(eng, a[5], b[4], a[4])
    MAJ(eng, a[6], b[5], a[5])
    MAJ(eng, a[7], b[6], a[6])

    UMA(eng, a[7], b[6], a[6])
    UMA(eng, a[6], b[5], a[5])
    UMA(eng, a[5], b[4], a[4])
    UMA(eng, a[4], b[2], a[3])
    UMA(eng, a[3], b[7], a[2])
    UMA(eng, a[2], b[3], a[1])
    UMA(eng, a[1], b[0], a[0])
    UMA(eng, a[0], b[1], c0)


def F0_Add_Reverse(eng, a, b, c0):
    UMA_reverse(eng, a[0], b[1], c0)
    UMA_reverse(eng, a[1], b[0], a[0])
    UMA_reverse(eng, a[2], b[3], a[1])
    UMA_reverse(eng, a[3], b[7], a[2])
    UMA_reverse(eng, a[4], b[2], a[3])
    UMA_reverse(eng, a[5], b[4], a[4])
    UMA_reverse(eng, a[6], b[5], a[5])
    UMA_reverse(eng, a[7], b[6], a[6])

    MAJ_reverse(eng, a[7], b[6], a[6])
    MAJ_reverse(eng, a[6], b[5], a[5])
    MAJ_reverse(eng, a[5], b[4], a[4])
    MAJ_reverse(eng, a[4], b[2], a[3])
    MAJ_reverse(eng, a[3], b[7], a[2])
    MAJ_reverse(eng, a[2], b[3], a[1])
    MAJ_reverse(eng, a[1], b[0], a[0])
    MAJ_reverse(eng, a[0], b[1], c0)

def F0_CNOT(eng, a, b): # CNOT normal to F0

    CNOT | (a[0], b[1])
    CNOT | (a[1], b[0])
    CNOT | (a[2], b[3])
    CNOT | (a[3], b[7])
    CNOT | (a[4], b[2])
    CNOT | (a[5], b[4])
    CNOT | (a[6], b[5])
    CNOT | (a[7], b[6])

def F1_CNOT(eng, a, b):  #  CNOT normal to F1

    CNOT | (a[0], b[5])
    CNOT | (a[1], b[6])
    CNOT | (a[2], b[7])
    CNOT | (a[3], b[0])
    CNOT | (a[4], b[1])
    CNOT | (a[5], b[2])
    CNOT | (a[6], b[3])
    CNOT | (a[7], b[4])

    # 4 3 2 1 0 7 6 5

def X_CNOT(eng, a, b): # CNOT f0 to normal

    CNOT | (a[1], b[0])
    CNOT | (a[0], b[1])
    CNOT | (a[3], b[2])
    CNOT | (a[7], b[3])
    CNOT | (a[2], b[4])
    CNOT | (a[4], b[5])
    CNOT | (a[5], b[6])
    CNOT | (a[6], b[7])


def X_Add(eng, a, b, c0): # Add f0 to normal
    MAJ(eng, a[1], b[0], c0)
    MAJ(eng, a[0], b[1], a[1])
    MAJ(eng, a[3], b[2], a[0])
    MAJ(eng, a[7], b[3], a[3])
    MAJ(eng, a[2], b[4], a[7])
    MAJ(eng, a[4], b[5], a[2])
    MAJ(eng, a[5], b[6], a[4])
    MAJ(eng, a[6], b[7], a[5])

    UMA(eng, a[6], b[7], a[5])
    UMA(eng, a[5], b[6], a[4])
    UMA(eng, a[4], b[5], a[2])
    UMA(eng, a[2], b[4], a[7])
    UMA(eng, a[7], b[3], a[3])
    UMA(eng, a[3], b[2], a[0])
    UMA(eng, a[0], b[1], a[1])
    UMA(eng, a[1], b[0], c0)

def X1_Add(eng, a, b, c0): # Add F1 to normal
    MAJ(eng, a[5], b[0], c0)
    MAJ(eng, a[6], b[1], a[5])
    MAJ(eng, a[7], b[2], a[6])
    MAJ(eng, a[0], b[3], a[7])
    MAJ(eng, a[1], b[4], a[0])
    MAJ(eng, a[2], b[5], a[1])
    MAJ(eng, a[3], b[6], a[2])
    MAJ(eng, a[4], b[7], a[3])

    UMA(eng, a[4], b[7], a[3])
    UMA(eng, a[3], b[6], a[2])
    UMA(eng, a[2], b[5], a[1])
    UMA(eng, a[1], b[4], a[0])
    UMA(eng, a[0], b[3], a[7])
    UMA(eng, a[7], b[2], a[6])
    UMA(eng, a[6], b[1], a[5])
    UMA(eng, a[5], b[0], c0)




Resource = ResourceCounter()
eng = MainEngine(Resource)
Enc(eng)
print(Resource)

eng.flush()
