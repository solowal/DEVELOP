/*
 * AVR_revised_CHAM_8way.c
 *
 * Created: 2020-04-29 오후 8:03:58
 * Author : HD
 */ 

#include <avr/io.h>
#include <avr/pgmspace.h>
typedef uint32_t u32;
typedef uint16_t u16;

extern void CHAM_EncryptBlk(u16 *X, u16 *RK);
extern void CHAM_Enc64_Parallel(u16 *X, u16 *RK);
extern void CHAM_Enc64_Tri_Parallel(u16 *X, u16 *RK);
extern void CHAM_Enc64_CTR(u16 *X, u16 *RK);
extern void CHAM_Enc64_32bit_CTR(u16 *X, u16 *RK);
extern void CHAM_Enc64_Parallel_CTR(u16 *X, u16 *RK);
extern void CHAM_Enc64_Tri_Parallel_CTR(u16 *X, u16 *RK);

extern void CHAM_EncryptBlk128(u32 *X128, u16 *RK128);
extern void CHAM_Enc128_CTR(u32 *X128, u16 *RK128);

extern void CHAM_EncryptBlk256(u32 *X256, u32 *RK256);
extern void CHAM_Enc256_CTR(u32 *X256, u16 *RK256);

extern void CHAM_Enc64_pre_compute(u16 *X, u16 *RK, u16 *table);
extern void CHAM_Enc64_32bit_pre_compute(u16 *X, u16 *RK, u16 *table);
extern void CHAM_Enc128_pre_compute(u32 *X, u16 *RK, u32 *table);
extern void CHAM_Enc256_pre_compute(u32 *X, u16 *RK, u32 *table);

extern void CHAM_Enc64_CTR_F0(u16 *X, u16 *RK, u16 *table);
extern void CHAM_Enc64_CTR_F1(u16 *X, u16 *RK, u16 *table);

extern void CHAM_Enc64_32bit_CTR_F0(u16 *X, u16 *RK, u16 *table);
extern void CHAM_Enc64_32bit_CTR_F1(u16 *X, u16 *RK, u16 *table);

extern void CHAM_Enc128_CTR_F0(u32 *X, u16 *RK, u32 *table);
extern void CHAM_Enc128_CTR_F1(u32 *X, u16 *RK, u32 *table);

extern void CHAM_Enc256_CTR_F0(u32 *X, u16 *RK, u32 *table);
extern void CHAM_Enc256_CTR_F1(u32 *X, u16 *RK, u32 *table);


// Toolchain -> AVR/GNU Linker -> Memory Settings -> SRAM .MySection=0x400
u16 RK[16] __attribute__ ((section(".MySection64"))) = { 0x0301,0x0705,0x0b09,0x0f0d,0x1311,0x1715,0x1b19,0x1f1d,0x151e,0x0308,0x3932,0x2f24,0x4d46,0x5b50,0x616a,0x777c};
u16 pt64_1[] = {0x1100, 0x3322, 0x5544, 0x7766};
u16 pt64_2[] = {0x1100, 0x3322, 0x5544, 0x7766, 0x1100, 0x3322, 0x5544, 0x7766};
u16 pt64_3[] = {0x1100, 0x3322, 0x5544, 0x7766, 0x1100, 0x3322, 0x5544, 0x7766, 0x1100, 0x3322, 0x5544, 0x7766};
u16 table64[32] __attribute__ ((aligned(256)))= {0, };

	
u16 RK128[16] __attribute__ ((section(".MySection128"))) = { 0x0303,0x0707,0x0b0b,0x0f0f,0x1313,0x1717,0x1b1b,0x1f1f,0x2f34,0x3922,0x0318,0x150e,0x776c,0x617a,0x5b40,0x4d56};
u32 pt128_1[] = {0x33221100, 0x77665544, 0xbbaa9988, 0xffeeddcc};
u32 table128[32] __attribute__ ((aligned(256)))= {0, };


u16 RK256[32] __attribute__ ((section(".MySection256"))) = { 0x0303,0x0707,0X0b0b,0x0f0f,0X1313,0x1717,0X1b1b,0x1f1f,0Xe2e2,0xe6e6,0Xeaea,0xeeee,0Xf2f2,0xf6f6,0Xfafa,0xfefe,0x2f34,0x3922,0x0318,0x150e,0x776c,0x617a,0x5b40,0x4d56,0xb9a2,0xafb4,0x958e,0x8398,0xe1fa,0xf7ec,0xcdd6,0xdbc0};
u32 pt256_1[] = {0x33221100, 0x77665544, 0xbbaa9988, 0xffeeddcc};
u32 table256[32] __attribute__ ((aligned(256)))= {0, };

u16 pt64_1m[] = {0x1100, 0x3322, 0x5544, 0x7766};
u32 pt128_1m[] = {0x33221100, 0x77665544, 0xbbaa9988, 0xffeeddcc};
u32 pt256_1m[] = {0x33221100, 0x77665544, 0xbbaa9988, 0xffeeddcc};


int main(void)
{

//	CHAM_EncryptBlk(pt64_1, RK);
// 	CHAM_Enc64_Parallel(pt64_2, RK);
//	CHAM_Enc64_Tri_Parallel(pt64_3, RK);
// 	CHAM_Enc64_CTR(pt64_1, RK);
// 	CHAM_Enc64_Parallel_CTR(pt64_2, RK);
// 	CHAM_Enc64_Tri_Parallel_CTR(pt64_3, RK);

//	CHAM_Enc64_32bit_CTR(pt64_1, RK);				// LDI 사전 연산 모델

// 	CHAM_EncryptBlk128(pt128_1, RK128);
// 	CHAM_Enc128_CTR(pt128_1, RK128);
	
//	CHAM_EncryptBlk256(pt256_1, RK256);
// 	CHAM_Enc256_CTR(pt256_1, RK256);


//	CHAM_Enc64_pre_compute(pt64_1, RK, table64);
//	CHAM_Enc128_pre_compute(pt128_1, RK128, table128);
//	CHAM_Enc256_pre_compute(pt256_1, RK256, table256);
		
//	CHAM_Enc64_CTR_F0(pt64_1, RK, table64);
//	CHAM_Enc64_CTR_F1(pt64_1m, RK, table64);

//	CHAM_Enc64_32bit_pre_compute(pt64_1, RK, table64);
	CHAM_Enc64_32bit_CTR_F0(pt64_1, RK, table64);
	CHAM_Enc64_32bit_CTR_F1(pt64_1m, RK, table64);			// 수정 필요

//	CHAM_Enc128_CTR_F0(pt128_1, RK128, table128);
//	CHAM_Enc128_CTR_F1(pt128_1m, RK128, table128);
	
//	CHAM_Enc256_CTR_F0(pt256_1, RK256, table256);
//	CHAM_Enc256_CTR_F1(pt256_1m, RK256, table256);
	
// 64/128 test vector	
//	RK: 0x0301, 0x0705, 0x0b09, 0x0f0d, 0x1311, 0x1715, 0x1b19, 0x1f1d, 0x151e, 0x0308, 0x3932, 0x2f24, 0x4d46, 0x5b50, 0x616a, 0x777c
//	PT: 0x1100, 0x3322, 0x5544, 0x7766
//	CT: 0x6579 0x1204 0x123f 0xe5a9

//	PT: 0x0000 0x3322 0x5544 0x7766
//	CT: 0x9565,0xba14,0x4054,0xbfdd


// 128/128 test vector
// RK: 0x0303, 0x0707, 0x0b0b, 0x0f0f, 0x1313, 0x1717, 0x1b1b, 0x1f1f, 0x2f34, 0x3922, 0x0318, 0x150e, 0x776c, 0x617a, 0x5b40, 0x4d56
// PT: 0x1100, 0x3322, 0x5544, 0x7766
// CT: 0xd05419ee, 0x9f118f4c, 0x99e36469, 0x1c885ec1

// 128/256 test vector
// RK: 0x0303,0x0707,0X0b0b,0x0f0f,0X1313,0x1717,0X1b1b,0x1f1f,0Xe2e2,0xe6e6,0Xeaea,0xeeee,0Xf2f2,0xf6f6,0Xfafa,0xfefe,0x2f34,0x3922,0x0318,0x150e,0x776c,0x617a,0x5b40,0x4d56,0xb9a2,0xafb4,0x958e,0x8398,0xe1fa,0xf7ec,0xcdd6,0xdbc0
// PT: 0x33221100, 0x77665544, 0xbbaa9988, 0xffeeddcc
// CT: 0x027377dc, 0x120b5651, 0x8f839b95, 0x5e5ec075

//	revised_enc64(plaintext64, SK, C);
	
}