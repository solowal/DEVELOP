/*
 * AES_GCM.c
 *
 * Created: 2020-01-20 오후 6:25:59
 * Author : kyung
 */ 

#include <avr/io.h>
#include "aes_types.h"

#define PTLength 16 // SET PT Length
typedef unsigned char u8;

void aes128_init(const void *key, aes128_ctx_t *ctx);
void aes128_enc(void *buffer, aes128_ctx_t *ctx, u8 counter);
void aes192_init(const void *key, aes192_ctx_t *ctx);
void aes192_enc(void *buffer, aes192_ctx_t *ctx, u8 counter);
void aes256_init(const void *key, aes128_ctx_t *ctx);
void aes256_enc(void *buffer, aes128_ctx_t *ctx, u8 counter);

extern void mul128(uint8_t *c,uint8_t *b,uint8_t *a);

u8 temp[36] = {0x66, 0xe9, 0x4b, 0xd4, 0xef, 0x8a, 0x2c, 0x3b, 0x89, 0x63, 0x67, 0xef, 0x88, 0x4c, 0xfa, 0x59, 0xca, 0x34, 0x2b, 0x2e, 0x42, 0x78,	0xd1, 0x77, 0xee, 0xa5, 0xb1, 0x8d, 0x25, 0xbe, 0x07, 0x15, 0xcb, 0x1b, 0xb6, 0x98};
u8 T[32];
u8 pt[2048] = {0,};
	
int main(void)
{
		u8 key[16] = {0,};
		u8 result[2048] = {0,};
		int i = 0;
		aes256_ctx_t aes_test;
		aes256_init(key, &aes_test);
		aes256_enc(result ,&aes_test, 16); // J0
		
		// Encryption
		for(i = 2; i < (PTLength >> 4) + 2; i++)
		{
			aes256_enc(result ,&aes_test, (i << 4));
			for(int j = 0; j < 16; j++)
				result[j + (i << 4)] ^= pt[j + (i << 4)]; // pt set zero
		}
		// GHASH
		for(i = 2; i < (PTLength >> 4) + 2; i++)
		{
			mul128(T,result+(i << 4),temp);
		}
		// GHASH LAST(LANGTH)
		T[15] ^= (PTLength << 3) & 0xff;
		T[14] ^= (PTLength << 3) >> 8;
		
		mul128(T,T,temp);
		
		// SET T
		for(int i = 0; i < 16; i++)
				T[i] ^= result[i + 16];
				
		return 0;
	
}

