/*
 * faceplus.c
 *
 * Created: 2019-09-05 오전 8:09:33
 * Author : kyung
 */ 

#include <avr/io.h>
#include <stdio.h>
#include <stdlib.h>
#include "aes_types.h"

void aes128_init(const void *key, aes256_ctx_t *ctx);
void aes128_enc(void *buffer, aes256_ctx_t *ctx);
void aes192_init(const void *key, aes256_ctx_t *ctx);
void aes192_enc(void *buffer, aes256_ctx_t *ctx);

void aes256_init(const void *key, aes256_ctx_t *ctx);
void aes256_enc(void *buffer, aes256_ctx_t *ctx);

aes_genctx_t ctx;
aes_cipher_state_t state;

int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
		  uint8_t key[32]={0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c};
		  uint8_t buffer[16]={0,};

		  aes192_ctx_t aes_test;

		  aes192_init(key, &aes_test);
		  aes192_enc(buffer,&aes_test);
    }
}

