//
//  SceneDelegate.h
//  AES_128_TEST
//
//  Created by info on 2021/06/10.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

