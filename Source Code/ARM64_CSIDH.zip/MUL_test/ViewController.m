//
//  ViewController.m
//  MUL_test
//
//  Created by hwajeong seo on 2021/01/26.
//

#import "ViewController.h"
#include "csidh_api.h"
#include "arith_test.h"
#include "arith.h"
#include "csidh_api.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#define BENCH_COUNT     10
#define TEST_COUNT      1

int64_t cpucycles(void)
{ // Access system counter for benchmarking
    struct timespec time;

    clock_gettime(CLOCK_MONOTONIC, &time);
    return (int64_t)(time.tv_sec*1e9 + time.tv_nsec);
}

int csidh_test()
{
    int i;
    public_key_t alice_pub, bob_pub;
    private_key_t alice_priv, bob_priv;
    shared_secret_t alice_shared, bob_shared;

    fp_init_zero(alice_pub->A);
    fp_init_zero(bob_pub->A);
    fp_init_zero(bob_shared->A);
    fp_init_zero(alice_shared->A);
    
    bool passed = true;
    bool valid = true;
#ifdef _CONSTANT_
    printf("\n\nTESTING CONSTANT-TIME CSIDH KEY-EXCHANGE CSIDH_P511\n");
    printf("---------------------------------------------------\n\n");
#else
    printf("\n\nTESTING NON-CONSTANT TIME CSIDH KEY-EXCHANGE CSIDH_P511\n");
    printf("-------------------------------------------------------\n\n");
#endif
    for(i = 0; i < TEST_COUNT; i++)
    {
        csidh_keypair(alice_priv, alice_pub);
        csidh_keypair(bob_priv, bob_pub);

        valid = csidh_validate(bob_pub);
        valid = csidh_validate(alice_pub);
        csidh_sharedsecret(bob_pub, alice_priv, alice_shared);
        csidh_sharedsecret(alice_pub, bob_priv, bob_shared);
                
        if(memcmp(alice_shared, bob_shared, NWORDS_64 * 8) != 0)
        {
            passed = false;
            fp_print(alice_shared->A);fp_print(bob_shared->A);
            break;
        }
    }

    if (passed == true)
    {
        printf("   CSIDH tests..........................................PASSED");
        if(!valid)
        {
            printf("\n   Public-key Validation................................FAILED");
        }else
        {
            printf("\n   Public-key Validation................................PASSED");
        }
    }
    else
    {
        printf("   CSIDH tests..........................................FAILED\n");
        if(!valid)
        {
            printf("\n   Public-key Validation................................FAILED");
        }else
        {
            printf("\n   Public-key Validation................................PASSED");
        }
    
        return 0;   // FAILED
    }
	
	
    
	
    return 1;   // PASSED
}

void csidh_bench()
{
    int i;
    public_key_t alice_pub, bob_pub;
    private_key_t alice_priv, bob_priv;
    shared_secret_t alice_shared, bob_shared;
    unsigned long long cycles, start, end, alice_total = 0, bob_total = 0;

    fp_init_zero(alice_pub->A);
    fp_init_zero(bob_pub->A);
    fp_init_zero(bob_shared->A);
    fp_init_zero(alice_shared->A);
    for(i = 0; i < NWORDS_64; i++)
    {
        alice_priv->exponents[i] = 0;
        bob_priv->exponents[i] = 0;
    }

#ifdef _CONSTANT_
    printf("\n\nBENCHMARKING CONSTANT-TIME CSIDH KEY-EXCHANGE CSIDH_P511\n");
    printf("----------------------------------------------------------\n\n");
#else
    printf("\n\nBENCHMARKING NON-CONSTANT TIME CSIDH KEY-EXCHANGE CSIDH_P511\n");
    printf("------------------------------------------------------------\n\n");
#endif

    // Benchmarking key generation
    cycles = 0;
    for(i = 0; i < BENCH_COUNT; i++)
    {
        start = cpucycles();
        csidh_keypair(alice_priv, alice_pub);
        end = cpucycles();
        cycles = cycles + (end - start);
    }
    printf("Alice Key generation runs in..............................%10lld nsec\n", cycles/BENCH_COUNT);
    alice_total = cycles/BENCH_COUNT;

    cycles = 0;
    for(i = 0; i < BENCH_COUNT; i++)
    {
        start = cpucycles();
        csidh_keypair(bob_priv, bob_pub);
        end = cpucycles();
        cycles = cycles + (end - start);
    }
    printf("Bob Key generation runs in................................%10lld nsec\n", cycles/BENCH_COUNT);
    bob_total = cycles/BENCH_COUNT;

    // Benchmarking Public-key validation
    cycles = 0;
    for(i = 0; i < BENCH_COUNT; i++)
    {
        start = cpucycles();
        csidh_validate(bob_pub);
        end = cpucycles();
        cycles = cycles + (end - start);
    }
    printf("Alice validation of Bob's Public-Key runs in..............%10lld nsec\n", cycles/BENCH_COUNT);
    alice_total += cycles/BENCH_COUNT;

    cycles = 0;
    for(i = 0; i < BENCH_COUNT; i++)
    {
        start = cpucycles();
        csidh_validate(alice_pub);
        end = cpucycles();
        cycles = cycles + (end - start);
    }
    printf("Bob validation of Alice's Public-Key runs in..............%10lld nsec\n", cycles/BENCH_COUNT);
    bob_total += cycles/BENCH_COUNT;

    // Benchmarking shared-secret computations
    cycles = 0;
    for(i = 0; i < BENCH_COUNT; i++)
    {
        start = cpucycles();
        csidh_sharedsecret(bob_pub, alice_priv, alice_shared);
        end = cpucycles();
        cycles = cycles + (end - start);
    }
    printf("Alice Shared key generation runs in.......................%10lld nsec\n", cycles/BENCH_COUNT);
    alice_total += cycles/BENCH_COUNT;

    cycles = 0;
    for(i = 0; i < BENCH_COUNT; i++)
    {
        start = cpucycles();
        csidh_sharedsecret(alice_pub, bob_priv, bob_shared);
        end = cpucycles();
        cycles = cycles + (end - start);
    }
    printf("Bob Shared key generation runs in.........................%10lld nsec\n", cycles/BENCH_COUNT);
    bob_total += cycles/BENCH_COUNT;

    printf("\nAlice Total computations runs in.........................%10lld nsec\n", alice_total);
    printf("Bob Total computations runs in...........................%10lld nsec\n\n", bob_total);
    /**/
	
	
	
	felm_t a={0}, b={0}, acpy={0}, bcpy={0}, c={0}, d={0}, c1={0}, c2={0}, c3={0}, c4={0};
	fp_random_512(a);fp_random_512(b); fp_random_512(c);
	
	
	cycles = 0;
    start = cpucycles();
    for(i = 0; i < 100000; i++)
    {
        
        fp_mul_mont_512(a, b, c);
        
    }
    end = cpucycles();
    cycles = cycles + (end - start);
    printf("mul generation runs in.........................%10lld/100000= %10lld nsec\n", cycles, cycles/100000);
	
	
	
	
    return;
}


/////////
#define NUM_SIZE 16

unsigned int a[NUM_SIZE]={0x6041903B
    ,  0x7BDB6F70
    ,  0x21DCC2A5
    ,  0x2C4874D0
    ,  0x3C68E7EE
    ,  0xF0FC3906
    ,  0x5C14A48C
    ,  0xEC266DBF
    ,  0xB3F7099C
    ,  0xDAA3561E
    ,  0xFC79E93A
    ,  0x42F30FE5
    ,  0xEE629AC7
    ,  0x6CC60AFB
    ,  0xB93D5AEB
    ,  0x3A8E5762};
unsigned int b[NUM_SIZE]={0x2FFC1724
    ,  0x36905B57
    ,  0x25F1F27D
    ,  0x67086F45
    ,  0xD22370CA
    ,  0x4FAF3FBF
    ,  0xBCC584B1
    ,  0x192EA214
    ,  0x2F5DE3D0
    ,  0x5DAE03EE
    ,  0x1776B371
    ,  0x1E924873
    ,  0x20E4F52D
    ,  0xAD5F166E
    ,  0xA6F3917E
    ,  0x4ED759AE};
unsigned int c[2*NUM_SIZE]={0,};
unsigned int d[NUM_SIZE]={0,};

extern void mul503_asm (unsigned int * a,unsigned int *b, unsigned int *c);
extern void rdc503_asm (unsigned int * a,unsigned int *c);



@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
  //  mul503_asm(a,b,c);
  //  rdc503_asm(c,d);
/*
    for(int i=0;i<2*NUM_SIZE;i++){
        printf("%x\n",c[i]);
    }
  */
    printf("\n");
    
    /*for(int i=0;i<NUM_SIZE;i++){
        printf("0x%x\n",d[i]);
        
    }*/
    
    int passed;
    
    passed = test_fp_arithmetic();

    if(passed)
    {
        printf("\nfp arithmetic tests passed\n");
    }else{
        printf("\nfp arithmetic tests failed\n");
    }
    
    passed = 1;
    passed = csidh_test();

    if (!passed)
    {
        printf("\n\n Error: SHARED_KEY");
    }

    csidh_bench();
    /**/
    int i;
    uint64_t tmp[16];
    uint64_t tmp2[16];
    felm_t a={0x371A1A82F511BD01
        ,  0xDBDA7434B6EF5666
        ,  0xDA805D004B77208F
        ,  0x36CB747016CBC4D5
        ,  0xBF331AF26DA3B9ED
        ,  0x7975392F30320084
        ,  0x6C20DEDA71509F41
        ,  0x49E4B9B749F5794A

        

        }, b={0x36905B572FFC1724
            ,  0x67086F4525F1F27D
            ,  0x4FAF3FBFD22370CA
            ,  0x192EA214BCC584B1
            ,  0x5DAE03EE2F5DE3D0
            ,  0x1E9248731776B371
            ,  0xAD5F166E20E4F52D
            ,  0x4ED759AEA6F3917E}, c={0}, d={0};
    for(i=0;i<0;i++){
    fp_random_512(a);fp_random_512(b);
    
        fp_mul_mont_512(a,b,c);
        //mul503_asm(a,b,d);
        //rdc503_asm(tmp,d);
        //fp_print(tmp);
    if(memcmp(c, d, 64) != 0)
    {
        fp_print(a);
        fp_print(b);
        
        //fp_print(tmp);
        
        fp_print(tmp2);
        fp_print(d);
        passed = 0;
    }
    }
    
}


@end
