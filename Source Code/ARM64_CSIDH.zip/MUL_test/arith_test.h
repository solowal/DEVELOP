//
//  arith_test.h
//  MUL_test
//
//  Created by hwajeong seo on 2021/01/26.
//

#ifndef arith_test_h
#define arith_test_h

int test_fp_arithmetic();

#endif /* arith_test_h */
