/* Copyright 2019 SiFive, Inc */
/* SPDX-License-Identifier: Apache-2.0 */

#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "util.h"

#define NUM_OF_ROUND 64

extern void mul_asm(uint32_t* a,uint32_t* b,uint32_t* c, uint32_t length);

uint32_t a[NUM_OF_ROUND]={0xBBAA13E7
		,0x2656A456
		,0xD24BBD11
		,0x262E6963
		,0xCA49AE00
		,0x4EA3F2AB
		,0x1762E302
		,0x92E10DCE
		,0xC2C1F78A
		,0x90739A37
		,0x4C762929
		,0x2081B8BD
		,0xFBF25989
		,0x5A3C0CF5
		,0xA31C195E
		,0xBD4058B9};
uint32_t b[NUM_OF_ROUND]={0x58584336
		,0x2F863F67
		,0xE5CD9BDF
		,0xA1094E50
		,0x32D41DCA
		,0x90FE3098
		,0x4BF59FF8
		,0xD92E1D37
		,0xF7828C49
		,0xC30A3550
		,0x9C64B14D
		,0x10500F2F
		,0x4D10ADF2
		,0xFCBAB6E8
		,0x71431F9
		,0x989F9776};
uint32_t c[NUM_OF_ROUND*2]={0,};

int main() {


	uint64_t oldcount = getcycles();

	for(int i=0;i<100000;i++)
		mul_asm(a,b,c,4*NUM_OF_ROUND);

    uint64_t cyclecount = getcycles()-oldcount;

/*
    for(int i=0;i<NUM_OF_ROUND*2;i++){
    	printf("%x\n", c[i]);
    }
*/

    printf("cyc: %u\n", (unsigned int)cyclecount);
}
