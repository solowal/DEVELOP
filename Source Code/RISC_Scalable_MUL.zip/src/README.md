# hello
A simple "Hello, World!" example to demonstrate printf and build environment.
