#ifndef UTIL_H
#define UTIL_H

#include <stdint.h>

uint64_t getcycles();
uint64_t getinstret();

#endif
