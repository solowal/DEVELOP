# cmsis-svd-generator
Generates CMSIS-SVD xml files from DTS info and Register templates in the regmaps directory.
