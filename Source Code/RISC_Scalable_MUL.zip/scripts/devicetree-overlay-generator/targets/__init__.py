#!/usr/bin/env python3

import targets.arty
import targets.generic
import targets.hifive
import targets.qemu
import targets.spike
import targets.testbench
import targets.vc707
import targets.vcu118
