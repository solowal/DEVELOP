Watchdog
========

.. doxygenfile:: metal/watchdog.h
   :project: metal

