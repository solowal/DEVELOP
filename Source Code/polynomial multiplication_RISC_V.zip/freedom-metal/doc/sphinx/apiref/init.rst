Constructors and Destructors
============================

.. doxygenfile:: metal/init.h
   :project: metal
   :no-link:

