/* Copyright 2019 SiFive, Inc */
/* SPDX-License-Identifier: Apache-2.0 */

#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "util.h"

#define para_256 8

uint32_t a[4]={0x12345678,0x90ABCDEF,0x01020304,0x05060708};
//uint32_t a[16]={0xffffffff,0xffffffff,0xffffffff,0xffffffff,0xffffffff,0xffffffff,0xffffffff,0xffffffff,0xffffffff,0xffffffff,0xffffffff,0xffffffff,0xffffffff,0xffffffff,0xffffffff,0xffffffff};
uint32_t b[4]={0x09000A0B,0x0C0D0E0F,0x11121314,0x15161718};
//uint32_t b[16]={0xffffffff,0xffffffff,0xffffffff,0xffffffff,0xffffffff,0xffffffff,0xffffffff,0xffffffff,0xffffffff,0xffffffff,0xffffffff,0xffffffff,0xffffffff,0xffffffff,0xffffffff,0xffffffff};
uint32_t c[32]={0,};

//128-bit
void binary_mul_ver0(uint32_t* a,uint32_t* b,uint32_t* c);			 //basic bit checking
extern void binary_mul_ver1_asm(uint32_t* a,uint32_t* b,uint32_t* c);// LUT based
extern void binary_mul_ver2_asm(uint32_t* a,uint32_t* b,uint32_t* c);// secure bit checking

//256-bit
void Karatsuba_mul_256_ver0(uint32_t* a,uint32_t* b,uint32_t* c, uint32_t len);
void Karatsuba_mul_256_ver1(uint32_t* a,uint32_t* b,uint32_t* c, uint32_t len);
void Karatsuba_mul_256_ver2(uint32_t* a,uint32_t* b,uint32_t* c, uint32_t len);

//512-bit
void Karatsuba_mul_512_ver0(uint32_t* a,uint32_t* b,uint32_t* c, uint32_t len);
void Karatsuba_mul_512_ver1(uint32_t* a,uint32_t* b,uint32_t* c, uint32_t len);
void Karatsuba_mul_512_ver2(uint32_t* a,uint32_t* b,uint32_t* c, uint32_t len);

int main() {

	uint64_t oldcount = getcycles();
	for(int i=0;i<10000;i++)
		binary_mul_ver0(a,b,c);
		//Karatsuba_mul_256_ver0(a,b,c,8);
		//Karatsuba_mul_512_ver0(a,b,c,16);
    uint64_t cyclecount = getcycles()-oldcount;
    printf("0cyc: %u\n", (unsigned int)cyclecount);

    oldcount = getcycles();
	for(int i=0;i<10000;i++)
		binary_mul_ver1_asm(a,b,c);
		//Karatsuba_mul_256_ver1(a,b,c,8);
		//Karatsuba_mul_512_ver1(a,b,c,16);
	cyclecount = getcycles()-oldcount;
	printf("1cyc: %u\n", (unsigned int)cyclecount);

	oldcount = getcycles();
	for(int i=0;i<10000;i++)
		binary_mul_ver2_asm(a,b,c);
		//Karatsuba_mul_256_ver2(a,b,c,8);
		//Karatsuba_mul_512_ver2(a,b,c,16);
	cyclecount = getcycles()-oldcount;
	printf("2cyc: %u\n", (unsigned int)cyclecount);

	//////////////////////////////////////////////////////////////////////////////

	 oldcount = getcycles();
	for(int i=0;i<10000;i++)
		//binary_mul_ver0(a,b,c);
		Karatsuba_mul_256_ver0(a,b,c,8);
		//Karatsuba_mul_512_ver0(a,b,c,16);
     cyclecount = getcycles()-oldcount;
    printf("0cyc: %u\n", (unsigned int)cyclecount);

    oldcount = getcycles();
	for(int i=0;i<10000;i++)
		//binary_mul_ver1_asm(a,b,c);
		Karatsuba_mul_256_ver1(a,b,c,8);
		//Karatsuba_mul_512_ver1(a,b,c,16);
	cyclecount = getcycles()-oldcount;
	printf("1cyc: %u\n", (unsigned int)cyclecount);

	oldcount = getcycles();
	for(int i=0;i<10000;i++)
		//binary_mul_ver2_asm(a,b,c);
		Karatsuba_mul_256_ver2(a,b,c,8);
		//Karatsuba_mul_512_ver2(a,b,c,16);
	cyclecount = getcycles()-oldcount;
	printf("2cyc: %u\n", (unsigned int)cyclecount);

	////////////////////////////////////////////////////////////////////////////////////////
	 oldcount = getcycles();
	for(int i=0;i<10000;i++)
		//binary_mul_ver0(a,b,c);
		//Karatsuba_mul_256_ver0(a,b,c,8);
		Karatsuba_mul_512_ver0(a,b,c,16);
     cyclecount = getcycles()-oldcount;
    printf("0cyc: %u\n", (unsigned int)cyclecount);

    oldcount = getcycles();
	for(int i=0;i<10000;i++)
		//binary_mul_ver1_asm(a,b,c);
		//Karatsuba_mul_256_ver1(a,b,c,8);
		Karatsuba_mul_512_ver1(a,b,c,16);
	cyclecount = getcycles()-oldcount;
	printf("1cyc: %u\n", (unsigned int)cyclecount);

	oldcount = getcycles();
	for(int i=0;i<10000;i++)
		//binary_mul_ver2_asm(a,b,c);
		//Karatsuba_mul_256_ver2(a,b,c,8);
		Karatsuba_mul_512_ver2(a,b,c,16);
	cyclecount = getcycles()-oldcount;
	printf("2cyc: %u\n", (unsigned int)cyclecount);





	/*
	binary_mul_ver0(a,b,c);
	for(int i=0;i<8;i++) printf("%x\n", c[i]);
    binary_mul_ver1_asm(a,b,c);
    for(int i=0;i<8;i++) printf("%x\n", c[i]);
    binary_mul_ver2_asm(a,b,c);
    for(int i=0;i<8;i++) printf("%x\n", c[i]);
	*/
	//Karatsuba_mul_256_ver0(a,b,c,8);
    //Karatsuba_mul_256_ver1(a,b,c,8);
    //Karatsuba_mul_256_ver2(a,b,c,8);

	//Karatsuba_mul_512_ver0(a,b,c,16);
    //Karatsuba_mul_512_ver1(a,b,c,16);
    //Karatsuba_mul_512_ver2(a,b,c,16);

    //for(int i=0;i<16;i++) printf("%x\n", c[i]);

}

//128

void binary_mul_ver0(uint32_t* a,uint32_t* b,uint32_t* c){
	uint32_t i, j;
	uint32_t k=1;
	k = k<<31;

	uint32_t tmp0[8];
	for(i=0; i<8; i++){
		c[i] = 0;
	}

	for(i=0;i<32;i++){
		for(j=0;j<4;j++){
			if(k&a[j]){
				c[j+0] ^= b[0];
				c[j+1] ^= b[1];
				c[j+2] ^= b[2];
				c[j+3] ^= b[3];
			}
		}
		k = k>>1;
		if(i!=31){
			tmp0[0] = c[0] >> 31;
			tmp0[1] = c[1] >> 31;
			tmp0[2] = c[2] >> 31;
			tmp0[3] = c[3] >> 31;
			tmp0[4] = c[4] >> 31;
			tmp0[5] = c[5] >> 31;
			tmp0[6] = c[6] >> 31;

			c[0] = c[0] << 1;
			c[1] = c[1] << 1;
			c[2] = c[2] << 1;
			c[3] = c[3] << 1;
			c[4] = c[4] << 1;
			c[5] = c[5] << 1;
			c[6] = c[6] << 1;
			c[7] = c[7] << 1;

			c[1] = c[1] | tmp0[0];
			c[2] = c[2] | tmp0[1];
			c[3] = c[3] | tmp0[2];
			c[4] = c[4] | tmp0[3];
			c[5] = c[5] | tmp0[4];
			c[6] = c[6] | tmp0[5];
			c[7] = c[7] | tmp0[6];
			}
	}
}


//256
void Karatsuba_mul_256_ver0(uint32_t* a,uint32_t* b,uint32_t* c, uint32_t len){
	uint32_t i;
	uint32_t tmp0[len];
	uint32_t tmp1[len];
	uint32_t tmp2[len];

	uint32_t tmp_a[(len/2)];
	uint32_t tmp_b[(len/2)];

	for(i=0;i<(len/2);i++){
		tmp_a[i] = a[i] ^ a[i+(len/2)];
	}
	for(i=0;i<(len/2);i++){
		tmp_b[i] = b[i] ^ b[i+(len/2)];
	}

	binary_mul_ver0(a,b,tmp0);
	binary_mul_ver0(tmp_a,tmp_b,tmp1);
	binary_mul_ver0(&a[(len/2)],&b[(len/2)],tmp2);

	for(i=0;i<(len);i++){
		tmp1[i] = tmp0[i] ^ tmp2[i];
	}

	for(i=0;i<(len);i++){
		c[i] = tmp0[i];
	}

	for(i=0;i<(len);i++){
		c[i+len] = tmp2[i];
	}

	for(i=0;i<(len);i++){
		c[i+(len/2)] ^= tmp1[i];
	}
}

void Karatsuba_mul_256_ver1(uint32_t* a,uint32_t* b,uint32_t* c, uint32_t len){
	uint32_t i;
	uint32_t tmp0[len];
	uint32_t tmp1[len];
	uint32_t tmp2[len];

	uint32_t tmp_a[(len/2)];
	uint32_t tmp_b[(len/2)];

	for(i=0;i<(len/2);i++){
		tmp_a[i] = a[i] ^ a[i+(len/2)];
	}
	for(i=0;i<(len/2);i++){
		tmp_b[i] = b[i] ^ b[i+(len/2)];
	}

	binary_mul_ver1_asm(a,b,tmp0);
	binary_mul_ver1_asm(tmp_a,tmp_b,tmp1);
	binary_mul_ver1_asm(&a[(len/2)],&b[(len/2)],tmp2);

	for(i=0;i<(len);i++){
		tmp1[i] = tmp0[i] ^ tmp2[i];
	}

	for(i=0;i<(len);i++){
		c[i] = tmp0[i];
	}

	for(i=0;i<(len);i++){
		c[i+len] = tmp2[i];
	}

	for(i=0;i<(len);i++){
		c[i+(len/2)] ^= tmp1[i];
	}
}

void Karatsuba_mul_256_ver2(uint32_t* a,uint32_t* b,uint32_t* c, uint32_t len){
	uint32_t i;
	uint32_t tmp0[len];
	uint32_t tmp1[len];
	uint32_t tmp2[len];

	uint32_t tmp_a[(len/2)];
	uint32_t tmp_b[(len/2)];

	for(i=0;i<(len/2);i++){
		tmp_a[i] = a[i] ^ a[i+(len/2)];
	}
	for(i=0;i<(len/2);i++){
		tmp_b[i] = b[i] ^ b[i+(len/2)];
	}

	binary_mul_ver2_asm(a,b,tmp0);
	binary_mul_ver2_asm(tmp_a,tmp_b,tmp1);
	binary_mul_ver2_asm(&a[(len/2)],&b[(len/2)],tmp2);

	for(i=0;i<(len);i++){
		tmp1[i] = tmp0[i] ^ tmp2[i];
	}

	for(i=0;i<(len);i++){
		c[i] = tmp0[i];
	}

	for(i=0;i<(len);i++){
		c[i+len] = tmp2[i];
	}

	for(i=0;i<(len);i++){
		c[i+(len/2)] ^= tmp1[i];
	}
}

//512
void Karatsuba_mul_512_ver0(uint32_t* a,uint32_t* b,uint32_t* c, uint32_t len){
	uint32_t i;
	uint32_t tmp0[len];
	uint32_t tmp1[len];
	uint32_t tmp2[len];

	uint32_t tmp_a[(len/2)];
	uint32_t tmp_b[(len/2)];

	for(i=0;i<(len/2);i++){
		tmp_a[i] = a[i] ^ a[i+(len/2)];
	}
	for(i=0;i<(len/2);i++){
		tmp_b[i] = b[i] ^ b[i+(len/2)];
	}

	Karatsuba_mul_256_ver0(a,b,tmp0,8);
	Karatsuba_mul_256_ver0(tmp_a,tmp_b,tmp1,8);
	Karatsuba_mul_256_ver0(&a[(len/2)],&b[(len/2)],tmp2,8);

	for(i=0;i<(len);i++){
		tmp1[i] = tmp0[i] ^ tmp2[i];
	}

	for(i=0;i<(len);i++){
		c[i] = tmp0[i];
	}

	for(i=0;i<(len);i++){
		c[i+len] = tmp2[i];
	}

	for(i=0;i<(len);i++){
		c[i+(len/2)] ^= tmp1[i];
	}
}


void Karatsuba_mul_512_ver1(uint32_t* a,uint32_t* b,uint32_t* c, uint32_t len){
	uint32_t i;
	uint32_t tmp0[len];
	uint32_t tmp1[len];
	uint32_t tmp2[len];

	uint32_t tmp_a[(len/2)];
	uint32_t tmp_b[(len/2)];

	for(i=0;i<(len/2);i++){
		tmp_a[i] = a[i] ^ a[i+(len/2)];
	}
	for(i=0;i<(len/2);i++){
		tmp_b[i] = b[i] ^ b[i+(len/2)];
	}

	Karatsuba_mul_256_ver1(a,b,tmp0,8);
	Karatsuba_mul_256_ver1(tmp_a,tmp_b,tmp1,8);
	Karatsuba_mul_256_ver1(&a[(len/2)],&b[(len/2)],tmp2,8);

	for(i=0;i<(len);i++){
		tmp1[i] = tmp0[i] ^ tmp2[i];
	}

	for(i=0;i<(len);i++){
		c[i] = tmp0[i];
	}

	for(i=0;i<(len);i++){
		c[i+len] = tmp2[i];
	}

	for(i=0;i<(len);i++){
		c[i+(len/2)] ^= tmp1[i];
	}
}

void Karatsuba_mul_512_ver2(uint32_t* a,uint32_t* b,uint32_t* c, uint32_t len){
	uint32_t i;
	uint32_t tmp0[len];
	uint32_t tmp1[len];
	uint32_t tmp2[len];

	uint32_t tmp_a[(len/2)];
	uint32_t tmp_b[(len/2)];

	for(i=0;i<(len/2);i++){
		tmp_a[i] = a[i] ^ a[i+(len/2)];
	}
	for(i=0;i<(len/2);i++){
		tmp_b[i] = b[i] ^ b[i+(len/2)];
	}

	Karatsuba_mul_256_ver2(a,b,tmp0,8);
	Karatsuba_mul_256_ver2(tmp_a,tmp_b,tmp1,8);
	Karatsuba_mul_256_ver2(&a[(len/2)],&b[(len/2)],tmp2,8);

	for(i=0;i<(len);i++){
		tmp1[i] = tmp0[i] ^ tmp2[i];
	}

	for(i=0;i<(len);i++){
		c[i] = tmp0[i];
	}

	for(i=0;i<(len);i++){
		c[i+len] = tmp2[i];
	}

	for(i=0;i<(len);i++){
		c[i+(len/2)] ^= tmp1[i];
	}
}
