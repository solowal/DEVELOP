//
//  SHA.h
//  neon
//
//  Created by info on 2017. 1. 2..
//  Copyright (c) 2017년 info. All rights reserved.
//

#ifndef __neon__SHA__
#define __neon__SHA__

#include <sys/time.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

extern void sha256_block_data_order (uint32_t *ctx, const void *in, size_t num);
void SHA256(uint32_t* output, uint32_t* input32, size_t len);

#endif /* defined(__neon__SHA__) */
