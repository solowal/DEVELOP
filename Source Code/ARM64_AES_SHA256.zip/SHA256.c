//
//  SHA.c
//  neon
//
//  Created by info on 2017. 1. 2..
//  Copyright (c) 2017년 info. All rights reserved.
//

#include "SHA.h"

// SHA-256 initial hash value
const uint32_t H_0[8] = {0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19,};

void SHA256(uint32_t* output, uint32_t* input32, size_t len){
    // initialize hash value
    uint8_t* input = (uint8_t*) input32;
    memcpy(output, H_0, 8*4);
    uint64_t bits = 0;
    size_t i, len_mod, len_num;
    unsigned char buffer[64]={0,};
    
    //len = 56;
    bits = len * 8;
    
    len_num = len / 64;
    len_mod = len % 64;
    
    if(len_num){//larger than 64 bytes
        sha256_block_data_order(output, input, len_num);
        memset(buffer, 0, sizeof(buffer));
        memcpy(buffer, &input[len_num*64], sizeof(uint8_t)*len_mod);
        
        //padding
        buffer[len_mod] = 0x80;
        for (i = len_mod+1; i < 56; i++) {
            buffer[i] = 0x00;
        }
        
    }else{// shorter than 64 bytes
        memset(buffer, 0, sizeof(buffer));
        memcpy(buffer, input, sizeof(uint8_t)*len_mod);
        buffer[len] = 0x80;
        i = len + 1;
        
        if (len > 55) {// longer than 55 bytes
            for (; i < 64; i++) {
                buffer[i] = 0x00;
            }
            sha256_block_data_order(output, buffer,1);
            i = 0;
        }
        
        for (; i < 56; i++) {
            buffer[i] = 0x00;
        }
    }
    
    // add message length in bits in big endian
    for (i = 0; i < 8; i++) {
        buffer[63 - i] = bits >> (i * 8);
    }
    
    sha256_block_data_order(output, buffer,1);
}
