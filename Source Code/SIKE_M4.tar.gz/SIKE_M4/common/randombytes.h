#ifndef RANDOMBYTES_H
#define RANDOMBYTES_H

void randombytes(unsigned char *x,unsigned long long xlen);

#endif
