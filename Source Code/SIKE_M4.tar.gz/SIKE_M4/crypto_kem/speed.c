#include "api.h"
#include "stm32wrapper.h"

#include <stdio.h>
#include <stdint.h>
#include <string.h>

static unsigned long long overflowcnt = 0;

void sys_tick_handler(void)
{
  ++overflowcnt;
}

static void printcycles(const char *s, unsigned long long c)
{
  char outs[32];
  send_USART_str(s);
  snprintf(outs,sizeof(outs),"%llu\n",c);
  send_USART_str(outs);
}

static void write_canary(unsigned char *d)
{
  *((uint64_t *) d)= 0x0123456789ABCDEF;
}

static int check_canary(unsigned char *d)
{
  if(*(uint64_t *) d !=  0x0123456789ABCDEF)
    return -1;
  else
    return 0;
}

int main(void)
{
  unsigned int t0, t1;

  unsigned char key_a[CRYPTO_BYTES+16], key_b[CRYPTO_BYTES+16];
  unsigned char pk[CRYPTO_PUBLICKEYBYTES+16];
  unsigned char sendb[CRYPTO_CIPHERTEXTBYTES+16];
  unsigned char sk_a[CRYPTO_SECRETKEYBYTES+16];
  
  unsigned char PrivateKeyA[SIDH_SECRETKEYBYTES], PrivateKeyB[SIDH_SECRETKEYBYTES];
  unsigned char PublicKeyA[SIDH_PUBLICKEYBYTES], PublicKeyB[SIDH_PUBLICKEYBYTES];
  unsigned char SharedSecretA[SIDH_BYTES], SharedSecretB[SIDH_BYTES];
  bool passed = true;
  
  write_canary(key_a); write_canary(key_a+sizeof(key_a)-8);
  write_canary(key_b); write_canary(key_b+sizeof(key_b)-8);
  write_canary(pk); write_canary(pk+sizeof(pk)-8);
  write_canary(sendb); write_canary(sendb+sizeof(sendb)-8);
  write_canary(sk_a); write_canary(sk_a+sizeof(sk_a)-8);


  //clock_setup(CLOCK_BENCHMARK);
  clock_setup(CLOCK_FAST);
  gpio_setup();
  usart_setup(115200);
  systick_setup();
  rng_enable();

  send_USART_str("==========================");

  random_mod_order_A(PrivateKeyA);
  random_mod_order_B(PrivateKeyB);
  write_canary(SharedSecretB);


  // KeyGen
  t0 = systick_get_value();
  overflowcnt = 0;
  crypto_kem_keypair(pk+8, sk_a+8);
  t1 = systick_get_value();
  printcycles("keypair cycles:", (t0+overflowcnt*2400000llu)-t1);

  // Encapsulation
  t0 = systick_get_value();
  overflowcnt = 0;
  crypto_kem_enc(sendb+8, key_b+8, pk+8);
  t1 = systick_get_value();
  printcycles("encaps cycles: ", (t0+overflowcnt*2400000llu)-t1);

  // Decapsulation
  t0 = systick_get_value();
  overflowcnt = 0;
  crypto_kem_dec(key_a+8, sendb+8, sk_a+8);
  t1 = systick_get_value();
  printcycles("decaps cycles: ", (t0+overflowcnt*2400000llu)-t1);

  if(memcmp(key_a+8, key_b+8, CRYPTO_BYTES))
    {
      send_USART_str("ERROR KEYS\n");
    }
    else
    {
      send_USART_str("OK KEYS\n");
    }

  send_USART_str("#");
  while(1);
  return 0;
}
