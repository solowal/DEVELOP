/*
 * Created: 2021
 * Author : Hwajeong
 */ 

#include <avr/io.h>
#include <stdint-gcc.h>

int main(void)
{
	uint64_t a = 0xffffffff;
	uint64_t b = 0xffffffff;
	uint64_t c = 0;
    /* Replace with your application code */
    c = a * b;
	c = a + b;
	c = a - b - 1;
}

